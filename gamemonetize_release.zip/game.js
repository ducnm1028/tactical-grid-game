/**
 * BREAKERS COMBINE!: WEGO TACTICS 20x7
 * Simultaneous Turn-Based Action Queue Engine
 * Features: Modular Characters, Path-based Movement, Ranged Weapons, Cooldowns & 3x3 AoE Explosions
 */

// --- Hằng số & Cấu hình ---
const GRID_COLS = 20;
const GRID_ROWS = 7;
const CELL_SIZE = 64; // Kích thước mỗi ô trên Canvas

const DIRECTIONS = {
    UP:         { name: 'UP',         dx:  0, dy: -1, symbol: '↑', label: 'Lên', label_en: 'Up' },
    DOWN:       { name: 'DOWN',       dx:  0, dy:  1, symbol: '↓', label: 'Dưới', label_en: 'Down' },
    LEFT:       { name: 'LEFT',       dx: -1, dy:  0, symbol: '←', label: 'Trái', label_en: 'Left' },
    RIGHT:      { name: 'RIGHT',      dx:  1, dy:  0, symbol: '→', label: 'Phải', label_en: 'Right' },
    UP_LEFT:    { name: 'UP_LEFT',    dx: -1, dy: -1, symbol: '↖', label: 'Lên-Trái', label_en: 'Up-Left' },
    UP_RIGHT:   { name: 'UP_RIGHT',   dx:  1, dy: -1, symbol: '↗', label: 'Lên-Phải', label_en: 'Up-Right' },
    DOWN_LEFT:  { name: 'DOWN_LEFT',  dx: -1, dy:  1, symbol: '↙', label: 'Dưới-Trái', label_en: 'Down-Left' },
    DOWN_RIGHT: { name: 'DOWN_RIGHT', dx:  1, dy:  1, symbol: '↘', label: 'Dưới-Phải', label_en: 'Down-Right' }
};

class GameEngine {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');

        this.minimapCanvas = document.getElementById('minimapCanvas');
        this.minimapCtx = this.minimapCanvas.getContext('2d');

        this.resizeCanvas();

        this.turn = 1;
        this.lang = (typeof getLanguage === 'function') ? getLanguage() : 'vi';
        this.phase = 'LANG_SELECT'; // 'LANG_SELECT' | 'MAIN_MENU' | 'CHAR_SELECT' | 'HOW_TO_PLAY' | 'PLANNING' | 'RESOLVING' | 'GAMEOVER'
        this.previousPhaseBeforeGuide = 'MAIN_MENU';
        this.currentStep = -1;

        // Nhân vật được chọn mặc định
        this.selectedCharacter = getCharacterById('trooper');

        // Trạng thái vẽ Lộ trình Di chuyển (Path Planning Mode)
        this.isBuildingPath = false;
        this.activePath = []; // [{ dir, dx, dy, symbol, x, y }]
        this.activePathMaxSteps = 2;

        // Trạng thái hiển thị quảng cáo GameMonetize SDK
        this.isAdShowing = false;

        // Hệ thống Hồi chiêu, Đạn dược & Vật thể mặt đất (Ground Hazards / Lựu đạn / Vùng Cháy)
        this.cooldowns = {}; // { [skillId]: turnsLeft }
        this.skillAmmo = {}; // { [skillId]: currentAmmo }
        this.groundHazards = []; // [{ id, type: 'GRENADE', x, y, turnsLeft: 2, power: 50, aoeRadius: 1 }]
        this.fireZones = []; // [{ id, team, x, y, aoeRadius: 1, turnsLeft: 2, creatorName }]
        this.sentries = []; // [{ id, team, owner, ownerName, x, y, hp: 50, maxHp: 50, power: 10, range: 5, color }]
        this.teleporters = []; // [{ id, team, owner, ownerName, inX, inY, outX, outY, hp: 60, maxHp: 60, color }]
        this.zombies = []; // [{ id, team, owner, ownerName, name, avatar, x, y, hp: 40, maxHp: 40, power: 35, range: 1, attackedThisTurn: false, color }]

        // Trạng thái Lộ diện khi trúng đạn (Hookman Stealth Break)
        this.playerRevealedTurns = 0;
        this.cpuRevealedTurns = 0;

        // Hệ thống Buff & Trạng thái hiệu ứng (Adrenaline, Cigarette, Tether)
        this.playerBuffs = {
            adrenaline: { turnsLeft: 0, healPerTurn: 5, dmgBonusPercent: 20 },
            cigarette: { turnsLeft: 0, dmgBonusPercent: 30, moveBonus: 1 }
        };
        this.activeHookTethers = []; // [{ source, target, turnsUntilPull, pullDist, skillId, cdAfterPull }]

        // Quản lý Chế độ Đội hình & Bổ sung CPU (Tối đa 5 người mỗi đội)
        this.blueTeamSize = 1;
        this.redTeamSize = 1;
        this.currentTeamPreset = '1v1';
        this.gameMode = 'DUEL'; // 'DUEL' (1v1) hoặc 'KOTH' (King of the Hill khi >= 2 người / đội)
        this.kothZone = { minX: 8, maxX: 12, minY: 1, maxY: 5 }; // Khu vực Cứ Điểm 5x5 ở giữa bản đồ 20x7
        this.hillScale = 0; // -2 (Đỏ chiếm), -1 (Đỏ đang chiếm), 0 (Trung lập), +1 (Xanh đang chiếm), +2 (Xanh chiếm)
        this.hillOwner = null; // 'BLUE' | 'RED' | null (Chuẩn TF2 KOTH: Quyền sở hữu cứ điểm liên tục cộng điểm cho tới khi đối thủ chiếm 100%)
        this.blueScore = 0;
        this.redScore = 0;
        this.SCORE_LIMIT = 15;
        this.inOvertime = false;
        this.RESPAWN_TURNS = 2;
        this.blueTeam = [];
        this.redTeam = [];

        // Nhân vật Người chơi (Được gán tham chiếu tới blueTeam[0])
        this.player = {
            x: 2,
            y: 3,
            renderX: 2,
            renderY: 3,
            dir: 'RIGHT',
            hp: 100,
            maxHp: 100,
            shieldDir: null,
            state: 'IDLE',
            color: '#10b981',
            name: 'Trooper',
            avatar: '🪖'
        };

        // Nhân vật CPU (Được gán tham chiếu tới redTeam[0])
        this.cpu = {
            x: 17,
            y: 3,
            renderX: 17,
            renderY: 3,
            dir: 'LEFT',
            hp: 100,
            maxHp: 100,
            shieldDir: null,
            state: 'IDLE',
            color: '#ff3366',
            name: 'SENTINEL',
            avatar: '🤖'
        };

        // Camera viewport
        this.cameraX = 0;
        this.targetCameraX = 0;

        // Hàng đợi 4 lệnh
        this.playerQueue = [];
        this.cpuQueue = [];
        this.currentSelectedDir = 'RIGHT';

        // Quản lý Nhân vật CPU
        this.selectedCpuOption = 'random';
        this.cpuCharacter = null;
        this.cpuCooldowns = {};
        this.cpuSkillAmmo = {};
        this.cpuBuffs = {
            adrenaline: { turnsLeft: 0, healPerTurn: 5, dmgBonusPercent: 20 },
            cigarette: { turnsLeft: 0, dmgBonusPercent: 30, moveBonus: 1 }
        };
        this.cpuRevealedTurns = 0;

        // Hiệu ứng hạt & chữ bay
        this.floatingTexts = [];
        this.particles = [];

        // Quản lý Chế độ 2 Người Chơi Local (Hotseat Mode)
        this.isTwoPlayerMode = false;
        this.p1Team = 'BLUE';
        this.p2Team = 'RED';
        this.p1Character = getCharacterById('trooper');
        this.p2Character = getCharacterById('hookman');
        this.p1Unit = null;
        this.p2Unit = null;
        this.activePlanningPlayer = 1;
        this.p1Queue = [];
        this.p2Queue = [];
        this.isHotseatModalOpen = false;

        this.setupTeams();
        this.initCharacterSelectUI();
        this.initMatchModeUI();
        this.initTeamModeUI();
        this.initMenuAndGuideUI();
        this.bindEvents();
        this.applyLanguageToUI();
        this.updateCamera(true);

        // Vòng lặp vẽ liên tục 60 FPS
        this.lastTime = performance.now();
        requestAnimationFrame((t) => this.renderLoop(t));
    }

    resizeCanvas() {
        this.canvas.width = 960;
        this.canvas.height = GRID_ROWS * CELL_SIZE; // 7 * 64 = 448
    }

    // --- Màn hình Chọn Nhân vật (Character Selection) ---
    initCharacterSelectUI() {
        const container = document.getElementById('charGridContainer');
        if (!container) return;
        const characters = getAllCharacters();
        const lang = this.lang || 'vi';

        container.innerHTML = characters.map(char => {
            const isUnlocked = char.isUnlocked;
            const isSelected = char.id === this.selectedCharacter.id;
            const cName = getCharName(char, lang);
            const cTitle = getCharTitle(char, lang);
            const cDesc = getCharDesc(char, lang);

            const skillsHtml = char.skills.map(s => `
                <div class="preview-skill-item">
                    <span class="ps-icon">${s.icon}</span>
                    <span class="ps-name">${getSkillName(s, lang)}</span>
                    <span class="ps-key">${s.hotkey || ''}</span>
                </div>
            `).join('');

            return `
                <div class="char-card ${isSelected ? 'selected' : ''} ${!isUnlocked ? 'locked' : ''}" 
                     data-char-id="${char.id}">
                    <div class="char-avatar-box">${char.avatar}</div>
                    <div class="char-name">${cName}</div>
                    <div class="char-title">${cTitle}</div>
                    <div class="char-desc">${cDesc}</div>
                    <div style="font-size:0.75rem; color:#f59e0b; margin-bottom:8px;">
                        ${t('moveBudgetLabel', { budget: char.moveBudget || 3 })}
                    </div>
                    <div class="char-skills-preview">
                        ${skillsHtml}
                    </div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('.char-card').forEach(card => {
            card.addEventListener('click', () => {
                const charId = card.getAttribute('data-char-id');
                const char = getCharacterById(charId);
                if (char && char.isUnlocked) {
                    this.selectedCharacter = char;
                    container.querySelectorAll('.char-card').forEach(c => c.classList.remove('selected'));
                    card.classList.add('selected');
                    this.updateTeamRosterPreviews();
                    if (window.soundCtrl) window.soundCtrl.playSelect();
                } else {
                    this.addCombatLog(lang === 'en' ? 'This operative slot is pending design!' : 'Ô nhân vật này đang chờ ý tưởng thiết kế từ bạn!', 'system');
                    if (window.soundCtrl) window.soundCtrl.playUndo();
                }
            });
        });

        const cpuOptBtns = document.querySelectorAll('#cpuSelectOptions .cpu-opt-btn');
        cpuOptBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const cpuChar = btn.getAttribute('data-cpuchar');
                this.selectedCpuOption = cpuChar;
                cpuOptBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.updateTeamRosterPreviews();
                if (window.soundCtrl) window.soundCtrl.playSelect();
            });
        });

        const startBtn = document.getElementById('btnStartBattle');
        if (startBtn) startBtn.onclick = () => this.startBattle();
    }

    // --- Khởi tạo Giao diện Chế độ Thi đấu (1P vs CPU hoặc 2P Local Hotseat) ---
    initMatchModeUI() {
        const btn1P = document.getElementById('btnMode1Player');
        const btn2P = document.getElementById('btnMode2Player');
        if (btn1P) btn1P.addEventListener('click', () => this.setMatchMode(false));
        if (btn2P) btn2P.addEventListener('click', () => this.setMatchMode(true));

        // P1 Team
        const btnP1Blue = document.getElementById('btnP1TeamBlue');
        const btnP1Red = document.getElementById('btnP1TeamRed');
        if (btnP1Blue) btnP1Blue.addEventListener('click', () => this.setP1Team('BLUE'));
        if (btnP1Red) btnP1Red.addEventListener('click', () => this.setP1Team('RED'));

        // P2 Team
        const btnP2Blue = document.getElementById('btnP2TeamBlue');
        const btnP2Red = document.getElementById('btnP2TeamRed');
        if (btnP2Blue) btnP2Blue.addEventListener('click', () => this.setP2Team('BLUE'));
        if (btnP2Red) btnP2Red.addEventListener('click', () => this.setP2Team('RED'));

        // P1 Character
        const p1CharBtns = document.querySelectorAll('#p1CharSelectGrid .p-char-mini-btn');
        p1CharBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const charId = btn.getAttribute('data-char');
                this.setP1Character(charId);
            });
        });

        // P2 Character
        const p2CharBtns = document.querySelectorAll('#p2CharSelectGrid .p-char-mini-btn');
        p2CharBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const charId = btn.getAttribute('data-char');
                this.setP2Character(charId);
            });
        });

        // Nút tiếp tục trong Hotseat Modal
        const btnHotseatCont = document.getElementById('btnHotseatContinue');
        if (btnHotseatCont) {
            btnHotseatCont.addEventListener('click', () => {
                this.continueToP2Planning();
            });
        }

        this.updateMatchModeUI();
    }

    setMatchMode(isTwoPlayer) {
        this.isTwoPlayerMode = !!isTwoPlayer;
        this.updateMatchModeUI();
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    setP1Team(team) {
        if (team === 'BLUE' || team === 'RED') {
            this.p1Team = team;
            this.updateMatchModeUI();
            if (window.soundCtrl) window.soundCtrl.playSelect();
        }
    }

    setP2Team(team) {
        if (team === 'BLUE' || team === 'RED') {
            this.p2Team = team;
            this.updateMatchModeUI();
            if (window.soundCtrl) window.soundCtrl.playSelect();
        }
    }

    setP1Character(charId) {
        const char = typeof charId === 'string' ? getCharacterById(charId) : charId;
        if (char && char.isUnlocked) {
            this.p1Character = char;
            this.updateMatchModeUI();
            if (window.soundCtrl) window.soundCtrl.playSelect();
        }
    }

    setP2Character(charId) {
        const char = typeof charId === 'string' ? getCharacterById(charId) : charId;
        if (char && char.isUnlocked) {
            this.p2Character = char;
            this.updateMatchModeUI();
            if (window.soundCtrl) window.soundCtrl.playSelect();
        }
    }

    updateMatchModeUI() {
        if (typeof document === 'undefined' || !document.getElementById) return;

        const btn1P = document.getElementById('btnMode1Player');
        const btn2P = document.getElementById('btnMode2Player');
        if (btn1P && btn1P.classList) btn1P.classList.toggle('active', !this.isTwoPlayerMode);
        if (btn2P && btn2P.classList) btn2P.classList.toggle('active', this.isTwoPlayerMode);

        const twoPlayerSec = document.getElementById('twoPlayerConfigSection');
        const charGrid = document.getElementById('charGridContainer');
        const cpuSec = document.querySelector('.cpu-select-section');

        if (twoPlayerSec && twoPlayerSec.style) twoPlayerSec.style.display = this.isTwoPlayerMode ? 'block' : 'none';
        if (charGrid && charGrid.style) charGrid.style.display = this.isTwoPlayerMode ? 'none' : 'grid';
        if (cpuSec && cpuSec.style) cpuSec.style.display = this.isTwoPlayerMode ? 'none' : 'flex';

        // P1 Team buttons
        const btnP1Blue = document.getElementById('btnP1TeamBlue');
        const btnP1Red = document.getElementById('btnP1TeamRed');
        if (btnP1Blue && btnP1Blue.classList) btnP1Blue.classList.toggle('active', this.p1Team === 'BLUE');
        if (btnP1Red && btnP1Red.classList) btnP1Red.classList.toggle('active', this.p1Team === 'RED');

        // P2 Team buttons
        const btnP2Blue = document.getElementById('btnP2TeamBlue');
        const btnP2Red = document.getElementById('btnP2TeamRed');
        if (btnP2Blue && btnP2Blue.classList) btnP2Blue.classList.toggle('active', this.p2Team === 'BLUE');
        if (btnP2Red && btnP2Red.classList) btnP2Red.classList.toggle('active', this.p2Team === 'RED');

        // P1 Char buttons
        const p1CharBtns = document.querySelectorAll('#p1CharSelectGrid .p-char-mini-btn');
        p1CharBtns.forEach(btn => {
            if (btn && btn.classList) btn.classList.toggle('active', btn.getAttribute('data-char') === this.p1Character.id);
        });

        // P2 Char buttons
        const p2CharBtns = document.querySelectorAll('#p2CharSelectGrid .p-char-mini-btn');
        p2CharBtns.forEach(btn => {
            if (btn && btn.classList) btn.classList.toggle('active', btn.getAttribute('data-char') === this.p2Character.id);
        });

        // Badges summary
        const p1Badge = document.getElementById('p1ActiveSummaryBadge');
        if (p1Badge) {
            p1Badge.innerText = `${this.p1Team === 'BLUE' ? (this.lang === 'en' ? '🔵 Blue Team' : '🔵 Đội Xanh') : (this.lang === 'en' ? '🔴 Red Team' : '🔴 Đội Đỏ')} • ${this.p1Character.avatar} ${getCharName(this.p1Character, this.lang)}`;
        }
        const p2Badge = document.getElementById('p2ActiveSummaryBadge');
        if (p2Badge) {
            p2Badge.innerText = `${this.p2Team === 'BLUE' ? (this.lang === 'en' ? '🔵 Blue Team' : '🔵 Đội Xanh') : (this.lang === 'en' ? '🔴 Red Team' : '🔴 Đội Đỏ')} • ${this.p2Character.avatar} ${getCharName(this.p2Character, this.lang)}`;
        }

        // Matchup banner
        const matchupText = document.getElementById('twoPlayerMatchupText');
        if (matchupText) {
            const isPvp = this.p1Team !== this.p2Team;
            if (isPvp) {
                matchupText.innerHTML = this.lang === 'en'
                    ? `⚔️ Direct Battle: Player 1 (${this.p1Team === 'BLUE' ? '🔵 Blue' : '🔴 Red'}) vs Player 2 (${this.p2Team === 'BLUE' ? '🔵 Blue' : '🔴 Red'})`
                    : `⚔️ Đối Đầu Trực Tiếp: Người Chơi 1 (${this.p1Team === 'BLUE' ? '🔵 Đội Xanh' : '🔴 Đội Đỏ'}) vs Người Chơi 2 (${this.p2Team === 'BLUE' ? '🔵 Đội Xanh' : '🔴 Đội Đỏ'})`;
            } else {
                const teamName = this.p1Team === 'BLUE' ? (this.lang === 'en' ? '🔵 Blue Team' : '🔵 Đội Xanh') : (this.lang === 'en' ? '🔴 Red Team' : '🔴 Đội Đỏ');
                matchupText.innerHTML = this.lang === 'en'
                    ? `🤝 Co-op Squad: Both Player 1 & Player 2 on ${teamName} against CPU rivals!`
                    : `🤝 Hợp Tác Cùng Phe: Cả 2 Người Chơi cùng thuộc ${teamName} tác chiến chống lại CPU!`;
            }
        }

        this.setupTeams();
        this.updateTeamRosterPreviews();
    }

    // --- Khởi tạo Giao diện Chế độ Đội hình (Tối đa 5 người mỗi đội) ---
    initTeamModeUI() {
        const presets = ['1v1', '2v2', '3v3', '4v4', '5v5'];
        presets.forEach(p => {
            const btn = document.getElementById(`btnPreset${p}`);
            if (btn) {
                btn.addEventListener('click', () => {
                    this.applyTeamPreset(p);
                    if (window.soundCtrl) window.soundCtrl.playSelect();
                });
            }
        });

        const blueBtns = document.querySelectorAll('#blueTeamSizeSelectors .team-size-btn');
        blueBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const sz = parseInt(btn.getAttribute('data-size'), 10) || 1;
                this.setBlueTeamSize(sz);
                if (window.soundCtrl) window.soundCtrl.playSelect();
            });
        });

        const redBtns = document.querySelectorAll('#redTeamSizeSelectors .team-size-btn');
        redBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const sz = parseInt(btn.getAttribute('data-size'), 10) || 1;
                this.setRedTeamSize(sz);
                if (window.soundCtrl) window.soundCtrl.playSelect();
            });
        });

        this.updateTeamModeUI();
    }

    applyTeamPreset(preset) {
        this.currentTeamPreset = preset;
        const num = parseInt(preset[0], 10) || 1;
        this.blueTeamSize = num;
        this.redTeamSize = num;
        this.gameMode = (this.blueTeamSize === 1 && this.redTeamSize === 1) ? 'DUEL' : 'KOTH';
        this.setupTeams();
        this.updateTeamModeUI();
    }

    setBlueTeamSize(size) {
        this.blueTeamSize = Math.max(1, Math.min(5, size));
        if (this.blueTeamSize === this.redTeamSize) {
            this.currentTeamPreset = `${this.blueTeamSize}v${this.blueTeamSize}`;
        } else {
            this.currentTeamPreset = 'custom';
        }
        this.gameMode = (this.blueTeamSize === 1 && this.redTeamSize === 1) ? 'DUEL' : 'KOTH';
        this.setupTeams();
        this.updateTeamModeUI();
    }

    setRedTeamSize(size) {
        this.redTeamSize = Math.max(1, Math.min(5, size));
        if (this.blueTeamSize === this.redTeamSize) {
            this.currentTeamPreset = `${this.blueTeamSize}v${this.blueTeamSize}`;
        } else {
            this.currentTeamPreset = 'custom';
        }
        this.gameMode = (this.blueTeamSize === 1 && this.redTeamSize === 1) ? 'DUEL' : 'KOTH';
        this.setupTeams();
        this.updateTeamModeUI();
    }

    updateTeamModeUI() {
        if (typeof document === 'undefined' || !document.getElementById) return;

        this.gameMode = (this.blueTeamSize === 1 && this.redTeamSize === 1) ? 'DUEL' : 'KOTH';

        const presets = ['1v1', '2v2', '3v3', '4v4', '5v5'];
        presets.forEach(p => {
            const btn = document.getElementById(`btnPreset${p}`);
            if (btn) btn.classList.toggle('active', this.currentTeamPreset === p);
        });

        const blueBtns = document.querySelectorAll('#blueTeamSizeSelectors .team-size-btn');
        blueBtns.forEach(btn => {
            const sz = parseInt(btn.getAttribute('data-size'), 10);
            btn.classList.toggle('active', sz === this.blueTeamSize);
        });

        const redBtns = document.querySelectorAll('#redTeamSizeSelectors .team-size-btn');
        redBtns.forEach(btn => {
            const sz = parseInt(btn.getAttribute('data-size'), 10);
            btn.classList.toggle('active', sz === this.redTeamSize);
        });

        const blueCount = document.getElementById('blueTeamCountPill');
        if (blueCount) {
            blueCount.innerText = t('teamCountFormat', { count: this.blueTeamSize });
        }
        const redCount = document.getElementById('redTeamCountPill');
        if (redCount) {
            redCount.innerText = t('teamCountFormat', { count: this.redTeamSize });
        }

        const modeBadge = document.getElementById('modeObjectiveBadge');
        const modeDesc = document.getElementById('modeObjectiveDesc');
        if (modeBadge && modeDesc) {
            if (this.gameMode === 'DUEL') {
                modeBadge.innerText = t('modeDuelName');
                modeDesc.innerText = t('duelObjectiveDesc');
            } else {
                modeBadge.innerText = t('modeKothName');
                modeDesc.innerText = t('kothObjectiveDesc');
            }
        }

        this.updateTeamRosterPreviews();
    }

    updateTeamRosterPreviews() {
        if (typeof document === 'undefined' || !document.getElementById) return;

        const blueList = document.getElementById('blueRosterList');
        const redList = document.getElementById('redRosterList');
        if (!blueList || !redList) return;

        const unlockedChars = CHARACTERS_DATABASE.filter(c => c.isUnlocked);

        if (this.isTwoPlayerMode) {
            // Roster Đội Xanh (2P Mode)
            let blueHtml = '';
            if (this.p1Team === 'BLUE') {
                blueHtml += `
                    <div class="team-roster-chip is-player" title="${getCharName(this.p1Character, this.lang)} (${this.p1Character.maxHp} HP)">
                        <span>🎮 ${this.p1Character.avatar}</span>
                        <span>${getCharName(this.p1Character, this.lang)}</span>
                        <span style="color: #38bdf8; font-size: 0.68rem; font-weight:800;">[P1]</span>
                    </div>
                `;
            }
            if (this.p2Team === 'BLUE') {
                blueHtml += `
                    <div class="team-roster-chip is-player" title="${getCharName(this.p2Character, this.lang)} (${this.p2Character.maxHp} HP)">
                        <span>🎮 ${this.p2Character.avatar}</span>
                        <span>${getCharName(this.p2Character, this.lang)}</span>
                        <span style="color: #38bdf8; font-size: 0.68rem; font-weight:800;">[P2]</span>
                    </div>
                `;
            }
            const currentBlueHumans = (this.p1Team === 'BLUE' ? 1 : 0) + (this.p2Team === 'BLUE' ? 1 : 0);
            for (let i = currentBlueHumans; i < this.blueTeamSize; i++) {
                const allyChar = unlockedChars[i % unlockedChars.length];
                blueHtml += `
                    <div class="team-roster-chip is-ally" title="${getCharName(allyChar, this.lang)} (${allyChar.maxHp} HP)">
                        <span>🤖 ${allyChar.avatar}</span>
                        <span>${getCharName(allyChar, this.lang)}</span>
                        <span style="color: #38bdf8; font-size: 0.65rem;">+CPU</span>
                    </div>
                `;
            }
            blueList.innerHTML = blueHtml || `<span style="color:#64748b; font-size:0.75rem;">(${this.lang === 'en' ? 'Empty' : 'Trống'})</span>`;

            // Roster Đội Đỏ (2P Mode)
            let redHtml = '';
            if (this.p1Team === 'RED') {
                redHtml += `
                    <div class="team-roster-chip is-enemy" title="${getCharName(this.p1Character, this.lang)} (${this.p1Character.maxHp} HP)">
                        <span>🎮 ${this.p1Character.avatar}</span>
                        <span>${getCharName(this.p1Character, this.lang)}</span>
                        <span style="color: #f43f5e; font-size: 0.68rem; font-weight:800;">[P1]</span>
                    </div>
                `;
            }
            if (this.p2Team === 'RED') {
                redHtml += `
                    <div class="team-roster-chip is-enemy" title="${getCharName(this.p2Character, this.lang)} (${this.p2Character.maxHp} HP)">
                        <span>🎮 ${this.p2Character.avatar}</span>
                        <span>${getCharName(this.p2Character, this.lang)}</span>
                        <span style="color: #f43f5e; font-size: 0.68rem; font-weight:800;">[P2]</span>
                    </div>
                `;
            }
            const currentRedHumans = (this.p1Team === 'RED' ? 1 : 0) + (this.p2Team === 'RED' ? 1 : 0);
            for (let j = currentRedHumans; j < this.redTeamSize; j++) {
                const enemyChar = unlockedChars[(j + 2) % unlockedChars.length];
                redHtml += `
                    <div class="team-roster-chip is-enemy" title="${getCharName(enemyChar, this.lang)} (${enemyChar.maxHp} HP)">
                        <span>🤖 ${enemyChar.avatar}</span>
                        <span>${getCharName(enemyChar, this.lang)}</span>
                        <span style="color: #fb7185; font-size: 0.65rem;">+CPU</span>
                    </div>
                `;
            }
            redList.innerHTML = redHtml || `<span style="color:#64748b; font-size:0.75rem;">(${this.lang === 'en' ? 'Empty' : 'Trống'})</span>`;
            return;
        }

        const pChar = this.selectedCharacter || getCharacterById('trooper');
        const otherChars = unlockedChars.filter(c => c.id !== pChar.id);
        const allyPool = otherChars.length > 0 ? otherChars : unlockedChars;

        // Blue Team Roster (1P Mode)
        let blueHtml = `
            <div class="team-roster-chip is-player" title="${getCharName(pChar, this.lang)} (100 HP)">
                <span>👑 ${pChar.avatar}</span>
                <span>${getCharName(pChar, this.lang)}</span>
                <span style="color: #34d399; font-size: 0.68rem;">[${this.lang === 'en' ? 'YOU' : 'BẠN'}]</span>
            </div>
        `;
        for (let i = 1; i < this.blueTeamSize; i++) {
            const allyChar = allyPool[(i - 1) % allyPool.length];
            blueHtml += `
                <div class="team-roster-chip is-ally" title="${getCharName(allyChar, this.lang)} (${allyChar.maxHp} HP)">
                    <span>🤖 ${allyChar.avatar}</span>
                    <span>${getCharName(allyChar, this.lang)}</span>
                    <span style="color: #38bdf8; font-size: 0.65rem;">+CPU</span>
                </div>
            `;
        }
        blueList.innerHTML = blueHtml;

        // Red Team Roster (1P Mode)
        let cLeaderChar = getCharacterById(this.selectedCpuOption);
        if (!cLeaderChar) cLeaderChar = unlockedChars[0];

        let redHtml = `
            <div class="team-roster-chip is-enemy" title="${getCharName(cLeaderChar, this.lang)} (${cLeaderChar.maxHp} HP)">
                <span>🎯 ${cLeaderChar.avatar}</span>
                <span>${getCharName(cLeaderChar, this.lang)}</span>
                <span style="color: #fb7185; font-size: 0.65rem;">${this.lang === 'en' ? 'LEADER' : 'CHỦ LỰC'}</span>
            </div>
        `;
        for (let j = 1; j < this.redTeamSize; j++) {
            const enemyChar = unlockedChars[j % unlockedChars.length];
            redHtml += `
                <div class="team-roster-chip is-enemy" title="${getCharName(enemyChar, this.lang)} (${enemyChar.maxHp} HP)">
                    <span>🤖 ${enemyChar.avatar}</span>
                    <span>${getCharName(enemyChar, this.lang)}</span>
                    <span style="color: #fb7185; font-size: 0.65rem;">CPU ${j + 1}</span>
                </div>
            `;
        }
        redList.innerHTML = redHtml;
    }

    // --- Tọa độ Xuất phát 20x7 cho Đội hình Tối đa 5 người ---
    getTeamSpawnPosition(team, index) {
        const blueSpawns = [
            { x: 2, y: 3 }, // Vị trí trung tâm
            { x: 2, y: 1 }, // Cánh trên
            { x: 2, y: 5 }, // Cánh dưới
            { x: 1, y: 2 }, // Hậu quân trên
            { x: 1, y: 4 }  // Hậu quân dưới
        ];
        const redSpawns = [
            { x: 17, y: 3 }, // Vị trí trung tâm
            { x: 17, y: 1 }, // Cánh trên
            { x: 17, y: 5 }, // Cánh dưới
            { x: 18, y: 2 }, // Hậu quân trên
            { x: 18, y: 4 }  // Hậu quân dưới
        ];
        return team === 'BLUE' ? blueSpawns[index % 5] : redSpawns[index % 5];
    }

    isInCaptureZone(x, y) {
        return x >= this.kothZone.minX && x <= this.kothZone.maxX &&
               y >= this.kothZone.minY && y <= this.kothZone.maxY;
    }

    getRespawnPosition(team, index) {
        const defaultSpawn = this.getTeamSpawnPosition(team, index);
        const allLiving = [...(this.blueTeam || []), ...(this.redTeam || [])].filter(u => u.hp > 0 && !u.isDead);
        if (!allLiving.some(u => u.x === defaultSpawn.x && u.y === defaultSpawn.y)) {
            return defaultSpawn;
        }
        const minCol = team === 'BLUE' ? 0 : 15;
        const maxCol = team === 'BLUE' ? 4 : 19;
        for (let offset = 0; offset <= 4; offset++) {
            for (let r = 0; r < GRID_ROWS; r++) {
                const col = team === 'BLUE' ? minCol + offset : maxCol - offset;
                if (!allLiving.some(u => u.x === col && u.y === r)) {
                    return { x: col, y: r };
                }
            }
        }
        return defaultSpawn;
    }

    createUnit(id, team, index, charObj, isPlayer = false, customName = null) {
        const spawn = this.getTeamSpawnPosition(team, index);
        const unit = {
            id,
            team,
            index,
            isPlayer,
            isCpu: !isPlayer,
            charId: charObj.id,
            character: charObj,
            name: customName || (isPlayer ? getCharName(charObj, this.lang) : `${team === 'BLUE' ? (this.lang === 'en' ? 'Ally' : 'Đồng minh') : (this.lang === 'en' ? 'Enemy' : 'Kẻ địch')} ${getCharName(charObj, this.lang)}`),
            avatar: charObj.avatar,
            color: isPlayer ? charObj.themeColor : (team === 'BLUE' ? '#38bdf8' : '#f43f5e'),
            charThemeColor: charObj.themeColor,
            hp: charObj.maxHp,
            maxHp: charObj.maxHp,
            x: spawn.x,
            y: spawn.y,
            renderX: spawn.x,
            renderY: spawn.y,
            dir: team === 'BLUE' ? 'RIGHT' : 'LEFT',
            shieldDir: null,
            state: 'IDLE',
            moveBudget: charObj.moveBudget || 2,
            stealthRadius: charObj.stealthRadius || 0,
            revealedTurns: 0,
            cooldowns: {},
            skillAmmo: {},
            buffs: {
                adrenaline: { turnsLeft: 0, healPerTurn: 5, dmgBonusPercent: 20 },
                cigarette: { turnsLeft: 0, dmgBonusPercent: 30, moveBonus: 1 },
                destructiveShot: false,
                thermalVision: { active: false, rangeBonus: 0 },
                chaosShot: false,
                invulnerability: { active: false, primedForNextTurn: false, turnsLeft: 0, sourceName: '' }
            },
            isScoped: false,
            isImmune: false,
            queue: [],
            alive: true,
            isDead: false,
            respawnTurns: 0,
            isOiled: false,
            burnTurns: 0,
            burnDmg: 5,
            stats: {
                kills: 0,
                deaths: 0,
                damageDealt: 0,
                damageTaken: 0,
                healing: 0,
                hillPoints: 0,
                score: 0
            }
        };
        charObj.skills.forEach(s => {
            if (s.maxAmmo) unit.skillAmmo[s.id] = s.maxAmmo;
        });
        return unit;
    }

    setupTeams() {
        const unlockedChars = CHARACTERS_DATABASE.filter(c => c.isUnlocked);

        if (this.isTwoPlayerMode) {
            let blueSize = Math.max(1, Math.min(5, this.blueTeamSize || 1));
            let redSize = Math.max(1, Math.min(5, this.redTeamSize || 1));
            if (this.p1Team === 'BLUE' && this.p2Team === 'BLUE') {
                blueSize = Math.max(2, blueSize);
                this.blueTeamSize = blueSize;
            }
            if (this.p1Team === 'RED' && this.p2Team === 'RED') {
                redSize = Math.max(2, redSize);
                this.redTeamSize = redSize;
            }
            this.gameMode = (blueSize === 1 && redSize === 1) ? 'DUEL' : 'KOTH';

            this.blueTeam = [];
            this.redTeam = [];

            // 1. Blue Team (2P Mode)
            const bluePlayers = [];
            if (this.p1Team === 'BLUE') bluePlayers.push({ pNum: 1, char: this.p1Character });
            if (this.p2Team === 'BLUE') bluePlayers.push({ pNum: 2, char: this.p2Character });

            for (let i = 0; i < bluePlayers.length; i++) {
                const pInfo = bluePlayers[i];
                const unit = this.createUnit(`blue_${i}`, 'BLUE', i, pInfo.char, true, `(P${pInfo.pNum}) [${getCharName(pInfo.char, this.lang)}]`);
                unit.playerIndex = pInfo.pNum;
                if (pInfo.pNum === 1) this.p1Unit = unit;
                if (pInfo.pNum === 2) this.p2Unit = unit;
                this.blueTeam.push(unit);
            }

            for (let i = this.blueTeam.length; i < blueSize; i++) {
                const allyChar = unlockedChars[i % unlockedChars.length];
                const allyUnit = this.createUnit(`blue_${i}`, 'BLUE', i, allyChar, false);
                this.blueTeam.push(allyUnit);
            }

            // 2. Red Team (2P Mode)
            const redPlayers = [];
            if (this.p1Team === 'RED') redPlayers.push({ pNum: 1, char: this.p1Character });
            if (this.p2Team === 'RED') redPlayers.push({ pNum: 2, char: this.p2Character });

            for (let j = 0; j < redPlayers.length; j++) {
                const pInfo = redPlayers[j];
                const unit = this.createUnit(`red_${j}`, 'RED', j, pInfo.char, true, `(P${pInfo.pNum}) [${getCharName(pInfo.char, this.lang)}]`);
                unit.playerIndex = pInfo.pNum;
                if (pInfo.pNum === 1) this.p1Unit = unit;
                if (pInfo.pNum === 2) this.p2Unit = unit;
                this.redTeam.push(unit);
            }

            for (let j = this.redTeam.length; j < redSize; j++) {
                const enemyChar = unlockedChars[(j + 2) % unlockedChars.length];
                const enemyUnit = this.createUnit(`red_${j}`, 'RED', j, enemyChar, false);
                this.redTeam.push(enemyUnit);
            }

            // Đồng bộ tham chiếu tương thích ngược
            this.player = this.p1Unit || this.blueTeam[0];
            this.cpu = this.p2Unit || this.redTeam[0];
            this.cooldowns = this.player.cooldowns;
            this.skillAmmo = this.player.skillAmmo;
            this.playerBuffs = this.player.buffs;
            this.cpuCooldowns = this.cpu.cooldowns;
            this.cpuSkillAmmo = this.cpu.skillAmmo;
            this.cpuBuffs = this.cpu.buffs;
            this.playerRevealedTurns = this.player.revealedTurns;
            this.cpuRevealedTurns = this.cpu.revealedTurns;
            this.activePathMaxSteps = this.player.moveBudget;
            return;
        }

        const blueSize = Math.max(1, Math.min(5, this.blueTeamSize || 1));
        const redSize = Math.max(1, Math.min(5, this.redTeamSize || 1));
        this.gameMode = (blueSize === 1 && redSize === 1) ? 'DUEL' : 'KOTH';

        // 1. Blue Team
        this.blueTeam = [];
        const pChar = this.selectedCharacter || getCharacterById('trooper');
        const pUnit = this.createUnit('blue_0', 'BLUE', 0, pChar, true, getCharName(pChar, this.lang));
        this.blueTeam.push(pUnit);

        const otherChars = unlockedChars.filter(c => c.id !== pChar.id);
        const allyPool = otherChars.length > 0 ? otherChars : unlockedChars;
        for (let i = 1; i < blueSize; i++) {
            const allyChar = allyPool[(i - 1) % allyPool.length];
            const allyUnit = this.createUnit(`blue_${i}`, 'BLUE', i, allyChar, false);
            this.blueTeam.push(allyUnit);
        }

        // 2. Red Team
        this.redTeam = [];
        let cLeaderChar = this.cpuCharacter;
        if (!cLeaderChar) {
            if (this.selectedCpuOption && this.selectedCpuOption !== 'random') {
                cLeaderChar = getCharacterById(this.selectedCpuOption);
            }
            if (!cLeaderChar) cLeaderChar = unlockedChars[0];
            this.cpuCharacter = cLeaderChar;
        }

        const cLeaderUnit = this.createUnit('red_0', 'RED', 0, cLeaderChar, false, `${this.lang === 'en' ? 'Sentinel' : 'Thủ lĩnh'} [${getCharName(cLeaderChar, this.lang)}]`);
        this.redTeam.push(cLeaderUnit);

        for (let j = 1; j < redSize; j++) {
            const enemyChar = unlockedChars[j % unlockedChars.length];
            const enemyUnit = this.createUnit(`red_${j}`, 'RED', j, enemyChar, false);
            this.redTeam.push(enemyUnit);
        }

        // Đồng bộ các tham chiếu tương thích ngược (Backward compatibility)
        this.player = this.blueTeam[0];
        this.cpu = this.redTeam[0];
        this.cooldowns = this.player.cooldowns;
        this.skillAmmo = this.player.skillAmmo;
        this.playerBuffs = this.player.buffs;
        this.cpuCooldowns = this.cpu.cooldowns;
        this.cpuSkillAmmo = this.cpu.skillAmmo;
        this.cpuBuffs = this.cpu.buffs;
        this.playerRevealedTurns = this.player.revealedTurns;
        this.cpuRevealedTurns = this.cpu.revealedTurns;
        this.activePathMaxSteps = this.player.moveBudget;
    }

    // --- Khởi tạo Giao diện Màn hình Chính, Hướng dẫn & Ngôn ngữ ---
    initMenuAndGuideUI() {
        const btnVi = document.getElementById('btnSelectLangVi');
        if (btnVi) {
            btnVi.addEventListener('click', () => this.selectLanguage('vi'));
        }

        const btnEn = document.getElementById('btnSelectLangEn');
        if (btnEn) {
            btnEn.addEventListener('click', () => this.selectLanguage('en'));
        }

        const btnHeaderLang = document.getElementById('btnHeaderLang');
        if (btnHeaderLang) {
            btnHeaderLang.addEventListener('click', () => this.toggleLanguage());
        }

        const btnPlay = document.getElementById('btnMenuPlay');
        if (btnPlay) {
            btnPlay.addEventListener('click', () => this.showCharSelectScreen());
        }

        const btnMenuLb = document.getElementById('btnMenuLeaderboard');
        if (btnMenuLb) {
            btnMenuLb.addEventListener('click', () => this.openHallOfFame());
        }

        const btnGuide = document.getElementById('btnMenuGuide');
        if (btnGuide) {
            btnGuide.addEventListener('click', () => this.showHowToPlayScreen());
        }

        const btnCloseGuideX = document.getElementById('btnCloseGuideX');
        if (btnCloseGuideX) {
            btnCloseGuideX.addEventListener('click', () => this.closeHowToPlayScreen());
        }

        const btnGuideBack = document.getElementById('btnGuideBack');
        if (btnGuideBack) {
            btnGuideBack.addEventListener('click', () => this.closeHowToPlayScreen());
        }

        const btnGuidePlay = document.getElementById('btnGuidePlay');
        if (btnGuidePlay) {
            btnGuidePlay.addEventListener('click', () => this.showCharSelectScreen());
        }

        const btnCharSelectBack = document.getElementById('btnCharSelectBack');
        if (btnCharSelectBack) {
            btnCharSelectBack.addEventListener('click', () => this.showMainMenuScreen());
        }

        const btnHeaderMenu = document.getElementById('btnHeaderMenu');
        if (btnHeaderMenu) {
            btnHeaderMenu.addEventListener('click', () => this.showMainMenuScreen());
        }

        const btnHeaderGuide = document.getElementById('btnHeaderGuide');
        if (btnHeaderGuide) {
            btnHeaderGuide.addEventListener('click', () => this.showHowToPlayScreen());
        }
    }

    showLanguageSelectScreen() {
        this.cancelPathPlanning();
        this.phase = 'LANG_SELECT';
        const langScreen = document.getElementById('languageSelectScreen');
        const menu = document.getElementById('mainMenuScreen');
        const charSel = document.getElementById('charSelectScreen');
        const guide = document.getElementById('howToPlayScreen');
        if (langScreen) langScreen.style.display = 'flex';
        if (menu) menu.style.display = 'none';
        if (charSel) charSel.style.display = 'none';
        if (guide) guide.style.display = 'none';
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    selectLanguage(lang) {
        if (typeof setLanguage === 'function') {
            setLanguage(lang);
        }
        this.lang = lang;
        const langScreen = document.getElementById('languageSelectScreen');
        if (langScreen) langScreen.style.display = 'none';
        this.applyLanguageToUI();
        if (window.soundCtrl) window.soundCtrl.playSelect();
        this.showMainMenuScreen();
    }

    toggleLanguage() {
        const nextLang = (this.lang === 'vi') ? 'en' : 'vi';
        if (typeof setLanguage === 'function') {
            setLanguage(nextLang);
        }
        this.lang = nextLang;
        this.applyLanguageToUI();
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    showMainMenuScreen() {
        this.cancelPathPlanning();
        this.phase = 'MAIN_MENU';
        const langScreen = document.getElementById('languageSelectScreen');
        const menu = document.getElementById('mainMenuScreen');
        const charSel = document.getElementById('charSelectScreen');
        const guide = document.getElementById('howToPlayScreen');
        if (langScreen) langScreen.style.display = 'none';
        if (menu) menu.style.display = 'flex';
        if (charSel) charSel.style.display = 'none';
        if (guide) guide.style.display = 'none';
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    showCharSelectScreen() {
        this.cancelPathPlanning();
        this.phase = 'CHAR_SELECT';
        const langScreen = document.getElementById('languageSelectScreen');
        const menu = document.getElementById('mainMenuScreen');
        const charSel = document.getElementById('charSelectScreen');
        const guide = document.getElementById('howToPlayScreen');
        if (langScreen) langScreen.style.display = 'none';
        if (menu) menu.style.display = 'none';
        if (charSel) charSel.style.display = 'flex';
        if (guide) guide.style.display = 'none';
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    showHowToPlayScreen() {
        this.cancelPathPlanning();
        if (this.phase !== 'HOW_TO_PLAY') {
            this.previousPhaseBeforeGuide = this.phase;
        }
        this.phase = 'HOW_TO_PLAY';
        const langScreen = document.getElementById('languageSelectScreen');
        const menu = document.getElementById('mainMenuScreen');
        const charSel = document.getElementById('charSelectScreen');
        const guide = document.getElementById('howToPlayScreen');
        if (langScreen) langScreen.style.display = 'none';
        if (menu) menu.style.display = 'none';
        if (charSel) charSel.style.display = 'none';
        if (guide) guide.style.display = 'flex';
        this.renderHowToPlayUI();
        if (window.soundCtrl) window.soundCtrl.playSelect();
    }

    closeHowToPlayScreen() {
        if (this.previousPhaseBeforeGuide === 'CHAR_SELECT') {
            this.showCharSelectScreen();
        } else if (this.previousPhaseBeforeGuide === 'PLANNING') {
            const guide = document.getElementById('howToPlayScreen');
            if (guide) guide.style.display = 'none';
            this.phase = 'PLANNING';
            if (window.soundCtrl) window.soundCtrl.playSelect();
        } else {
            this.showMainMenuScreen();
        }
    }

    triggerAd() {
        if (typeof sdk !== 'undefined' && typeof sdk.showBanner !== 'undefined') {
            try {
                sdk.showBanner();
            } catch (e) {
                console.warn('[GameMonetize] showBanner error:', e);
            }
        }
    }

    startBattle() {
        this.triggerAd();
        const langScreen = document.getElementById('languageSelectScreen');
        const menu = document.getElementById('mainMenuScreen');
        const charSel = document.getElementById('charSelectScreen');
        const guide = document.getElementById('howToPlayScreen');
        if (langScreen) langScreen.style.display = 'none';
        if (menu) menu.style.display = 'none';
        if (charSel) charSel.style.display = 'none';
        if (guide) guide.style.display = 'none';

        if (this.isTwoPlayerMode) {
            this.setupTeams();
            this.sentries = [];
            this.teleporters = [];
            this.activePlanningPlayer = 1;
            this.p1Queue = [];
            this.p2Queue = [];
            this.playerQueue = [];
            this.cpuQueue = [];
            this.selectedCharacter = this.p1Character;
            this.cooldowns = this.p1Unit.cooldowns;
            this.skillAmmo = this.p1Unit.skillAmmo;
            this.playerBuffs = this.p1Unit.buffs;
            this.currentSelectedDir = this.p1Unit.dir || (this.p1Unit.team === 'BLUE' ? 'RIGHT' : 'LEFT');
            this.highlightSelectedDirButton();
        } else {
            this.applySelectedCharacter();
            this.applyCpuCharacter(this.selectedCpuOption);
            this.setupTeams();
        }

        this.turn = 1;
        this.hillScale = 0;
        this.hillOwner = null;
        this.blueScore = 0;
        this.redScore = 0;
        this.inOvertime = false;
        this.phase = 'PLANNING';
        if (window.soundCtrl) window.soundCtrl.playCommit();

        if (this.isTwoPlayerMode) {
            const p1 = this.p1Unit;
            const p2 = this.p2Unit;
            this.addCombatLog(this.lang === 'en'
                ? `👥 2-Player Local Match started! P1 (${p1.name}) vs P2 (${p2.name}). Planning Turn: Player 1 (P1)!`
                : `👥 Trận đấu 2 Người Chơi Local bắt đầu! P1 (${p1.name}) vs P2 (${p2.name}). Lượt lập lệnh: Người Chơi 1 (P1)!`, 'system');
        } else if (this.gameMode === 'KOTH') {
            this.addCombatLog(this.lang === 'en'
                ? `👑 King of the Hill started! Squads: Blue (${this.blueTeamSize}) vs Red (${this.redTeamSize}). Hold the 5x5 Hill to reach 15 points!`
                : `👑 Chế độ Chiếm Cứ Điểm 5x5 bắt đầu! Đội hình: Xanh (${this.blueTeamSize}) vs Đỏ (${this.redTeamSize}). Chiếm giữ Cứ điểm để đạt 15 điểm!`, 'system');
        } else {
            this.addCombatLog(this.lang === 'en'
                ? `⚔️ 1v1 Classic Duel started! Eliminate your opponent to win!`
                : `⚔️ Đấu tay đôi 1v1 sinh tử bắt đầu! Tiêu diệt đối thủ để chiến thắng!`, 'system');
        }
        this.updateHUD();
        this.updateQueueDisplay();
    }

    applyLanguageToUI() {
        if (typeof document === 'undefined' || !document.querySelector) return;
        const lang = this.lang || 'vi';
        document.title = t('appTitle');

        // Header
        const subElem = document.querySelector('.title-container .subtitle');
        if (subElem) subElem.innerText = t('headerSubtitle');

        const btnHdrLb = document.getElementById('btnHeaderLeaderboard');
        if (btnHdrLb) {
            btnHdrLb.innerText = t('btnHeaderLeaderboard');
            btnHdrLb.title = t('tooltipHeaderLeaderboard');
        }

        const btnHudLb = document.getElementById('btnHudLeaderboard');
        if (btnHudLb) {
            btnHudLb.innerText = t('btnHudLeaderboard');
            btnHudLb.title = t('tooltipHudLeaderboard');
        }

        const btnLang = document.getElementById('btnHeaderLang');
        if (btnLang) {
            btnLang.innerText = lang === 'vi' ? '🌐 English' : '🌐 Tiếng Việt';
            btnLang.title = t('tooltipHeaderLang');
        }

        const btnMenu = document.getElementById('btnHeaderMenu');
        if (btnMenu) {
            btnMenu.innerText = t('btnHeaderMenu');
            btnMenu.title = t('tooltipHeaderMenu');
        }

        const btnGuide = document.getElementById('btnHeaderGuide');
        if (btnGuide) {
            btnGuide.innerText = t('btnHeaderGuide');
            btnGuide.title = t('tooltipHeaderGuide');
        }

        const btnChar = document.getElementById('btnOpenCharSelect');
        if (btnChar) {
            btnChar.innerText = t('btnOpenCharSelect');
            btnChar.title = t('tooltipOpenCharSelect');
        }

        const soundBtn = document.getElementById('soundToggleBtn');
        if (soundBtn) {
            soundBtn.innerText = (window.soundCtrl && window.soundCtrl.enabled) ? t('soundOn') : t('soundOff');
            soundBtn.title = t('tooltipSoundToggle');
        }

        // Main Menu
        const menuBadge = document.querySelector('.menu-badge');
        if (menuBadge) menuBadge.innerText = t('menuBadge');

        const menuTitle = document.querySelector('.menu-title');
        if (menuTitle) menuTitle.innerText = t('menuTitle');

        const menuTag = document.querySelector('.menu-tagline');
        if (menuTag) menuTag.innerText = t('menuTagline');

        const menuDesc = document.querySelector('.menu-description');
        if (menuDesc) menuDesc.innerText = t('menuDescription');

        const btnMenuPlay = document.getElementById('btnMenuPlay');
        if (btnMenuPlay) btnMenuPlay.title = t('tooltipMenuPlay');
        const playMain = document.querySelector('#btnMenuPlay .btn-main-text');
        if (playMain) playMain.innerText = t('btnMenuPlay');
        const playSub = document.querySelector('#btnMenuPlay .btn-sub-text');
        if (playSub) playSub.innerText = t('btnMenuPlaySub');

        const btnMenuLb = document.getElementById('btnMenuLeaderboard');
        if (btnMenuLb) btnMenuLb.title = t('tooltipMenuLeaderboard');
        const lbMenuMain = document.querySelector('#btnMenuLeaderboard .btn-main-text');
        if (lbMenuMain) lbMenuMain.innerText = t('btnMenuLeaderboard');
        const lbMenuSub = document.querySelector('#btnMenuLeaderboard .btn-sub-text');
        if (lbMenuSub) lbMenuSub.innerText = t('btnMenuLeaderboardSub');

        const btnMenuGuide = document.getElementById('btnMenuGuide');
        if (btnMenuGuide) btnMenuGuide.title = t('tooltipMenuGuide');
        const guideMain = document.querySelector('#btnMenuGuide .btn-main-text');
        if (guideMain) guideMain.innerText = t('btnMenuGuide');
        const guideSub = document.querySelector('#btnMenuGuide .btn-sub-text');
        if (guideSub) guideSub.innerText = t('btnMenuGuideSub');

        // Language Select Screen Labels
        const langBadgeEl = document.querySelector('#languageSelectScreen .lang-badge');
        if (langBadgeEl) langBadgeEl.innerText = t('langBadge');
        const langTitleEl = document.querySelector('#languageSelectScreen .lang-title');
        if (langTitleEl) langTitleEl.innerText = t('langTitle');
        const langSubEl = document.querySelector('#languageSelectScreen .lang-subtitle');
        if (langSubEl) langSubEl.innerText = t('langSubtitle');
        const langViNameEl = document.querySelector('#btnSelectLangVi .lang-card-name');
        if (langViNameEl) langViNameEl.innerText = t('langCardViTitle');
        const langViSubEl = document.querySelector('#btnSelectLangVi .lang-card-sub');
        if (langViSubEl) langViSubEl.innerText = t('langCardViSub');
        const langEnNameEl = document.querySelector('#btnSelectLangEn .lang-card-name');
        if (langEnNameEl) langEnNameEl.innerText = t('langCardEnTitle');
        const langEnSubEl = document.querySelector('#btnSelectLangEn .lang-card-sub');
        if (langEnSubEl) langEnSubEl.innerText = t('langCardEnSub');
        const langHintEl = document.querySelector('#languageSelectScreen .lang-footer-hint');
        if (langHintEl) {
            langHintEl.innerHTML = lang === 'en'
                ? `<span>You can switch languages anytime using the <b>🌐</b> button in the top bar.</span>`
                : `<span>💡 Bạn có thể đổi lại ngôn ngữ bất kỳ lúc nào bằng nút <b>🌐</b> trên thanh tiêu đề.</span>`;
        }

        const pills = document.querySelectorAll('.menu-feature-pills .pill');
        if (pills && pills.length >= 4) {
            pills[0].innerText = t('pillWego');
            pills[1].innerText = t('pillChars');
            pills[2].innerText = t('pillRoute');
            pills[3].innerText = t('pillCpu');
        }

        const menuHint = document.querySelector('.menu-footer-hint');
        if (menuHint) {
            menuHint.innerHTML = lang === 'en'
                ? `Press <kbd class="kbd-hint">SPACE</kbd> or <kbd class="kbd-hint">ENTER</kbd> to Play • Press <kbd class="kbd-hint">H</kbd> for Guide`
                : `Nhấn <kbd class="kbd-hint">SPACE</kbd> hoặc <kbd class="kbd-hint">ENTER</kbd> để vào Chơi • Nhấn <kbd class="kbd-hint">H</kbd> để xem Hướng dẫn`;
        }

        // Đồng bộ hóa tên các đấu thủ theo ngôn ngữ hiện tại
        if (this.blueTeam && this.redTeam) {
            [...this.blueTeam, ...this.redTeam].forEach(u => {
                if (u.character) {
                    u.name = u.isPlayer ? getCharName(u.character, lang) : `${u.team === 'BLUE' ? (lang === 'en' ? 'Ally' : 'Đồng minh') : (lang === 'en' ? 'Enemy' : 'Kẻ địch')} ${getCharName(u.character, lang)}`;
                }
            });
        }

        // Character Select Screen
        const csTitle = document.getElementById('charSelectHeaderMainTitle') || document.querySelector('.char-select-header h2');
        if (csTitle) csTitle.innerText = t('charSelectHeaderTitle');
        const csSub = document.getElementById('charSelectHeaderSubText') || document.querySelector('.char-select-header p');
        if (csSub) csSub.innerText = t('charSelectHeaderSub');

        // Match Mode Selector
        const matchModeLbl = document.getElementById('matchModeLabel');
        if (matchModeLbl) matchModeLbl.innerText = t('matchModeTitle');
        const btn1P = document.getElementById('btnMode1Player');
        if (btn1P) btn1P.innerText = t('mode1Player');
        const btn2P = document.getElementById('btnMode2Player');
        if (btn2P) btn2P.innerText = t('mode2Player');

        // 2P Config Labels
        const p1Choice = document.getElementById('p1TeamChoiceLabel');
        if (p1Choice) p1Choice.innerText = t('teamChoicePrompt');
        const p2Choice = document.getElementById('p2TeamChoiceLabel');
        if (p2Choice) p2Choice.innerText = t('teamChoicePrompt');
        const p1CharChoice = document.getElementById('p1CharChoiceLabel');
        if (p1CharChoice) p1CharChoice.innerText = t('charChoicePrompt');
        const p2CharChoice = document.getElementById('p2CharChoiceLabel');
        if (p2CharChoice) p2CharChoice.innerText = t('charChoicePrompt');
        const btnP1B = document.getElementById('btnP1TeamBlue');
        if (btnP1B) btnP1B.innerText = t('teamBlueOpt');
        const btnP1R = document.getElementById('btnP1TeamRed');
        if (btnP1R) btnP1R.innerText = t('teamRedOpt');
        const btnP2B = document.getElementById('btnP2TeamBlue');
        if (btnP2B) btnP2B.innerText = t('teamBlueOpt');
        const btnP2R = document.getElementById('btnP2TeamRed');
        if (btnP2R) btnP2R.innerText = t('teamRedOpt');

        // Hotseat Modal Texts
        const hsTitle = document.getElementById('hotseatTitle');
        if (hsTitle) hsTitle.innerText = t('hotseatTransitionTitle');
        const hsDesc = document.getElementById('hotseatDesc');
        if (hsDesc) hsDesc.innerHTML = t('hotseatTransitionDesc');
        const hsBtn = document.getElementById('btnHotseatContinue');
        if (hsBtn) hsBtn.innerText = t('hotseatBtnContinue');

        const cpuLabel = document.querySelector('.cpu-select-label');
        if (cpuLabel) cpuLabel.innerText = t('cpuSelectLabel');

        const randomBtn = document.querySelector('#cpuSelectOptions [data-cpuchar="random"]');
        if (randomBtn) randomBtn.innerText = t('cpuOptRandom');

        const csBack = document.getElementById('btnCharSelectBack');
        if (csBack) csBack.innerText = t('btnCharSelectBack');

        const csStart = document.getElementById('btnStartBattle');
        if (csStart) csStart.innerText = t('btnStartBattle');

        // Team Battle Mode Section
        const tSecTitle = document.getElementById('teamModeSectionTitle');
        if (tSecTitle) tSecTitle.innerText = t('teamModeTitle');
        const tSecSub = document.getElementById('teamModeSectionSub');
        if (tSecSub) tSecSub.innerText = t('teamModeSub');

        const tBlueTitle = document.getElementById('teamBlueBoxTitle');
        if (tBlueTitle) tBlueTitle.innerText = t('labelTeamBlue');
        const tRedTitle = document.getElementById('teamRedBoxTitle');
        if (tRedTitle) tRedTitle.innerText = t('labelTeamRed');

        const p1 = document.getElementById('btnPreset1v1'); if (p1) p1.innerText = t('preset1v1');
        const p2 = document.getElementById('btnPreset2v2'); if (p2) p2.innerText = t('preset2v2');
        const p3 = document.getElementById('btnPreset3v3'); if (p3) p3.innerText = t('preset3v3');
        const p4 = document.getElementById('btnPreset4v4'); if (p4) p4.innerText = t('preset4v4');
        const p5 = document.getElementById('btnPreset5v5'); if (p5) p5.innerText = t('preset5v5');

        const bBtns = document.querySelectorAll('#blueTeamSizeSelectors .team-size-btn');
        bBtns.forEach(b => {
            const sz = parseInt(b.getAttribute('data-size'), 10);
            if (sz === 1) b.innerText = t('sizeBtnSolo');
            else b.innerText = t('sizeBtnPlusCpu', { size: sz, cpu: sz - 1 });
        });
        const rBtns = document.querySelectorAll('#redTeamSizeSelectors .team-size-btn');
        rBtns.forEach(b => {
            const sz = parseInt(b.getAttribute('data-size'), 10);
            b.innerText = t('sizeBtnCpuOnly', { size: sz });
        });

        this.updateTeamModeUI();
        this.updateMatchModeUI();

        // Update Tooltips on Character Mini-Buttons and CPU Selector Options
        const miniCharButtons = document.querySelectorAll('#p1CharSelectGrid .p-char-mini-btn, #p2CharSelectGrid .p-char-mini-btn, #cpuSelectOptions .cpu-opt-btn');
        if (miniCharButtons && miniCharButtons.length > 0) {
            miniCharButtons.forEach(btn => {
                const charId = btn.getAttribute('data-char') || btn.getAttribute('data-cpuchar');
                if (charId && charId !== 'random') {
                    const charObj = getCharacterById(charId);
                    if (charObj) {
                        btn.title = `${getCharName(charObj, lang)} - ${getCharTitle(charObj, lang)}`;
                    }
                }
            });
        }

        // Minimap
        const mmTitle = document.querySelector('.minimap-title');
        if (mmTitle) mmTitle.innerText = t('minimapTitle');

        // Queues & Logs
        const pQTitle = document.querySelector('.queue-row:first-child .queue-label span:first-child');
        if (pQTitle) pQTitle.innerText = t('playerQueueTitle');

        const cQTitle = document.querySelector('.queue-row:last-child .queue-label span:first-child');
        if (cQTitle) cQTitle.innerText = t('cpuQueueTitle');

        const cQSecret = document.querySelector('.queue-row:last-child .queue-label span:last-child');
        if (cQSecret) cQSecret.innerText = t('secretTag');

        const logTitle = document.querySelector('.log-title');
        if (logTitle) logTitle.innerText = t('combatLogTitle');

        // Hotkey bar labels
        const actLabel = document.querySelector('#actionButtonsGroup .hotkey-group-label');
        if (actLabel) actLabel.innerText = t('actionGroupLabel');

        const dirLabel = document.querySelector('#directionButtonsGroup .hotkey-group-label');
        if (dirLabel) dirLabel.innerText = t('directionGroupLabel');

        const btnUndo = document.getElementById('btnUndo');
        if (btnUndo) {
            btnUndo.innerHTML = t('btnUndo');
            btnUndo.title = t('tooltipBtnUndo');
        }

        const btnClear = document.getElementById('btnClear');
        if (btnClear) {
            btnClear.innerHTML = t('btnClear');
            btnClear.title = t('tooltipBtnClear');
        }

        const finishPathBtn = document.getElementById('btnFinishPath');
        if (finishPathBtn) finishPathBtn.innerText = t('btnFinishPath');

        // Control Panel Instruction & Badges
        const instBadge = document.querySelector('#controlPanelInstruction .inst-icon-badge');
        if (instBadge) instBadge.innerText = t('controlInstBadge');

        const instText = document.getElementById('controlPanelInstructionText');
        if (instText) instText.innerHTML = t('controlPanelInstruction');

        const actSubBadge = document.getElementById('actionSubBadge');
        if (actSubBadge) actSubBadge.innerText = t('actionSubBadge');

        const dirSubBadge = document.getElementById('directionSubBadge');
        if (dirSubBadge) dirSubBadge.innerText = t('directionSubBadge');

        // Direction buttons tooltips
        const dirTooltips = {
            btnKeyQ: { vi: 'Lên-Trái (Q / Num 7)', en: 'Up-Left (Q / Num 7)' },
            btnKeyW: { vi: 'Lên (W / Num 8)', en: 'Up (W / Num 8)' },
            btnKeyE: { vi: 'Lên-Phải (E / Num 9)', en: 'Up-Right (E / Num 9)' },
            btnKeyA: { vi: 'Trái (A / Num 4)', en: 'Left (A / Num 4)' },
            btnKeyS: { vi: 'Dưới (S / Num 2)', en: 'Down (S / Num 2)' },
            btnKeyD: { vi: 'Phải (D / Num 6)', en: 'Right (D / Num 6)' },
            btnKeyZ: { vi: 'Dưới-Trái (Z / Num 1)', en: 'Down-Left (Z / Num 1)' },
            btnKeyC: { vi: 'Dưới-Phải (C / Num 3)', en: 'Down-Right (C / Num 3)' }
        };
        for (const [btnId, labels] of Object.entries(dirTooltips)) {
            const btn = document.getElementById(btnId);
            if (btn) btn.title = lang === 'en' ? labels.en : labels.vi;
        }

        const pathSubtext = document.querySelector('.path-subtext');
        if (pathSubtext) pathSubtext.innerText = t('pathPlannerSubtext');
        const btnFinishPath = document.getElementById('btnFinishPath');
        if (btnFinishPath) btnFinishPath.innerText = t('btnFinishPath');

        // Rotate Device Overlay & Header Update Button
        const rotTitle = document.querySelector('#rotateDeviceNotice .rotate-title');
        if (rotTitle) rotTitle.innerText = t('rotateTitle');
        const rotDesc = document.querySelector('#rotateDeviceNotice .rotate-desc');
        if (rotDesc) rotDesc.innerText = t('rotateDesc');
        const btnUpdate = document.getElementById('btnHeaderUpdate');
        if (btnUpdate) btnUpdate.innerText = t('btnHeaderUpdate');

        // HUD Static Labels
        const curFacingLbl = document.getElementById('currentFacingLabel');
        if (curFacingLbl) curFacingLbl.innerText = t('currentFacing');
        const cpuStatLbl = document.getElementById('cpuStatusLabelText');
        if (cpuStatLbl) cpuStatLbl.innerText = t('cpuStatusLabel');

        // 2P Player Card Pills
        const p1Pill = document.querySelector('.p1-tag');
        if (p1Pill) p1Pill.innerText = `🎮 ${t('player1Label')}`;
        const p2Pill = document.querySelector('.p2-tag');
        if (p2Pill) p2Pill.innerText = `🎮 ${t('player2Label')}`;

        // Game Over Modal Static Labels & Buttons
        const mvpKillsLbl = document.getElementById('mvpKillsLabel');
        if (mvpKillsLbl) mvpKillsLbl.innerText = t('mvpStatKills');
        const mvpDmgLbl = document.getElementById('mvpDmgLabel');
        if (mvpDmgLbl) mvpDmgLbl.innerText = t('mvpStatDmg');
        const mvpScoreLbl = document.getElementById('mvpScoreLabel');
        if (mvpScoreLbl) mvpScoreLbl.innerText = t('mvpStatScore');
        const pmTitle = document.getElementById('postMatchTableTitle');
        if (pmTitle) pmTitle.innerText = t('lbFinalScoreboardTitle');
        const pmThChar = document.getElementById('postMatchThChar');
        if (pmThChar) pmThChar.innerText = t('lbColChar');
        const pmThTeam = document.getElementById('postMatchThTeam');
        if (pmThTeam) pmThTeam.innerText = t('lbColTeam');
        const pmThScore = document.getElementById('postMatchThScore');
        if (pmThScore) pmThScore.innerText = t('lbColScore');
        const restartBtn = document.getElementById('restartBtn');
        if (restartBtn) restartBtn.innerText = t('restartBtnText');
        const btnPmHof = document.getElementById('btnPostMatchHof');
        if (btnPmHof) btnPmHof.innerText = t('btnViewHof');
        const btnPmMenu = document.getElementById('btnPostMatchMenu');
        if (btnPmMenu) btnPmMenu.innerText = t('btnHeaderMenu');

        // In-Match Leaderboard Modal Static Labels
        const lbTitle = document.getElementById('lbModalTitle');
        if (lbTitle) lbTitle.innerText = t('lbModalTitle');
        const lbBlueBadge = document.getElementById('lbBlueBadgeText');
        if (lbBlueBadge) lbBlueBadge.innerText = t('lbBlueTeamBadge');
        const lbRedBadge = document.getElementById('lbRedBadgeText');
        if (lbRedBadge) lbRedBadge.innerText = t('lbRedTeamBadge');
        const lbBScoreLbl = document.getElementById('lbBlueScoreLabel');
        if (lbBScoreLbl) lbBScoreLbl.innerText = t('lbStatScore');
        const lbBAliveLbl = document.getElementById('lbBlueAliveLabel');
        if (lbBAliveLbl) lbBAliveLbl.innerText = t('lbStatAlive');
        const lbRScoreLbl = document.getElementById('lbRedScoreLabel');
        if (lbRScoreLbl) lbRScoreLbl.innerText = t('lbStatScore');
        const lbRAliveLbl = document.getElementById('lbRedAliveLabel');
        if (lbRAliveLbl) lbRAliveLbl.innerText = t('lbStatAlive');
        const lbTabAll = document.getElementById('lbTabAll');
        if (lbTabAll) lbTabAll.innerText = t('lbTabAll');
        const lbTabBlue = document.getElementById('lbTabBlue');
        if (lbTabBlue) lbTabBlue.innerText = t('lbTabBlue');
        const lbTabRed = document.getElementById('lbTabRed');
        if (lbTabRed) lbTabRed.innerText = t('lbTabRed');
        const thColChar = document.getElementById('thColChar');
        if (thColChar) thColChar.innerText = t('lbColChar');
        const thColTeam = document.getElementById('thColTeam');
        if (thColTeam) thColTeam.innerText = t('lbColTeam');
        const thColHp = document.getElementById('thColHp');
        if (thColHp) thColHp.innerText = t('lbColHp');
        const colHeaderHill = document.getElementById('colHeaderHill');
        if (colHeaderHill) colHeaderHill.innerText = t('lbColHill');
        const thColScore = document.getElementById('thColScore');
        if (thColScore) thColScore.innerText = t('lbColScore');
        const lbFooterHint = document.getElementById('lbFooterHint');
        if (lbFooterHint) lbFooterHint.innerText = `💡 ${t('lbHint')}`;
        const btnResumeMatch = document.getElementById('btnResumeMatch');
        if (btnResumeMatch) btnResumeMatch.innerText = t('lbResumeMatch');

        // Hall of Fame Modal Static Labels
        const hofBadgeEl = document.getElementById('hofBadge') || document.querySelector('#hallOfFameModal .lb-badge');
        if (hofBadgeEl) hofBadgeEl.innerText = t('hofBadge');
        const hofModalTitle = document.getElementById('hofModalTitle');
        if (hofModalTitle) hofModalTitle.innerText = t('hofTitle');
        const hofModalSub = document.getElementById('hofModalSub');
        if (hofModalSub) hofModalSub.innerText = t('hofSub');
        const hofHighScoreLbl = document.getElementById('hofHighScoreLabel');
        if (hofHighScoreLbl) hofHighScoreLbl.innerText = t('hofHighScore');
        const hofMaxKillsLbl = document.getElementById('hofMaxKillsLabel');
        if (hofMaxKillsLbl) hofMaxKillsLbl.innerText = t('hofMaxKills');
        const hofMaxDmgLbl = document.getElementById('hofMaxDmgLabel');
        if (hofMaxDmgLbl) hofMaxDmgLbl.innerText = t('hofMaxDmg');
        const hofHistTitle = document.getElementById('hofHistoryTitle');
        if (hofHistTitle) hofHistTitle.innerText = t('hofHistoryTitle');
        const btnClearHof = document.getElementById('btnClearHofHistory');
        if (btnClearHof) btnClearHof.innerText = t('hofClearHistory');
        const hofThTime = document.getElementById('hofThTime');
        if (hofThTime) hofThTime.innerText = t('hofColTime');
        const hofThMode = document.getElementById('hofThMode');
        if (hofThMode) hofThMode.innerText = t('hofColMode');
        const hofThChar = document.getElementById('hofThChar');
        if (hofThChar) hofThChar.innerText = t('hofColChar');
        const hofThResult = document.getElementById('hofThResult');
        if (hofThResult) hofThResult.innerText = t('hofColResult');
        const hofThKD = document.getElementById('hofThKD');
        if (hofThKD) hofThKD.innerText = t('hofColKD');
        const hofThDmg = document.getElementById('hofThDmg');
        if (hofThDmg) hofThDmg.innerText = t('hofColDmg');
        const hofThScore = document.getElementById('hofThScore');
        if (hofThScore) hofThScore.innerText = t('hofColScore');
        const hofThMvp = document.getElementById('hofThMvp');
        if (hofThMvp) hofThMvp.innerText = t('hofColMvp');
        const btnCloseHofBtn = document.getElementById('btnCloseHofBtn');
        if (btnCloseHofBtn) btnCloseHofBtn.innerText = t('hofClose');

        // Additional UI Button and Table Header Tooltips
        const btnCloseLb = document.getElementById('btnCloseLeaderboard');
        if (btnCloseLb) btnCloseLb.title = t('tooltipCloseLeaderboard');
        const btnCloseHof = document.getElementById('btnCloseHof');
        if (btnCloseHof) btnCloseHof.title = t('tooltipCloseHof');
        if (btnClearHof) btnClearHof.title = t('tooltipClearHofHistory');
        const btnCloseGuideX = document.getElementById('btnCloseGuideX');
        if (btnCloseGuideX) btnCloseGuideX.title = t('tooltipCloseGuide');
        if (btnUpdate) btnUpdate.title = t('tooltipHeaderUpdate');

        const thKills = document.getElementById('thColKills');
        if (thKills) thKills.title = t('tooltipThKills');
        const thDeaths = document.getElementById('thColDeaths');
        if (thDeaths) thDeaths.title = t('tooltipThDeaths');
        const thDmg = document.getElementById('thColDmg');
        if (thDmg) thDmg.title = t('tooltipThDmg');
        const thDef = document.getElementById('thColDef');
        if (thDef) thDef.title = t('tooltipThDef');
        const thHeal = document.getElementById('thColHeal');
        if (thHeal) thHeal.title = t('tooltipThHeal');
        if (colHeaderHill) colHeaderHill.title = t('tooltipThHill');
        if (thColScore) thColScore.title = t('tooltipThScore');

        // Initial Combat Log Update if still at start
        const logContent = document.getElementById('combatLog');
        if (logContent && (!this.turn || (this.turn === 1 && this.phase === 'PLANNING' && (!logContent.children || logContent.children.length <= 1)))) {
            const entry = logContent.querySelector ? logContent.querySelector('.log-entry.system') : null;
            if (entry) entry.innerText = t('combatLogInit');
        }

        // Re-render dynamic elements
        this.initCharacterSelectUI();
        this.renderHowToPlayUI();
        this.updateHUD();
        this.updateQueueDisplay();
        this.updateSkillButtons();
        if (this.isLeaderboardOpen) this.renderInMatchLeaderboard();
        if (this.isHofOpen) this.renderHallOfFame();
    }

    renderHowToPlayUI() {
        const guideModal = document.querySelector('#howToPlayScreen .guide-modal-container');
        if (!guideModal) return;

        const lang = this.lang || 'vi';
        const chars = getAllCharacters().filter(c => c.isUnlocked);

        const charCardsHtml = chars.map(c => {
            const cName = getCharName(c, lang);
            const cSub = `${getCharTitle(c, lang)} • ${c.maxHp} HP`;
            const skillsList = c.skills.map(s => {
                const sName = getSkillName(s, lang);
                const sDesc = getSkillDesc(s, lang);
                return `<li><b>${s.icon} ${sName}:</b> ${sDesc}</li>`;
            }).join('');

            return `
                <div class="cg-card">
                    <div class="cg-header">
                        <span class="cg-avatar">${c.avatar}</span>
                        <div>
                            <h4 class="cg-name" style="color: ${c.themeColor};">${cName.toUpperCase()}</h4>
                            <div class="cg-sub">${cSub}</div>
                        </div>
                    </div>
                    <ul class="cg-skills">
                        ${skillsList}
                    </ul>
                </div>
            `;
        }).join('');

        guideModal.innerHTML = `
            <div class="guide-header">
                <div class="guide-header-text">
                    <h2>${t('guideMainTitle')}</h2>
                    <p>${t('guideMainSub')}</p>
                </div>
                <button id="btnCloseGuideX" class="guide-close-btn" title="Close">✕</button>
            </div>

            <div class="guide-scroll-body">
                <!-- Section 1 -->
                <div class="guide-section-card">
                    <div class="section-card-title">
                        <span class="sec-icon">⚡</span>
                        <span>${t('guideSec1Title')}</span>
                    </div>
                    <div class="section-card-body">
                        <p>${t('guideSec1Desc')}</p>
                        <div class="guide-steps-grid">
                            <div class="g-step-box">
                                <span class="g-step-badge">${lang === 'en' ? 'Phase 1' : 'Pha 1'}</span>
                                <b>${t('guideSec1Phase1Title')}</b>
                                <span>${t('guideSec1Phase1Desc')}</span>
                            </div>
                            <div class="g-step-box">
                                <span class="g-step-badge">${lang === 'en' ? 'Phase 2' : 'Pha 2'}</span>
                                <b>${t('guideSec1Phase2Title')}</b>
                                <span>${t('guideSec1Phase2Desc')}</span>
                            </div>
                            <div class="g-step-box">
                                <span class="g-step-badge">${lang === 'en' ? 'Phase 3' : 'Pha 3'}</span>
                                <b>${t('guideSec1Phase3Title')}</b>
                                <span>${t('guideSec1Phase3Desc')}</span>
                            </div>
                        </div>
                        <div class="guide-callout tip">
                            ${t('guideSec1Tip')}
                        </div>
                    </div>
                </div>

                <!-- Section 2 -->
                <div class="guide-section-card">
                    <div class="section-card-title">
                        <span class="sec-icon">👟</span>
                        <span>${t('guideSec2Title')}</span>
                    </div>
                    <div class="section-card-body">
                        <p>${t('guideSec2Desc')}</p>
                        <ul class="guide-list">
                            <li>${t('guideSec2Li1')}</li>
                            <li>${t('guideSec2Li2')}</li>
                            <li>${t('guideSec2Li3')}</li>
                            <li>${t('guideSec2Li4')}</li>
                        </ul>
                    </div>
                </div>

                <!-- Section 3 -->
                <div class="guide-section-card">
                    <div class="section-card-title">
                        <span class="sec-icon">⌨️</span>
                        <span>${t('guideSec3Title')}</span>
                    </div>
                    <div class="section-card-body">
                        <div class="hotkey-table-grid">
                            <div class="hk-row"><span class="hk-key">[1]</span><span class="hk-desc">${t('hk1Desc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[2]</span><span class="hk-desc">${t('hk2Desc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[3]</span><span class="hk-desc">${t('hk3Desc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[4]</span><span class="hk-desc">${t('hk4Desc')}</span></div>
                            <div class="hk-row"><span class="hk-key">WASD / QEZC</span><span class="hk-desc">${t('hkDirDesc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[Space]</span><span class="hk-desc">${t('hkSpaceDesc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[⌫ Backspace]</span><span class="hk-desc">${t('hkBackDesc')}</span></div>
                            <div class="hk-row"><span class="hk-key">[Esc]</span><span class="hk-desc">${t('hkEscDesc')}</span></div>
                        </div>
                        <div class="guide-callout tip" style="margin-top: 10px;">
                            ${t('guideSec3TipText')}
                        </div>
                    </div>
                </div>

                <!-- Section 4 -->
                <div class="guide-section-card">
                    <div class="section-card-title">
                        <span class="sec-icon">👥</span>
                        <span>${t('guideSec4Title')}</span>
                    </div>
                    <div class="section-card-body">
                        <div class="char-guide-cards">
                            ${charCardsHtml}
                        </div>
                    </div>
                </div>

                <!-- Section 5 -->
                <div class="guide-section-card">
                    <div class="section-card-title">
                        <span class="sec-icon">🛡️</span>
                        <span>${t('guideSec5Title')}</span>
                    </div>
                    <div class="section-card-body">
                        <div class="strategy-tips-grid">
                            <div class="tip-card">
                                <b>${t('tip1Title')}</b>
                                <span>${t('tip1Desc')}</span>
                            </div>
                            <div class="tip-card">
                                <b>${t('tip2Title')}</b>
                                <span>${t('tip2Desc')}</span>
                            </div>
                            <div class="tip-card">
                                <b>${t('tip3Title')}</b>
                                <span>${t('tip3Desc')}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="guide-footer">
                <button id="btnGuideBack" class="guide-btn-secondary">${t('btnGuideBack')}</button>
                <button id="btnGuidePlay" class="guide-btn-primary">${t('btnGuidePlay')}</button>
            </div>
        `;

        // Re-bind modal buttons
        const closeX = document.getElementById('btnCloseGuideX');
        if (closeX) closeX.addEventListener('click', () => this.closeHowToPlayScreen());

        const guideBack = document.getElementById('btnGuideBack');
        if (guideBack) guideBack.addEventListener('click', () => this.closeHowToPlayScreen());

        const guidePlay = document.getElementById('btnGuidePlay');
        if (guidePlay) guidePlay.addEventListener('click', () => this.showCharSelectScreen());
    }

    applyCpuCharacter(cpuChoice = 'random') {
        const unlockedChars = CHARACTERS_DATABASE.filter(c => c.isUnlocked);
        let chosenChar = null;
        if (cpuChoice && cpuChoice !== 'random') {
            chosenChar = getCharacterById(cpuChoice);
        }
        if (!chosenChar || !chosenChar.isUnlocked) {
            chosenChar = unlockedChars[Math.floor(Math.random() * unlockedChars.length)];
        }
        this.cpuCharacter = chosenChar;
        this.setupTeams();

        const cpuBadge = document.getElementById('cpuNameBadge');
        if (cpuBadge) {
            cpuBadge.innerText = `${chosenChar.avatar} ${getCharName(chosenChar, this.lang).toUpperCase()} [CPU]`;
            cpuBadge.style.color = chosenChar.themeColor;
        }
        this.updateTeamRosterPreviews();
    }

    applySelectedCharacter() {
        const char = this.selectedCharacter || getCharacterById('trooper');
        this.selectedCharacter = char;
        this.setupTeams();
        this.groundHazards = [];
        this.fireZones = [];
        this.sentries = [];
        this.teleporters = [];
        this.activeHookTethers = [];

        const pBadge = document.getElementById('playerNameBadge');
        if (pBadge) {
            pBadge.innerText = `${getCharName(char, this.lang).toUpperCase()} [${this.lang === 'en' ? 'YOU' : 'BẠN'}]`;
        }
        this.updateSkillButtons();
        this.updateTeamRosterPreviews();
    }

    getActivePlanningUnit() {
        if (!this.isTwoPlayerMode) return this.player;
        return (this.activePlanningPlayer === 1) ? this.p1Unit : this.p2Unit;
    }

    getActivePlanningQueue() {
        if (!this.isTwoPlayerMode) return this.playerQueue;
        return (this.activePlanningPlayer === 1) ? this.p1Queue : this.p2Queue;
    }

    confirmP1QueueAndTransitionToP2() {
        if (this.phase !== 'PLANNING' || this.p1Queue.length !== 4) return;
        this.cancelPathPlanning();
        this.p1Unit.queue = [...this.p1Queue];
        if (window.soundCtrl) window.soundCtrl.playCommit();

        // Ẩn hiển thị hàng đợi của P1 để bảo mật (Anti-Peeking)
        for (let i = 0; i < 4; i++) {
            const slot = document.getElementById(`p-slot-${i}`);
            if (slot) {
                slot.className = 'queue-slot filled';
                slot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${t('secretLockedTitle')}</span>`;
            }
        }

        // Mở Hotseat modal
        this.isHotseatModalOpen = true;
        const modal = document.getElementById('hotseatTransitionModal');
        const p2Name = document.getElementById('hotseatNextPlayerName');
        const p2Team = document.getElementById('hotseatNextPlayerTeam');
        const p2Avatar = document.getElementById('hotseatNextPlayerAvatar');
        if (p2Name && this.p2Unit) p2Name.innerText = `${this.lang === 'en' ? 'Player 2' : 'Người Chơi 2'} [${getCharName(this.p2Unit.character, this.lang)}]`;
        if (p2Team && this.p2Unit) p2Team.innerText = this.p2Unit.team === 'BLUE' ? (this.lang === 'en' ? '🔵 Blue Team' : '🔵 Đội Xanh') : (this.lang === 'en' ? '🔴 Red Team' : '🔴 Đội Đỏ');
        if (p2Avatar && this.p2Unit) p2Avatar.innerText = this.p2Unit.avatar;
        if (modal) modal.style.display = 'flex';
    }

    continueToP2Planning() {
        this.isHotseatModalOpen = false;
        const modal = document.getElementById('hotseatTransitionModal');
        if (modal) modal.style.display = 'none';
        if (window.soundCtrl) window.soundCtrl.playSelect();

        this.activePlanningPlayer = 2;
        this.selectedCharacter = this.p2Unit.character;
        this.cooldowns = this.p2Unit.cooldowns;
        this.skillAmmo = this.p2Unit.skillAmmo;
        this.playerBuffs = this.p2Unit.buffs;
        this.currentSelectedDir = this.p2Unit.dir || (this.p2Unit.team === 'BLUE' ? 'RIGHT' : 'LEFT');
        this.highlightSelectedDirButton();

        // Nếu P2 hy sinh trong KOTH, tự động điền lệnh chờ hồi sinh
        if (this.gameMode === 'KOTH' && this.p2Unit.hp <= 0) {
            const respawnLabel = t('respawningTag', { turns: this.p2Unit.respawnTurns });
            this.p2Queue = [
                { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' }
            ];
        }

        this.updateSkillButtons();
        this.updateQueueDisplay();
        this.updateHUD();
        this.addCombatLog(this.lang === 'en' ? `🎮 [P2] ${this.p2Unit.name} begins planning 4 actions!` : `🎮 [P2] ${this.p2Unit.name} bắt đầu lên 4 lệnh!`, 'system');
    }

    isUnitScoped(unit, queue = null) {
        if (!unit) return false;
        let scoped = Boolean(unit.isScoped);
        const q = queue || (this.getActivePlanningQueue ? this.getActivePlanningQueue() : []);
        for (const act of q) {
            if (act.type === 'SNIPER_SCOPE' || act.type === 'TANK_SCOPE') {
                scoped = true;
            } else if (act.type === 'SNIPER_SHOT' || act.type === 'TANK_SHOT') {
                scoped = false;
            }
        }
        return scoped;
    }

    updateSkillButtons() {
        const unit = this.getActivePlanningUnit();
        if (!unit) return;
        const char = unit.character;
        const currentQueue = this.getActivePlanningQueue();
        const skillContainer = document.getElementById('dynamicSkillButtons');
        if (!skillContainer) return;

        if (this.gameMode === 'KOTH' && unit && unit.hp <= 0) {
            skillContainer.innerHTML = `
                <div style="padding: 10px; color: #f43f5e; font-weight: bold; background: rgba(244,63,94,0.12); border: 1px dashed #f43f5e; border-radius: 6px; width: 100%; text-align: center;">
                    ${t('respawnNoticeText', { turns: unit.respawnTurns })}
                </div>
            `;
            return;
        }

        const isScoped = this.isUnitScoped(unit, currentQueue);

        skillContainer.innerHTML = char.skills.map((s, idx) => {
            const cd = unit.cooldowns[s.id] || 0;
            const isCooldown = cd > 0;
            const isTethered = this.activeHookTethers && this.activeHookTethers.some(t => t.skillId === s.id && (t.sourceUnit === unit || t.source === 'PLAYER'));
            const isAdrenalineActive = s.id === 'HOOKMAN_ADRENALINE' && unit.buffs && unit.buffs.adrenaline && unit.buffs.adrenaline.turnsLeft > 0;
            const isCigaretteActive = s.id === 'SMOKE_CIGARETTE' && unit.buffs && unit.buffs.cigarette && unit.buffs.cigarette.turnsLeft > 0;

            let sName = (this.lang === 'en' && s.name_en) ? s.name_en : s.name;
            let sIcon = s.icon;
            let sDesc = (this.lang === 'en' && s.desc_en) ? s.desc_en : s.desc;
            let sColor = s.color;
            let statusLabel = '';
            let isAmmoEmpty = false;

            if (s.type === 'SNIPER_WEAPON') {
                if (isScoped) {
                    sName = this.lang === 'en' ? 'Fire Sniper' : 'Bắn Súng Tỉa';
                    sIcon = '💥';
                    sDesc = this.lang === 'en' ? '2nd tap: Fire sniper shot (25-50 DMG scales with distance)' : 'Lần bấm 2: Bắn phát súng tỉa (25-50 Sát thương, cự ly càng xa DMG càng cao)';
                    sColor = '#6366f1';
                    statusLabel = `<span class="cd-tag" style="background:#6366f1; color:white;">[${this.lang === 'en' ? 'SCOPED' : 'ĐÃ NGẮM'}]</span>`;
                } else {
                    sName = this.lang === 'en' ? 'Aim / Scope' : 'Ngắm Bắn';
                    sIcon = '🎯';
                    sDesc = this.lang === 'en' ? '1st tap: Scope in mode (lose 1 move step on movement)' : 'Lần bấm 1: Vào chế độ ngắm bắn (giảm 1 bước di chuyển mỗi lần chọn di chuyển)';
                }
            } else if (s.type === 'TANK_WEAPON') {
                if (isScoped) {
                    sName = this.lang === 'en' ? 'Fire Tank Cannon' : 'Bắn Nòng Xe Tăng';
                    sIcon = '💥';
                    sDesc = this.lang === 'en' ? '2nd tap: Fire cannon (15-45 DMG scales with distance, 3x3 blast 10 DMG)' : 'Lần bấm 2: Bắn đại bác (15-45 Sát thương theo cự ly, nổ 3x3 gây 10 DMG xung quanh trừ tâm)';
                    sColor = '#e11d48';
                    statusLabel = `<span class="cd-tag" style="background:#e11d48; color:white;">[${this.lang === 'en' ? 'SCOPED' : 'ĐÃ NGẮM'}]</span>`;
                } else {
                    sName = this.lang === 'en' ? 'Scope In' : 'Ngắm Nòng Pháo';
                    sIcon = '🎯';
                    sDesc = this.lang === 'en' ? '1st tap: Scope in mode (lose 1 move step on movement)' : 'Lần bấm 1: Vào chế độ ngắm bắn (giảm 1 bước di chuyển mỗi lần chọn di chuyển)';
                }
            } else if ((s.id === 'SNIPER_MOVE' || s.id === 'BOOM_MOVE') && isScoped) {
                statusLabel = `<span class="cd-tag" style="background:#818cf8; color:white;">[${this.lang === 'en' ? '1 STEP' : '1 BƯỚC'}]</span>`;
            } else if (s.id === 'SNIPER_DESTRUCTIVE') {
                const isDestrActive = (unit.buffs && unit.buffs.destructiveShot) || currentQueue.some(act => act.skillId === 'SNIPER_DESTRUCTIVE');
                if (isDestrActive && !isCooldown) {
                    statusLabel = `<span class="cd-tag" style="background:#ec4899; color:white;">[${this.lang === 'en' ? '+30% PIERCE' : '+30% XUYÊN'}]</span>`;
                }
            } else if (s.id === 'SNIPER_THERMAL') {
                const isThermalActive = (unit.buffs && unit.buffs.thermalVision && unit.buffs.thermalVision.active) || currentQueue.some(act => act.skillId === 'SNIPER_THERMAL');
                if (isThermalActive && !isCooldown) {
                    statusLabel = `<span class="cd-tag" style="background:#06b6d4; color:white;">[${this.lang === 'en' ? '+1 RANGE' : '+1 TẦM'}]</span>`;
                }
            } else if (s.id === 'BOOM_CHAOS_SHOT') {
                const isChaosActive = (unit.buffs && unit.buffs.chaosShot) || currentQueue.some(act => act.skillId === 'BOOM_CHAOS_SHOT');
                if (isChaosActive && !isCooldown) {
                    statusLabel = `<span class="cd-tag" style="background:#a855f7; color:white;">[+30% & 5x5]</span>`;
                }
            }

            if (s.maxAmmo) {
                const totalAmmo = unit.skillAmmo[s.id] !== undefined ? unit.skillAmmo[s.id] : s.maxAmmo;
                const queuedCount = currentQueue.filter(act => act.skillId === s.id).length;
                const availableAmmo = Math.max(0, totalAmmo - queuedCount);
                if (isCooldown) {
                    statusLabel = `<span class="cd-tag">[${this.lang === 'en' ? `CD: ${cd}T` : `Hồi: ${cd}L`}]</span>`;
                } else {
                    const ammoText = s.type === 'RECT_SLASH' ? (this.lang === 'en' ? 'USE' : 'DÙNG') : (this.lang === 'en' ? 'AMMO' : 'ĐẠN');
                    const tagBg = availableAmmo > 0 ? (sColor || '#f97316') : '#ef4444';
                    statusLabel = `<span class="cd-tag" style="background:${tagBg}; color:white;">[${ammoText}: ${availableAmmo}/${s.maxAmmo}]</span>`;
                }
                if (availableAmmo <= 0) {
                    isAmmoEmpty = true;
                }
            } else if (isTethered) {
                statusLabel = `<span class="cd-tag" style="background:#ef4444; color:white;">[${this.lang === 'en' ? 'TETHERED' : 'DÂY CĂNG'}]</span>`;
            } else if (isAdrenalineActive) {
                statusLabel = `<span class="cd-tag" style="background:#10b981; color:white;">[${this.lang === 'en' ? `+20% DMG: ${unit.buffs.adrenaline.turnsLeft}T` : `+20% DMG: ${unit.buffs.adrenaline.turnsLeft}L`}]</span>`;
            } else if (isCigaretteActive) {
                statusLabel = `<span class="cd-tag" style="background:#eab308; color:black; font-weight:bold;">[${this.lang === 'en' ? `SMOKING: ${unit.buffs.cigarette.turnsLeft}T` : `ĐANG HÚT: ${unit.buffs.cigarette.turnsLeft}L`}]</span>`;
            } else if (isCooldown) {
                statusLabel = `<span class="cd-tag">[${this.lang === 'en' ? `CD: ${cd}T` : `Hồi: ${cd}L`}]</span>`;
            }

            const isBlocked = isCooldown || isTethered || isCigaretteActive || isAmmoEmpty;
            const isSkill2Plus = idx >= 1;
            const dirReminder = isSkill2Plus ? (this.lang === 'en' ? ' • [Tip: Select direction first]' : ' • [Lưu ý: Phải chọn hướng trước]') : '';

            const cdTooltip = isCooldown ? (this.lang === 'en' ? ` (Cooldown: ${cd} turns)` : ` (Đang hồi ${cd} lượt)`) : '';
            const tetherTooltip = isTethered ? (this.lang === 'en' ? ' (Hook tether attached to target, will pull 2 tiles next turn end)' : ' (Dây móc đang găm vào đối thủ, cuối lượt sau sẽ giật 2 ô)') : '';

            return `
                <button class="key-badge ${isBlocked ? 'cooldown' : ''}" 
                        data-skill-idx="${idx}" 
                        style="border-color: ${isBlocked ? '#ef4444' : (sColor || '#475569')}" 
                        title="${sDesc}${dirReminder}${cdTooltip}${tetherTooltip}">
                    <b>[${idx + 1}]</b> ${sIcon} ${sName}${statusLabel}
                </button>
            `;
        }).join('');

        skillContainer.querySelectorAll('button[data-skill-idx]').forEach(btn => {
            btn.addEventListener('click', () => {
                const idx = parseInt(btn.getAttribute('data-skill-idx'), 10);
                this.addSkillToQueue(idx);
            });
        });
    }

    bindEvents() {
        window.addEventListener('keydown', (e) => this.handleKeyDown(e));

        const btnHdrLb = document.getElementById('btnHeaderLeaderboard');
        if (btnHdrLb) btnHdrLb.addEventListener('click', () => this.toggleInMatchLeaderboard());

        const btnHudLb = document.getElementById('btnHudLeaderboard');
        if (btnHudLb) btnHudLb.addEventListener('click', () => this.toggleInMatchLeaderboard());

        const btnCloseLb = document.getElementById('btnCloseLeaderboard');
        if (btnCloseLb) btnCloseLb.addEventListener('click', () => this.closeInMatchLeaderboard());

        const btnResume = document.getElementById('btnResumeMatch');
        if (btnResume) btnResume.addEventListener('click', () => this.closeInMatchLeaderboard());

        const tabAll = document.getElementById('lbTabAll');
        if (tabAll) tabAll.addEventListener('click', () => this.renderInMatchLeaderboard('all'));

        const tabBlue = document.getElementById('lbTabBlue');
        if (tabBlue) tabBlue.addEventListener('click', () => this.renderInMatchLeaderboard('BLUE'));

        const tabRed = document.getElementById('lbTabRed');
        if (tabRed) tabRed.addEventListener('click', () => this.renderInMatchLeaderboard('RED'));

        const btnCloseHof = document.getElementById('btnCloseHof');
        if (btnCloseHof) btnCloseHof.addEventListener('click', () => this.closeHallOfFame());

        const btnCloseHofBtn = document.getElementById('btnCloseHofBtn');
        if (btnCloseHofBtn) btnCloseHofBtn.addEventListener('click', () => this.closeHallOfFame());

        const btnClearHof = document.getElementById('btnClearHofHistory');
        if (btnClearHof) btnClearHof.addEventListener('click', () => this.clearHallOfFameHistory());

        const btnPmHof = document.getElementById('btnPostMatchHof');
        if (btnPmHof) btnPmHof.addEventListener('click', () => this.openHallOfFame());

        const btnPmMenu = document.getElementById('btnPostMatchMenu');
        if (btnPmMenu) btnPmMenu.addEventListener('click', () => this.showMainMenuScreen());

        document.getElementById('btnOpenCharSelect').addEventListener('click', () => {
            this.showCharSelectScreen();
        });

        // 8 Nút chọn hướng trên giao diện
        document.querySelectorAll('.key-badge[data-key]').forEach(btn => {
            btn.addEventListener('click', () => {
                const key = btn.getAttribute('data-key');
                this.handleDirectionInput(key);
            });
        });

        document.getElementById('btnUndo').addEventListener('click', () => this.undoAction());
        document.getElementById('btnClear').addEventListener('click', () => this.clearQueue());
        document.getElementById('btnCommit').addEventListener('click', () => {
            if (this.isTwoPlayerMode && this.phase === 'PLANNING') {
                if (this.activePlanningPlayer === 1 && this.p1Queue.length === 4) {
                    this.confirmP1QueueAndTransitionToP2();
                } else if (this.activePlanningPlayer === 2 && this.p2Queue.length === 4) {
                    this.commitTurn();
                }
            } else {
                this.commitTurn();
            }
        });
        document.getElementById('restartBtn').addEventListener('click', () => this.restartGame());
        document.getElementById('btnFinishPath').addEventListener('click', () => this.finishActivePath());

        const soundBtn = document.getElementById('soundToggleBtn');
        soundBtn.addEventListener('click', () => {
            if (window.soundCtrl) {
                window.soundCtrl.enabled = !window.soundCtrl.enabled;
                soundBtn.innerText = window.soundCtrl.enabled ? t('soundOn') : t('soundOff');
            }
        });

        // Mobile Touch Pan / Drag trên Canvas (cho phép vuốt xem bản đồ trên điện thoại)
        let isTouchingCanvas = false;
        let touchStartX = 0;
        let cameraStartX = 0;
        if (this.canvas) {
            this.canvas.addEventListener('touchstart', (e) => {
                if (e.touches && e.touches.length === 1) {
                    isTouchingCanvas = true;
                    touchStartX = e.touches[0].clientX;
                    cameraStartX = this.cameraX;
                    if (window.soundCtrl) window.soundCtrl.init();
                }
            }, { passive: true });
        }

        window.addEventListener('touchmove', (e) => {
            if (isTouchingCanvas && e.touches && e.touches.length === 1 && this.canvas) {
                const diffX = e.touches[0].clientX - touchStartX;
                const totalWorldWidth = GRID_COLS * CELL_SIZE;
                this.targetCameraX = Math.max(0, Math.min(totalWorldWidth - this.canvas.width, cameraStartX - diffX));
                this.cameraX = this.targetCameraX;
            }
        }, { passive: true });

        window.addEventListener('touchend', () => {
            isTouchingCanvas = false;
        }, { passive: true });

        // Mobile Minimap Tap: Nhấn vào minimap để nhảy camera tức thì
        const minimap = document.getElementById('minimapCanvas');
        if (minimap && this.canvas) {
            const handleMinimapJump = (clientX) => {
                const rect = minimap.getBoundingClientRect();
                const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
                const totalWorldWidth = GRID_COLS * CELL_SIZE;
                this.targetCameraX = Math.max(0, Math.min(totalWorldWidth - this.canvas.width, ratio * totalWorldWidth - this.canvas.width / 2));
                this.cameraX = this.targetCameraX;
            };
            minimap.addEventListener('click', (e) => handleMinimapJump(e.clientX));
            minimap.addEventListener('touchstart', (e) => {
                if (e.touches && e.touches.length > 0) handleMinimapJump(e.touches[0].clientX);
            }, { passive: true });
        }

        // Tự động mở khóa Web Audio trên Android Chrome & iOS Safari sau tương tác đầu tiên
        window.addEventListener('touchstart', function unlockAudio() {
            if (window.soundCtrl) window.soundCtrl.init();
            window.removeEventListener('touchstart', unlockAudio);
        }, { passive: true });
    }

    // --- Tính toán vị trí mô phỏng tiếp theo trong hàng đợi hiện tại ---
    getSimulatedPlayerPos() {
        const unit = this.getActivePlanningUnit();
        const currentQueue = this.getActivePlanningQueue();
        let sx = unit ? unit.x : this.player.x;
        let sy = unit ? unit.y : this.player.y;
        for (const act of currentQueue) {
            if (act.type === 'PATH_MOVE' && act.path && act.path.length > 0) {
                const lastNode = act.path[act.path.length - 1];
                sx = lastNode.x;
                sy = lastNode.y;
            } else if (act.type === 'DASH') {
                const d = DIRECTIONS[act.dir];
                sx = Math.max(0, Math.min(GRID_COLS - 1, sx + d.dx * (act.range || 2)));
                sy = Math.max(0, Math.min(GRID_ROWS - 1, sy + d.dy * (act.range || 2)));
            } else if (act.type === 'LEAP') {
                const d = DIRECTIONS[act.dir];
                let lx = sx + d.dx * (act.range || 3);
                let ly = sy + d.dy * (act.range || 3);
                lx = Math.max(0, Math.min(GRID_COLS - 1, lx));
                ly = Math.max(0, Math.min(GRID_ROWS - 1, ly));
                const allLiving = [...(this.blueTeam || []), ...(this.redTeam || [])].filter(u => u !== unit && u.hp > 0);
                const hasEnemy = allLiving.some(u => u.x === lx && u.y === ly);
                const hasHazard = this.groundHazards.some(h => h.x === lx && h.y === ly);
                if (hasEnemy || hasHazard) {
                    lx = Math.max(0, Math.min(GRID_COLS - 1, lx + d.dx * (act.leapExtra || 2)));
                    ly = Math.max(0, Math.min(GRID_ROWS - 1, ly + d.dy * (act.leapExtra || 2)));
                }
                sx = lx;
                sy = ly;
            }
        }
        return { x: sx, y: sy };
    }

    getPathStartPos() {
        return this.getSimulatedPlayerPos();
    }

    // --- Xử lý vẽ Lộ trình Di chuyển (Path Movement) ---
    startPathPlanning() {
        if (this.phase !== 'PLANNING') return;
        const unit = this.getActivePlanningUnit();
        if (this.gameMode === 'KOTH' && unit && unit.hp <= 0) return;
        const currentQueue = this.getActivePlanningQueue();
        if (currentQueue.length >= 4) {
            this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Hàng đợi đã đầy 4 lệnh! Nhấn [SPACE] để thực thi.', 'system');
            return;
        }

        this.isBuildingPath = true;
        this.activePath = [];
        const isCigaretteActive = (unit && unit.buffs && unit.buffs.cigarette && unit.buffs.cigarette.turnsLeft > 0) ||
                                  currentQueue.some(act => act.skillId === 'SMOKE_CIGARETTE');
        const isScoped = this.isUnitScoped(unit, currentQueue);
        let maxSteps = ((unit && unit.character.moveBudget) || 2) + (isCigaretteActive ? 1 : 0);
        if (isScoped) {
            maxSteps = Math.max(1, maxSteps - 1);
        }
        this.activePathMaxSteps = maxSteps;

        this.updatePathNoticeUI();
        if (window.soundCtrl) window.soundCtrl.playSelect();
        const scopedNote = isScoped ? (this.lang === 'en' ? ' (Scoped: -1 step)' : ' (Đang ngắm: -1 bước)') : '';
        this.addCombatLog(this.lang === 'en' ? `Route planning (max ${this.activePathMaxSteps} steps${scopedNote}): Press direction keys or click arrows to add steps!` : `Vẽ lộ trình (tối đa ${this.activePathMaxSteps} bước${scopedNote}): Nhấn phím hướng để nối bước!`, 'system');
    }

    updatePathNoticeUI() {
        const notice = document.getElementById('pathPlannerNotice');
        const countText = document.getElementById('pathStepCount');
        const subtext = document.querySelector('.path-subtext');
        const finishBtn = document.getElementById('btnFinishPath');
        if (this.isBuildingPath) {
            notice.style.display = 'flex';
            if (countText) countText.innerText = typeof t === 'function' ? t('pathPlannerNotice', { steps: this.activePath.length, maxSteps: this.activePathMaxSteps }) : (this.lang === 'en' ? `Drawing Route: ${this.activePath.length} / ${this.activePathMaxSteps} steps` : `Đang vẽ Lộ trình: ${this.activePath.length} / ${this.activePathMaxSteps} bước`);
            if (subtext && typeof t === 'function') subtext.innerText = t('pathPlannerSubtext');
            if (finishBtn && typeof t === 'function') finishBtn.innerText = t('btnFinishPath');
        } else {
            notice.style.display = 'none';
        }
    }

    appendStepToActivePath(dirKey) {
        if (!this.isBuildingPath) return;

        const d = DIRECTIONS[dirKey];
        if (!d) return;

        const startPos = this.getPathStartPos();
        const tipX = this.activePath.length === 0 ? startPos.x : this.activePath[this.activePath.length - 1].x;
        const tipY = this.activePath.length === 0 ? startPos.y : this.activePath[this.activePath.length - 1].y;

        const nextX = tipX + d.dx;
        const nextY = tipY + d.dy;

        if (nextX < 0 || nextX >= GRID_COLS || nextY < 0 || nextY >= GRID_ROWS) {
            this.addFloatingText(this.lang === 'en' ? 'BORDER HIT!' : 'CHẠM BIÊN!', tipX, tipY, '#cbd5e1');
            if (window.soundCtrl) window.soundCtrl.playUndo();
            return;
        }

        this.activePath.push({
            dir: dirKey,
            dx: d.dx,
            dy: d.dy,
            symbol: d.symbol,
            label: d.label,
            x: nextX,
            y: nextY
        });

        this.currentSelectedDir = dirKey;
        this.highlightSelectedDirButton();

        if (window.soundCtrl) window.soundCtrl.playMove();
        this.updatePathNoticeUI();

        if (this.activePath.length >= this.activePathMaxSteps) {
            this.finishActivePath();
        }
    }

    finishActivePath() {
        if (!this.isBuildingPath) return;

        if (this.activePath.length === 0) {
            this.cancelPathPlanning();
            return;
        }

        const unit = this.getActivePlanningUnit();
        const currentQueue = this.getActivePlanningQueue();
        const char = unit ? unit.character : this.selectedCharacter;
        const action = {
            skillId: char.skills[0].id,
            type: 'PATH_MOVE',
            name: `Lộ Trình (${this.activePath.length}b)`,
            name_en: `Route (${this.activePath.length} steps)`,
            icon: '👟',
            path: [...this.activePath],
            dir: this.activePath[this.activePath.length - 1].dir,
            dirSymbol: this.activePath.map(p => p.symbol).join(' '),
            color: char.themeColor
        };

        currentQueue.push(action);
        this.isBuildingPath = false;
        this.activePath = [];
        this.updatePathNoticeUI();

        if (window.soundCtrl) window.soundCtrl.playCommit();
        this.updateQueueDisplay();
        this.addCombatLog(this.lang === 'en' ? `Queued [${this.getActionName(action)}: ${action.dirSymbol}]!` : `Đã nạp [${action.name}: ${action.dirSymbol}] vào hàng đợi!`, 'system');

        if (currentQueue.length === 4) {
            if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
            } else {
                this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
            }
        }
    }

    cancelPathPlanning() {
        this.isBuildingPath = false;
        this.activePath = [];
        this.updatePathNoticeUI();
    }

    handleDirectionInput(key) {
        const keyMap = {
            'w': 'UP', 'arrowup': 'UP', 'numpad8': 'UP',
            's': 'DOWN', 'arrowdown': 'DOWN', 'numpad2': 'DOWN',
            'a': 'LEFT', 'arrowleft': 'LEFT', 'numpad4': 'LEFT',
            'd': 'RIGHT', 'arrowright': 'RIGHT', 'numpad6': 'RIGHT',
            'q': 'UP_LEFT', 'numpad7': 'UP_LEFT',
            'e': 'UP_RIGHT', 'numpad9': 'UP_RIGHT',
            'z': 'DOWN_LEFT', 'numpad1': 'DOWN_LEFT',
            'c': 'DOWN_RIGHT', 'numpad3': 'DOWN_RIGHT'
        };
        const dir = keyMap[key.toLowerCase()];
        if (!dir) return;

        if (this.isBuildingPath) {
            this.appendStepToActivePath(dir);
        } else {
            this.currentSelectedDir = dir;
            const activeUnit = this.getActivePlanningUnit();
            if (activeUnit) activeUnit.dir = dir;
            if (this.player) this.player.dir = dir;
            if (window.soundCtrl) window.soundCtrl.playSelect();
            this.highlightSelectedDirButton();
            this.updateHUD();
        }
    }

    highlightSelectedDirButton() {
        document.querySelectorAll('.key-badge[data-key]').forEach(btn => {
            const k = btn.getAttribute('data-key');
            const map = {
                'w': 'UP', 's': 'DOWN', 'a': 'LEFT', 'd': 'RIGHT',
                'q': 'UP_LEFT', 'e': 'UP_RIGHT', 'z': 'DOWN_LEFT', 'c': 'DOWN_RIGHT'
            };
            if (map[k] === this.currentSelectedDir) {
                btn.style.borderColor = '#00f2fe';
                btn.style.boxShadow = '0 0 10px rgba(0, 242, 254, 0.4)';
            } else {
                btn.style.borderColor = '#475569';
                btn.style.boxShadow = 'none';
            }
        });
    }

    handleKeyDown(e) {
        if (this.isAdShowing) {
            return;
        }

        if (e.code === 'Tab') {
            e.preventDefault();
            this.toggleInMatchLeaderboard();
            return;
        }

        if (e.code === 'Escape') {
            if (this.isLeaderboardOpen) {
                e.preventDefault();
                this.closeInMatchLeaderboard();
                return;
            }
            if (this.isHofOpen) {
                e.preventDefault();
                this.closeHallOfFame();
                return;
            }
        }

        if (this.isHotseatModalOpen) {
            if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                this.continueToP2Planning();
            }
            return;
        }

        if (this.phase === 'LANG_SELECT') {
            if (e.code === 'Digit1' || e.key === '1' || e.key === 'v' || e.key === 'V') {
                e.preventDefault();
                this.selectLanguage('vi');
            } else if (e.code === 'Digit2' || e.key === '2' || e.key === 'e' || e.key === 'E') {
                e.preventDefault();
                this.selectLanguage('en');
            } else if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                this.selectLanguage('vi');
            }
            return;
        }

        if (this.phase === 'MAIN_MENU') {
            if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                this.showCharSelectScreen();
            } else if (e.key === 'h' || e.key === 'H') {
                e.preventDefault();
                this.showHowToPlayScreen();
            } else if (e.key === 'l' || e.key === 'L') {
                e.preventDefault();
                this.openHallOfFame();
            }
            return;
        }

        if (this.phase === 'HOW_TO_PLAY') {
            if (e.code === 'Escape') {
                e.preventDefault();
                this.closeHowToPlayScreen();
            } else if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                this.showCharSelectScreen();
            }
            return;
        }

        if (this.phase === 'CHAR_SELECT') {
            if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                this.startBattle();
            } else if (e.code === 'Escape') {
                e.preventDefault();
                this.showMainMenuScreen();
            }
            return;
        }

        if (this.phase === 'GAMEOVER') {
            if (e.code === 'Enter' || e.code === 'Space') {
                this.restartGame();
            }
            return;
        }

        const key = e.key.toLowerCase();

        // 1. Phím chọn hành động: 1, 2, 3, 4 hoặc M, J, K, L
        if (key === '1' || key === 'm') {
            e.preventDefault();
            this.addSkillToQueue(0);
            return;
        }
        if (key === '2' || key === 'j') {
            e.preventDefault();
            this.addSkillToQueue(1);
            return;
        }
        if (key === '3' || key === 'k') {
            e.preventDefault();
            this.addSkillToQueue(2);
            return;
        }
        if (key === '4' || key === 'l') {
            e.preventDefault();
            this.addSkillToQueue(3);
            return;
        }

        // 2. Phím chọn hướng
        if (['w', 'a', 's', 'd', 'q', 'e', 'z', 'c', 
             'arrowup', 'arrowdown', 'arrowleft', 'arrowright',
             'numpad7', 'numpad8', 'numpad9', 'numpad4', 'numpad6', 'numpad1', 'numpad2', 'numpad3'].includes(key)) {
            e.preventDefault();
            this.handleDirectionInput(key);
            return;
        }

        // 3. Phím xóa lùi: Backspace
        if (e.code === 'Backspace') {
            e.preventDefault();
            if (this.isBuildingPath) {
                if (this.activePath.length > 0) {
                    this.activePath.pop();
                    if (window.soundCtrl) window.soundCtrl.playUndo();
                    this.updatePathNoticeUI();
                } else {
                    this.cancelPathPlanning();
                }
            } else {
                this.undoAction();
            }
            return;
        }

        // 4. Phím Hủy hết: Escape
        if (e.code === 'Escape') {
            e.preventDefault();
            if (this.isBuildingPath) {
                this.cancelPathPlanning();
            } else {
                this.clearQueue();
            }
            return;
        }

        // 5. Phím Khóa lệnh / Chốt lộ trình: Space hoặc Enter
        if (e.code === 'Space' || e.code === 'Enter') {
            e.preventDefault();
            if (this.isBuildingPath) {
                this.finishActivePath();
            } else if (this.isTwoPlayerMode && this.phase === 'PLANNING') {
                if (this.activePlanningPlayer === 1 && this.p1Queue.length === 4) {
                    this.confirmP1QueueAndTransitionToP2();
                } else if (this.activePlanningPlayer === 2 && this.p2Queue.length === 4) {
                    this.commitTurn();
                }
            } else if (this.playerQueue.length === 4 && this.phase === 'PLANNING') {
                this.commitTurn();
            }
        }
    }

    addSkillToQueue(skillIndex) {
        if (this.phase !== 'PLANNING') return;
        const unit = this.getActivePlanningUnit();
        if (this.gameMode === 'KOTH' && unit && unit.hp <= 0) return;
        const currentQueue = this.getActivePlanningQueue();
        const char = unit ? unit.character : this.selectedCharacter;
        if (!char || !char.skills) return;
        const skill = char.skills[skillIndex];
        if (!skill) return;

        // Nếu đang trong chế độ vẽ lộ trình mà nhấn chiêu khác -> Chốt lộ trình hiện tại trước
        if (this.isBuildingPath) {
            if (this.activePath.length > 0) {
                this.finishActivePath();
            } else {
                this.cancelPathPlanning();
            }
        }

        const ux = unit ? unit.x : this.player.x;
        const uy = unit ? unit.y : this.player.y;
        const uCooldowns = (unit && unit.cooldowns) ? unit.cooldowns : this.cooldowns;
        const uSkillAmmo = (unit && unit.skillAmmo) ? unit.skillAmmo : this.skillAmmo;
        const uBuffs = (unit && unit.buffs) ? unit.buffs : this.playerBuffs;

        // Kỹ năng chưa hoàn thiện (CUSTOM / Chưa thiết kế)
        if (skill.type === 'CUSTOM') {
            this.addFloatingText(this.lang === 'en' ? 'NOT DESIGNED!' : 'CHƯA THIẾT KẾ!', ux, uy, '#f59e0b');
            this.addCombatLog(this.lang === 'en' ? `Skill [${getSkillName(skill, 'en')}] is currently awaiting your design ideas!` : `Chiêu [${skill.name}] hiện đang chờ ý tưởng thiết kế từ bạn!`, 'system');
            if (window.soundCtrl) window.soundCtrl.playUndo();
            return;
        }

        // Kỹ năng Di chuyển theo Lộ trình (PATH_MOVE)
        if (skill.type === 'PATH_MOVE') {
            this.startPathPlanning();
            return;
        }

        // Kiểm tra Dây Móc đang găm (Active Tether)
        if (this.activeHookTethers && this.activeHookTethers.some(t => t.skillId === skill.id && (t.sourceUnit === unit || (unit && unit.isPlayer && t.source === 'PLAYER')))) {
            this.addFloatingText(this.lang === 'en' ? 'TETHERED!' : 'ĐANG TRÓI DÂY!', ux, uy, '#ef4444');
            this.addCombatLog(this.lang === 'en' ? `[${getSkillName(skill, 'en')}] is maintaining tether on target, will pull again next turn end!` : `[${skill.name}] đang duy trì dây móc găm vào mục tiêu, cuối lượt sau sẽ giật kéo tiếp!`, 'hit');
            if (window.soundCtrl) window.soundCtrl.playUndo();
            return;
        }

        // Kiểm tra Hồi chiêu (Cooldown)
        if (uCooldowns[skill.id] && uCooldowns[skill.id] > 0) {
            this.addFloatingText(this.lang === 'en' ? `COOLDOWN (${uCooldowns[skill.id]}T)!` : `HỒI CHIÊU (${uCooldowns[skill.id]}L)!`, ux, uy, '#f87171');
            this.addCombatLog(this.lang === 'en' ? `[${getSkillName(skill, 'en')}] is on cooldown! ${uCooldowns[skill.id]} turn(s) remaining.` : `[${skill.name}] đang hồi chiêu! Còn ${uCooldowns[skill.id]} lượt nữa.`, 'hit');
            if (window.soundCtrl) window.soundCtrl.playUndo();
            return;
        }

        // Kiểm tra đạn/lượt dùng của kỹ năng có cơ số đạn (Ammo)
        if (skill.maxAmmo) {
            const currentAmmo = uSkillAmmo[skill.id] !== undefined ? uSkillAmmo[skill.id] : skill.maxAmmo;
            const queuedCount = currentQueue.filter(act => act.skillId === skill.id).length;
            if (queuedCount >= currentAmmo) {
                const emptyWord = skill.type === 'RECT_SLASH' ? (this.lang === 'en' ? 'OUT OF USES!' : 'HẾT LƯỢT DÙNG!') : (this.lang === 'en' ? 'OUT OF AMMO!' : 'HẾT ĐẠN!');
                const unitWord = skill.type === 'RECT_SLASH' ? (this.lang === 'en' ? 'use(s)' : 'lượt sử dụng') : (this.lang === 'en' ? 'round(s)' : 'viên đạn');
                this.addFloatingText(emptyWord, ux, uy, '#f87171');
                this.addCombatLog(this.lang === 'en' ? `[${getSkillName(skill, 'en')}] only has ${currentAmmo} ${skill.type === 'RECT_SLASH' ? 'use(s)' : 'round(s)'} left!` : `[${skill.name}] chỉ còn ${currentAmmo} ${unitWord}!`, 'hit');
                if (window.soundCtrl) window.soundCtrl.playUndo();
                return;
            }
        }

        // Kiểm tra kỹ năng chỉ được dùng 4 hướng chính (Trái, Phải, Trên, Dưới)
        if (skill.cardinalOnly) {
            const cardinalDirs = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
            if (!cardinalDirs.includes(this.currentSelectedDir)) {
                const snapMap = {
                    'UP_LEFT': 'UP',
                    'UP_RIGHT': 'RIGHT',
                    'DOWN_LEFT': 'LEFT',
                    'DOWN_RIGHT': 'DOWN'
                };
                const snapped = snapMap[this.currentSelectedDir] || 'RIGHT';
                this.currentSelectedDir = snapped;
                if (unit) unit.dir = snapped;
                this.highlightSelectedDirButton();
                this.addFloatingText(this.lang === 'en' ? `FACING: ${DIRECTIONS[snapped].label_en || DIRECTIONS[snapped].label}` : `HƯỚNG: ${DIRECTIONS[snapped].label}`, ux, uy, '#06b6d4');
                this.addCombatLog(this.lang === 'en' ? `⚠️ [${getSkillName(skill, 'en')}] can only strike in 4 cardinal directions! Auto-snapped to [${DIRECTIONS[snapped].label_en || DIRECTIONS[snapped].label}]!` : `⚠️ [${skill.name}] chỉ có thể vung theo 4 hướng chính! Tự động chuyển sang hướng [${DIRECTIONS[snapped].label}]!`, 'system');
            }
        }

        // Kiểm tra Thuốc Lá đang hút
        if (skill.id === 'SMOKE_CIGARETTE' && uBuffs && uBuffs.cigarette && uBuffs.cigarette.turnsLeft > 0) {
            this.addFloatingText(this.lang === 'en' ? 'SMOKING!' : 'ĐANG HÚT THUỐC!', ux, uy, '#eab308');
            this.addCombatLog(this.lang === 'en' ? `[${getSkillName(skill, 'en')}] is currently active (+30% DMG & +1 Speed), cannot overlap!` : `[${skill.name}] đang duy trì hiệu lực (+30% DMG & +1 Tốc độ), không thể dùng đè!`, 'hit');
            if (window.soundCtrl) window.soundCtrl.playUndo();
            return;
        }

        // Kỹ năng có hồi chiêu thông thường chỉ được dùng tối đa 1 lần trong 1 lượt (ngoại trừ kỹ năng có maxAmmo)
        if (!skill.maxAmmo && skill.cooldown && skill.cooldown > 0) {
            const alreadyQueued = currentQueue.some(act => act.skillId === skill.id);
            if (alreadyQueued) {
                this.addFloatingText(this.lang === 'en' ? 'QUEUED THIS TURN!' : 'ĐÃ CHỌN TRONG LƯỢT!', ux, uy, '#f87171');
                this.addCombatLog(this.lang === 'en' ? `[${getSkillName(skill, 'en')}] has a cooldown, can only be used once per turn!` : `[${skill.name}] có hồi chiêu, chỉ được dùng tối đa 1 lần mỗi lượt!`, 'hit');
                if (window.soundCtrl) window.soundCtrl.playUndo();
                return;
            }
        }

        if (currentQueue.length >= 4) {
            this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Hàng đợi đã đầy (4/4)! Nhấn [SPACE] để thực thi.', 'system');
            return;
        }

        // Xử lý Vũ khí Súng Tỉa Snipeman: Lần 1 Ngắm Bắn, Lần 2 Bắn Súng Tỉa
        if (skill.type === 'SNIPER_WEAPON') {
            const isScoped = this.isUnitScoped(unit, currentQueue);
            if (!isScoped) {
                const action = {
                    skillId: 'SNIPER_SCOPE',
                    type: 'SNIPER_SCOPE',
                    name: this.lang === 'en' ? 'Scope In' : 'Ngắm Bắn',
                    icon: '🎯',
                    dir: this.currentSelectedDir,
                    dirSymbol: DIRECTIONS[this.currentSelectedDir].symbol,
                    range: 0,
                    power: 0,
                    color: '#818cf8'
                };
                currentQueue.push(action);
                if (window.soundCtrl) window.soundCtrl.playSniperScope();
                const playerPrefix = this.isTwoPlayerMode ? `[P${this.activePlanningPlayer}] ` : '';
                this.addCombatLog(
                    this.lang === 'en'
                        ? `${playerPrefix}Queued [Scope In]! Next movement is reduced by 1 step.`
                        : `${playerPrefix}Đã nạp [Ngắm Bắn] vào hàng đợi! Bước di chuyển tiếp theo bị giảm 1.`,
                    'system'
                );
                this.updateQueueDisplay();
                if (currentQueue.length === 4) {
                    if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                        this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
                    } else {
                        this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
                    }
                }
                return;
            } else {
                const action = {
                    skillId: 'SNIPER_SHOT',
                    type: 'SNIPER_SHOT',
                    name: this.lang === 'en' ? 'Sniper Shot' : 'Bắn Súng Tỉa',
                    icon: '💥',
                    dir: this.currentSelectedDir,
                    dirSymbol: DIRECTIONS[this.currentSelectedDir].symbol,
                    range: 6,
                    minPower: 25,
                    maxPower: 50,
                    color: '#6366f1'
                };
                currentQueue.push(action);
                if (window.soundCtrl) window.soundCtrl.playSelect();
                const dirObj = DIRECTIONS[action.dir];
                const dirLabel = this.lang === 'en' ? (dirObj.label_en || dirObj.label) : dirObj.label;
                const playerPrefix = this.isTwoPlayerMode ? `[P${this.activePlanningPlayer}] ` : '';
                this.addCombatLog(
                    this.lang === 'en'
                        ? `${playerPrefix}Queued [Sniper Shot] facing [${dirLabel} ${action.dirSymbol}]!`
                        : `${playerPrefix}Đã nạp [Bắn Súng Tỉa] hướng [${dirLabel} ${action.dirSymbol}] vào hàng đợi!`,
                    'system'
                );
                this.updateQueueDisplay();
                if (currentQueue.length === 4) {
                    if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                        this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
                    } else {
                        this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
                    }
                }
                return;
            }
        }

        // Xử lý Vũ khí Nòng Xe Tăng Hat Boom Man: Lần 1 Ngắm Bắn, Lần 2 Bắn Nòng Xe Tăng
        if (skill.type === 'TANK_WEAPON') {
            const isScoped = this.isUnitScoped(unit, currentQueue);
            if (!isScoped) {
                const action = {
                    skillId: 'TANK_SCOPE',
                    type: 'TANK_SCOPE',
                    name: this.lang === 'en' ? 'Scope In' : 'Ngắm Nòng Pháo',
                    icon: '🎯',
                    dir: this.currentSelectedDir,
                    dirSymbol: DIRECTIONS[this.currentSelectedDir].symbol,
                    range: 0,
                    power: 0,
                    color: '#e11d48'
                };
                currentQueue.push(action);
                if (window.soundCtrl) window.soundCtrl.playTankScope();
                const playerPrefix = this.isTwoPlayerMode ? `[P${this.activePlanningPlayer}] ` : '';
                this.addCombatLog(
                    this.lang === 'en'
                        ? `${playerPrefix}Queued [Scope In]! Next movement is reduced by 1 step.`
                        : `${playerPrefix}Đã nạp [Ngắm Nòng Pháo] vào hàng đợi! Bước di chuyển tiếp theo bị giảm 1.`,
                    'system'
                );
                this.updateQueueDisplay();
                if (currentQueue.length === 4) {
                    if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                        this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
                    } else {
                        this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
                    }
                }
                return;
            } else {
                const action = {
                    skillId: 'TANK_SHOT',
                    type: 'TANK_SHOT',
                    name: this.lang === 'en' ? 'Tank Cannon Shot' : 'Bắn Nòng Xe Tăng',
                    icon: '💥',
                    dir: this.currentSelectedDir,
                    dirSymbol: DIRECTIONS[this.currentSelectedDir].symbol,
                    range: 6,
                    minPower: 15,
                    maxPower: 45,
                    aoeRadius: 1,
                    splashPower: 10,
                    color: '#e11d48'
                };
                currentQueue.push(action);
                if (window.soundCtrl) window.soundCtrl.playSelect();
                const dirObj = DIRECTIONS[action.dir];
                const dirLabel = this.lang === 'en' ? (dirObj.label_en || dirObj.label) : dirObj.label;
                const playerPrefix = this.isTwoPlayerMode ? `[P${this.activePlanningPlayer}] ` : '';
                this.addCombatLog(
                    this.lang === 'en'
                        ? `${playerPrefix}Queued [Tank Cannon Shot] facing [${dirLabel} ${action.dirSymbol}]!`
                        : `${playerPrefix}Đã nạp [Bắn Nòng Xe Tăng] hướng [${dirLabel} ${action.dirSymbol}] vào hàng đợi!`,
                    'system'
                );
                this.updateQueueDisplay();
                if (currentQueue.length === 4) {
                    if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                        this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
                    } else {
                        this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
                    }
                }
                return;
            }
        }

        const action = {
            skillId: skill.id,
            type: skill.type,
            name: skill.name,
            name_en: skill.name_en,
            icon: skill.icon,
            dir: this.currentSelectedDir,
            dirSymbol: DIRECTIONS[this.currentSelectedDir].symbol,
            range: skill.range !== undefined ? skill.range : 1,
            power: skill.power !== undefined ? skill.power : 25,
            minPower: skill.minPower,
            maxPower: skill.maxPower,
            maxAmmo: skill.maxAmmo,
            pullSteps: skill.pullSteps,
            delayedPullSteps: skill.delayedPullSteps,
            leapExtra: skill.leapExtra,
            damageReductionPercent: skill.damageReductionPercent,
            rangeForward: skill.rangeForward,
            widthPerp: skill.widthPerp,
            cardinalOnly: skill.cardinalOnly,
            duration: skill.duration,
            healPerTurn: skill.healPerTurn,
            dmgBonusPercent: skill.dmgBonusPercent,
            moveBonus: skill.moveBonus,
            fuse: skill.fuse,
            cooldown: skill.cooldown,
            aoeRadius: skill.aoeRadius,
            burnTurns: skill.burnTurns,
            burnDmg: skill.burnDmg,
            fireZoneDuration: skill.fireZoneDuration,
            sentryHp: skill.sentryHp,
            sentryRange: skill.sentryRange,
            portalHp: skill.portalHp,
            rangeBonus: skill.rangeBonus,
            color: skill.color || '#38bdf8'
        };

        currentQueue.push(action);
        if (window.soundCtrl) window.soundCtrl.playSelect();

        const dirObj = DIRECTIONS[action.dir];
        const dirLabel = this.lang === 'en' ? (dirObj.label_en || dirObj.label) : dirObj.label;
        const playerPrefix = this.isTwoPlayerMode ? `[P${this.activePlanningPlayer}] ` : '';
        this.addCombatLog(
            this.lang === 'en'
                ? `${playerPrefix}Queued [${this.getActionName(action)}] facing [${dirLabel} ${action.dirSymbol}]!`
                : `${playerPrefix}Đã nạp [${action.name}] hướng [${dirLabel} ${action.dirSymbol}] vào hàng đợi!`,
            'system'
        );

        this.updateQueueDisplay();

        if (currentQueue.length === 4) {
            if (this.isTwoPlayerMode && this.activePlanningPlayer === 1) {
                this.addCombatLog(this.lang === 'en' ? 'P1 queue full (4/4)! Press [SPACE] to pass to P2!' : 'P1 đã đủ 4 lệnh. Bấm [SPACE] để xác nhận và chuyển P2!', 'system');
            } else {
                this.addCombatLog(this.lang === 'en' ? 'Queue full (4/4)! Press [SPACE] to EXECUTE!' : 'Đã nạp đủ 4 lệnh. Bấm [SPACE] để BẮT ĐẦU ĐẤU!', 'system');
            }
        }
    }

    undoAction() {
        if (this.phase !== 'PLANNING') return;
        const unit = this.getActivePlanningUnit();
        if (this.gameMode === 'KOTH' && unit && unit.hp <= 0) return;
        const currentQueue = this.getActivePlanningQueue();
        if (currentQueue.length > 0) {
            currentQueue.pop();
            if (window.soundCtrl) window.soundCtrl.playUndo();
            this.updateQueueDisplay();
        }
    }

    clearQueue() {
        if (this.phase !== 'PLANNING') return;
        const unit = this.getActivePlanningUnit();
        if (this.gameMode === 'KOTH' && unit && unit.hp <= 0) return;
        this.cancelPathPlanning();
        const currentQueue = this.getActivePlanningQueue();
        if (currentQueue.length > 0) {
            currentQueue.length = 0;
            if (window.soundCtrl) window.soundCtrl.playUndo();
            this.updateQueueDisplay();
        }
    }

    updateQueueDisplay() {
        const commitBtn = document.getElementById('btnCommit');
        const countText = document.getElementById('queueCountText');
        const pTitleElem = document.getElementById('playerQueueTitleText');
        const cTitleElem = document.getElementById('cpuQueueTitleText');
        const cStatusElem = document.getElementById('cpuQueueStatusText');

        if (this.isTwoPlayerMode) {
            const p1 = this.p1Unit || this.player;
            const p2 = this.p2Unit || this.cpu;

            if (pTitleElem && p1) {
                const teamName = p1.team === 'BLUE' ? (this.lang === 'en' ? 'BLUE' : 'XANH') : (this.lang === 'en' ? 'RED' : 'ĐỎ');
                pTitleElem.innerText = `🎮 ${this.lang === 'en' ? 'PLAYER 1' : 'NGƯỜI CHƠI 1'} [${getCharName(p1.character, this.lang)}] (${teamName})`;
            }
            if (cTitleElem && p2) {
                const teamName = p2.team === 'BLUE' ? (this.lang === 'en' ? 'BLUE' : 'XANH') : (this.lang === 'en' ? 'RED' : 'ĐỎ');
                cTitleElem.innerText = `🎮 ${this.lang === 'en' ? 'PLAYER 2' : 'NGƯỜI CHƠI 2'} [${getCharName(p2.character, this.lang)}] (${teamName})`;
            }

            if (this.phase === 'PLANNING') {
                if (this.activePlanningPlayer === 1) {
                    if (cStatusElem) cStatusElem.innerText = t('p2WaitingP1Status');
                    // Render P1 Queue
                    for (let i = 0; i < 4; i++) {
                        const slot = document.getElementById(`p-slot-${i}`);
                        if (i < this.p1Queue.length) {
                            const act = this.p1Queue[i];
                            slot.className = 'queue-slot filled';
                            slot.innerHTML = `
                                <span class="slot-step-num">#${i + 1}</span>
                                <span class="slot-icon">${act.icon}</span>
                                <span class="slot-name">${this.getActionName(act)}</span>
                                <span class="slot-dir" style="letter-spacing: 2px;">${act.dirSymbol || ''}</span>
                            `;
                        } else {
                            slot.className = 'queue-slot';
                            slot.innerHTML = `
                                <span class="slot-step-num">#${i + 1}</span>
                                <span class="slot-icon">?</span>
                                <span class="slot-name">${t('slotEmpty')}</span>
                            `;
                        }

                        // P2 slots show pending
                        const cSlot = document.getElementById(`c-slot-${i}`);
                        if (cSlot) {
                            cSlot.className = 'queue-slot';
                            cSlot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">⏳</span><span class="slot-name">${t('p2PendingQueueSlot')}</span>`;
                        }
                    }

                    if (countText) countText.innerText = `${this.p1Queue.length} / 4`;
                    if (commitBtn) {
                        if (this.p1Queue.length === 4) {
                            commitBtn.disabled = false;
                            commitBtn.innerHTML = `<span>[SPACE] ${t('btnCommitP1')} ➔</span>`;
                            commitBtn.style.animation = 'pulse 1s infinite alternate';
                        } else {
                            commitBtn.disabled = true;
                            commitBtn.innerHTML = `<span>${t('btnCommitP1')} (${this.p1Queue.length}/4)</span>`;
                            commitBtn.style.animation = 'none';
                        }
                    }
                } else {
                    // activePlanningPlayer === 2
                    if (cStatusElem) cStatusElem.innerText = t('p2ActivePlanningStatus');
                    // P1 slots masked with secret lock (Anti-peeking)
                    for (let i = 0; i < 4; i++) {
                        const slot = document.getElementById(`p-slot-${i}`);
                        if (slot) {
                            slot.className = 'queue-slot filled';
                            slot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${t('secretLockedTitle')}</span>`;
                        }

                        // Render P2 Queue
                        const cSlot = document.getElementById(`c-slot-${i}`);
                        if (cSlot) {
                            if (i < this.p2Queue.length) {
                                const act = this.p2Queue[i];
                                cSlot.className = 'queue-slot filled';
                                cSlot.innerHTML = `
                                    <span class="slot-step-num">#${i + 1}</span>
                                    <span class="slot-icon">${act.icon}</span>
                                    <span class="slot-name">${this.getActionName(act)}</span>
                                    <span class="slot-dir" style="letter-spacing: 2px;">${act.dirSymbol || ''}</span>
                                `;
                            } else {
                                cSlot.className = 'queue-slot';
                                cSlot.innerHTML = `
                                    <span class="slot-step-num">#${i + 1}</span>
                                    <span class="slot-icon">?</span>
                                    <span class="slot-name">${t('slotEmpty')}</span>
                                `;
                            }
                        }
                    }

                    if (countText) countText.innerText = `${this.p2Queue.length} / 4`;
                    if (commitBtn) {
                        if (this.p2Queue.length === 4) {
                            commitBtn.disabled = false;
                            commitBtn.innerHTML = `<span>[SPACE] ${t('btnCommitP2')} 🚀</span>`;
                            commitBtn.style.animation = 'pulse 1s infinite alternate';
                        } else {
                            commitBtn.disabled = true;
                            commitBtn.innerHTML = `<span>${t('btnCommitP2')} (${this.p2Queue.length}/4)</span>`;
                            commitBtn.style.animation = 'none';
                        }
                    }
                }
            } else if (this.phase === 'RESOLVING') {
                if (cStatusElem) cStatusElem.innerText = t('resolvingStatus');
                if (commitBtn) {
                    commitBtn.disabled = true;
                    commitBtn.innerHTML = `<span>${t('resolvingWegoProgress')}</span>`;
                    commitBtn.style.animation = 'none';
                }
            }

            this.updateSkillButtons();
            return;
        }

        // --- 1P Mode ---
        if (pTitleElem) pTitleElem.innerText = t('playerQueueTitle');
        if (cTitleElem) cTitleElem.innerText = t('cpuQueueTitle');
        if (cStatusElem) cStatusElem.innerText = t('secretTag');

        for (let i = 0; i < 4; i++) {
            const slot = document.getElementById(`p-slot-${i}`);
            if (i < this.playerQueue.length) {
                const act = this.playerQueue[i];
                slot.className = 'queue-slot filled';
                slot.innerHTML = `
                    <span class="slot-step-num">#${i + 1}</span>
                    <span class="slot-icon">${act.icon}</span>
                    <span class="slot-name">${this.getActionName(act)}</span>
                    <span class="slot-dir" style="letter-spacing: 2px;">${act.dirSymbol}</span>
                `;
            } else {
                slot.className = 'queue-slot';
                slot.innerHTML = `
                    <span class="slot-step-num">#${i + 1}</span>
                    <span class="slot-icon">?</span>
                    <span class="slot-name">${t('slotEmpty')}</span>
                `;
            }
        }

        if (countText) countText.innerText = `${this.playerQueue.length} / 4`;

        const isPlayerDead = this.gameMode === 'KOTH' && this.player && this.player.hp <= 0;

        if (this.playerQueue.length === 4 && this.phase === 'PLANNING') {
            commitBtn.disabled = false;
            if (isPlayerDead) {
                commitBtn.innerHTML = `<span>${t('waitingRespawnCommit')} ⏳</span>`;
            } else {
                commitBtn.innerHTML = `<span>${t('btnCommitPrefix')} (4/4) 🚀</span>`;
            }
            commitBtn.style.animation = 'pulse 1s infinite alternate';
        } else {
            commitBtn.disabled = true;
            commitBtn.innerHTML = `<span>${t('btnCommitPrefix')} (${this.playerQueue.length}/4)</span>`;
            commitBtn.style.animation = 'none';
        }

        this.updateSkillButtons();
    }

    updateHUD() {
        const p1 = (this.isTwoPlayerMode && this.p1Unit) ? this.p1Unit : this.player;
        const p2 = (this.isTwoPlayerMode && this.p2Unit) ? this.p2Unit : this.cpu;

        const pFill = document.getElementById('playerHpFill');
        const pText = document.getElementById('playerHpText');
        const pPct = Math.max(0, (p1.hp / p1.maxHp) * 100);
        if (pFill) pFill.style.width = `${pPct}%`;
        if (pText) pText.innerText = `${Math.round(p1.hp)} / ${p1.maxHp} HP`;

        const cFill = document.getElementById('cpuHpFill');
        const cText = document.getElementById('cpuHpText');
        const cPct = Math.max(0, (p2.hp / p2.maxHp) * 100);
        if (cFill) cFill.style.width = `${cPct}%`;
        if (cText) cText.innerText = `${Math.round(p2.hp)} / ${p2.maxHp} HP`;

        const playerBadge = document.getElementById('playerNameBadge');
        if (playerBadge) {
            if (this.isTwoPlayerMode) {
                const teamTag = p1.team === 'BLUE' ? (this.lang === 'en' ? 'BLUE' : 'XANH') : (this.lang === 'en' ? 'RED' : 'ĐỎ');
                playerBadge.innerText = `🎮 [P1] ${getCharName(p1.character, this.lang).toUpperCase()} (${teamTag})`;
                playerBadge.style.color = p1.color;
            } else if (this.selectedCharacter) {
                playerBadge.innerText = `${getCharName(this.selectedCharacter, this.lang).toUpperCase()} ${t('playerBadgeSuffix')}`;
            }
        }

        const cpuBadge = document.getElementById('cpuNameBadge');
        if (cpuBadge) {
            if (this.isTwoPlayerMode) {
                const teamTag = p2.team === 'BLUE' ? (this.lang === 'en' ? 'BLUE' : 'XANH') : (this.lang === 'en' ? 'RED' : 'ĐỎ');
                cpuBadge.innerText = `🎮 [P2] ${getCharName(p2.character, this.lang).toUpperCase()} (${teamTag})`;
                cpuBadge.style.color = p2.color;
            } else if (this.cpuCharacter) {
                cpuBadge.innerText = `${this.cpu.avatar} ${getCharName(this.cpuCharacter, this.lang).toUpperCase()} ${t('cpuBadgeSuffix')}`;
                cpuBadge.style.color = this.cpu.color;
            }
        }

        const cpuStatusText = document.getElementById('cpuStatusText');
        if (cpuStatusText) {
            if (this.cpu && this.cpu.hp <= 0 && (!this.redTeam || this.redTeam.every(u => u.hp <= 0))) {
                cpuStatusText.innerText = t('cpuStatusDefeated');
                cpuStatusText.style.color = '#f87171';
            } else if (this.phase === 'PLANNING') {
                cpuStatusText.innerText = t('cpuStatusThinking');
                cpuStatusText.style.color = '#38bdf8';
            } else {
                cpuStatusText.innerText = t('cpuStatusReady');
                cpuStatusText.style.color = '#34d399';
            }
        }

        // Render Roster Bars & Score
        const pRoster = document.getElementById('playerTeamRosterBar');
        if (pRoster && this.blueTeam && this.blueTeam.length > 0) {
            pRoster.innerHTML = this.blueTeam.map(u => {
                let statusDisplay = `${Math.round(u.hp)} HP`;
                let chipClass = 'team-hud-chip alive';
                if (u.hp <= 0) {
                    if (this.gameMode === 'KOTH' && u.respawnTurns > 0) {
                        statusDisplay = t('respawningTag', { turns: u.respawnTurns });
                        chipClass = 'team-hud-chip respawning';
                    } else {
                        statusDisplay = this.lang === 'en' ? 'K.O' : 'HẠ';
                        chipClass = 'team-hud-chip dead';
                    }
                }
                let debuffBadges = '';
                if (u.hp > 0) {
                    if (u.isOiled) debuffBadges += ` <span style="color:#f59e0b;" title="${t('statusOiled')}">🛢️</span>`;
                    if (u.burnTurns > 0) debuffBadges += ` <span style="color:#ea580c; font-weight:800;" title="${t('statusBurning', { turns: u.burnTurns })}">🔥${u.burnTurns}</span>`;
                }
                const pTag = u.playerIndex === 1 ? '[P1]' : (u.playerIndex === 2 ? '[P2]' : (u.isPlayer ? (this.lang === 'en' ? 'You' : 'Bạn') : '+CPU'));
                const pColor = u.playerIndex === 1 ? '#34d399' : (u.playerIndex === 2 ? '#fb7185' : (u.isPlayer ? '#34d399' : '#38bdf8'));
                const charTitle = u.character ? getCharName(u.character, this.lang) : u.name;
                const charShort = u.character ? getCharName(u.character, this.lang).split(' (')[0] : u.name;
                return `
                    <div class="${chipClass}" title="${charTitle}: ${u.hp > 0 ? Math.round(u.hp) + '/' + u.maxHp + ' HP' : statusDisplay}">
                        <span>${u.avatar}</span>
                        <span>${charShort}</span>
                        <span style="color: ${pColor}; font-size: 0.65rem; font-weight:800;">${pTag}</span>
                        <span style="color: ${u.hp > 0 ? '#34d399' : (u.respawnTurns > 0 ? '#f59e0b' : '#f87171')}; font-weight:800;">${statusDisplay}${debuffBadges}</span>
                    </div>
                `;
            }).join('');
        }

        const cRoster = document.getElementById('cpuTeamRosterBar');
        if (cRoster && this.redTeam && this.redTeam.length > 0) {
            cRoster.innerHTML = this.redTeam.map(u => {
                let statusDisplay = `${Math.round(u.hp)} HP`;
                let chipClass = 'team-hud-chip alive';
                if (u.hp <= 0) {
                    if (this.gameMode === 'KOTH' && u.respawnTurns > 0) {
                        statusDisplay = t('respawningTag', { turns: u.respawnTurns });
                        chipClass = 'team-hud-chip respawning';
                    } else {
                        statusDisplay = this.lang === 'en' ? 'K.O' : 'HẠ';
                        chipClass = 'team-hud-chip dead';
                    }
                }
                let debuffBadges = '';
                if (u.hp > 0) {
                    if (u.isOiled) debuffBadges += ` <span style="color:#f59e0b;" title="${t('statusOiled')}">🛢️</span>`;
                    if (u.burnTurns > 0) debuffBadges += ` <span style="color:#ea580c; font-weight:800;" title="${t('statusBurning', { turns: u.burnTurns })}">🔥${u.burnTurns}</span>`;
                }
                const pTag = u.playerIndex === 1 ? '[P1]' : (u.playerIndex === 2 ? '[P2]' : '+CPU');
                const pColor = u.playerIndex === 1 ? '#34d399' : (u.playerIndex === 2 ? '#fb7185' : '#fb7185');
                const charTitle = u.character ? getCharName(u.character, this.lang) : u.name;
                const charShort = u.character ? getCharName(u.character, this.lang).split(' (')[0] : u.name;
                return `
                    <div class="${chipClass}" title="${charTitle}: ${u.hp > 0 ? Math.round(u.hp) + '/' + u.maxHp + ' HP' : statusDisplay}">
                        <span>${u.avatar}</span>
                        <span>${charShort}</span>
                        <span style="color: ${pColor}; font-size: 0.65rem; font-weight:800;">${pTag}</span>
                        <span style="color: ${u.hp > 0 ? '#fb7185' : (u.respawnTurns > 0 ? '#f59e0b' : '#f87171')}; font-weight:800;">${statusDisplay}${debuffBadges}</span>
                    </div>
                `;
            }).join('');
        }

        const scoreElem = document.getElementById('teamScoreDisplay');
        if (scoreElem && this.blueTeam && this.redTeam) {
            const blueAlive = this.blueTeam.filter(u => u.hp > 0).length;
            const redAlive = this.redTeam.filter(u => u.hp > 0).length;
            scoreElem.innerText = `🔵 ${blueAlive} ${this.lang === 'en' ? 'Alive' : 'Sống'} vs 🔴 ${redAlive} ${this.lang === 'en' ? 'Alive' : 'Sống'}`;
        }

        // KOTH HUD Banner & Overtime
        const kothBanner = document.getElementById('kothScoreBanner');
        if (kothBanner) {
            if (this.gameMode === 'KOTH') {
                kothBanner.style.display = 'flex';
                const bScore = document.getElementById('kothBlueScoreText');
                const rScore = document.getElementById('kothRedScoreText');
                const hBadge = document.getElementById('kothHillStatusBadge');
                const otBadge = document.getElementById('kothOvertimeBadge');

                if (bScore) bScore.innerText = `🔵 ${this.blueScore}/15`;
                if (rScore) rScore.innerText = `🔴 ${this.redScore}/15`;

                if (hBadge) {
                    const blueInZone = this.blueTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;
                    const redInZone = this.redTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;
                    const isContested = blueInZone > 0 && redInZone > 0;

                    let hillText = t('kothHillNeutral');
                    let badgeClass = 'koth-hill-badge';

                    if (isContested) {
                        badgeClass += ' contested';
                        if (this.hillOwner === 'BLUE') {
                            hillText = this.lang === 'en'
                                ? `⚔️ BLUE POINT [CONTESTED! ${blueInZone}v${redInZone}] [+1 PT]`
                                : `⚔️ ĐỘI XANH [TRANH CHẤP! ${blueInZone}v${redInZone}] [+1 Đ]`;
                        } else if (this.hillOwner === 'RED') {
                            hillText = this.lang === 'en'
                                ? `⚔️ RED POINT [CONTESTED! ${redInZone}v${blueInZone}] [+1 PT]`
                                : `⚔️ ĐỘI ĐỎ [TRANH CHẤP! ${redInZone}v${blueInZone}] [+1 Đ]`;
                        } else {
                            hillText = t('kothHillContested', { blue: blueInZone, red: redInZone });
                        }
                    } else if (this.hillOwner === 'BLUE') {
                        badgeClass += ' blue-hold';
                        if (this.hillScale === 2) {
                            hillText = t('kothHillCapturedBlue');
                        } else {
                            hillText = this.lang === 'en'
                                ? `🔵 BLUE ZONE (RED CAPPING ${Math.abs(this.hillScale - 2)}/4) [+1 PT]`
                                : `🔵 ĐỘI XANH GIỮ (ĐỎ ĐANG CHIẾM ${Math.abs(this.hillScale - 2)}/4) [+1 Đ]`;
                        }
                    } else if (this.hillOwner === 'RED') {
                        badgeClass += ' red-hold';
                        if (this.hillScale === -2) {
                            hillText = t('kothHillCapturedRed');
                        } else {
                            hillText = this.lang === 'en'
                                ? `🔴 RED ZONE (BLUE CAPPING ${Math.abs(-2 - this.hillScale)}/4) [+1 PT]`
                                : `🔴 ĐỘI ĐỎ GIỮ (XANH ĐANG CHIẾM ${Math.abs(-2 - this.hillScale)}/4) [+1 Đ]`;
                        }
                    } else {
                        if (this.hillScale > 0) {
                            hillText = t('kothHillCapturingBlue', { status: this.hillScale });
                            badgeClass += ' blue-hold';
                        } else if (this.hillScale < 0) {
                            hillText = t('kothHillCapturingRed', { status: Math.abs(this.hillScale) });
                            badgeClass += ' red-hold';
                        } else {
                            hillText = t('kothHillNeutral');
                        }
                    }
                    hBadge.innerText = hillText;
                    hBadge.className = badgeClass;
                }

                if (otBadge) {
                    otBadge.style.display = this.inOvertime ? 'inline-block' : 'none';
                    if (this.inOvertime) {
                        otBadge.innerText = t('kothOvertimeBadge');
                    }
                }
            } else {
                kothBanner.style.display = 'none';
            }
        }

        // Thông báo Người chơi đang chờ hồi sinh
        const respawnNotice = document.getElementById('playerRespawnNotice');
        if (respawnNotice) {
            const activePlanningUnit = this.getActivePlanningUnit();
            if (this.gameMode === 'KOTH' && activePlanningUnit && activePlanningUnit.hp <= 0) {
                respawnNotice.style.display = 'flex';
                const respText = document.getElementById('playerRespawnNoticeText');
                if (respText) respText.innerText = t('respawnNoticeText', { turns: activePlanningUnit.respawnTurns });
            } else {
                respawnNotice.style.display = 'none';
            }
        }

        document.getElementById('turnDisplay').innerText = `${t('turnPrefix')} ${this.turn}`;
        const phaseElem = document.getElementById('phaseDisplay');
        if (this.phase === 'PLANNING') {
            phaseElem.innerText = t('phasePlanning');
            phaseElem.style.color = '#38bdf8';
        } else if (this.phase === 'RESOLVING') {
            phaseElem.innerText = this.lang === 'en' ? `RESOLVING: STEP ${this.currentStep + 1}/4` : `GIẢI QUYẾT: BƯỚC ${this.currentStep + 1}/4`;
            phaseElem.style.color = '#f59e0b';
        } else if (this.phase === 'CHAR_SELECT') {
            phaseElem.innerText = t('charSelectHeaderTitle');
            phaseElem.style.color = '#a855f7';
        } else if (this.phase === 'LANG_SELECT') {
            phaseElem.innerText = t('langBadge');
            phaseElem.style.color = '#38bdf8';
        } else {
            phaseElem.innerText = this.lang === 'en' ? 'GAME OVER' : 'KẾT THÚC';
            phaseElem.style.color = '#f43f5e';
        }

        const d = DIRECTIONS[this.currentSelectedDir];
        const dLabel = this.lang === 'en' ? (d.label_en || d.label) : d.label;
        document.getElementById('currentDirText').innerText = `${dLabel} (${d.symbol})`;
    }

    getActionName(act) {
        if (!act) return '';
        if (this.lang === 'en') {
            if (act.name_en) return act.name_en;

            // Tra cứu động qua cơ sở dữ liệu nhân vật & kỹ năng
            if (act.skillId && typeof CHARACTERS_DATABASE !== 'undefined') {
                for (const char of CHARACTERS_DATABASE) {
                    const sk = char.skills.find(s => s.id === act.skillId);
                    if (sk && sk.name_en) return sk.name_en;
                }
            }

            const actionNameMap = {
                'Lộ Trình': 'Route',
                'Bắn Bừa Bãi': 'Wild Spray',
                'Bắn Bừa Tên Lửa': 'Wild Rocket',
                'Bắn Bừa Bom Pháo': 'Wild Bomb Shot',
                'Bắn Bừa Đại Bác Lửa': 'Wild Fire Cannon',
                'Ném Bừa Thùng Dầu': 'Wild Oil Barrel',
                'Bắn Bừa Gattling Fire': 'Wild Gatling Fire',
                'Khiên': 'Shield',
                'Tên Lửa': 'Rocket',
                'Lựu Đạn': 'Frag Grenade',
                'Móc Kéo': 'Grappling Hook',
                'Adrenaline': 'Adrenaline Stim',
                'Ống Tiêm Adrenaline': 'Adrenaline Stim',
                'Silence Pistol': 'Silence Pistol',
                'Thuốc Lá': 'Cigarette',
                'Súng Bắn Bom': 'Bomb Launcher',
                'Combat Rifle': 'Combat Rifle',
                'Kiếm Gắn Tay': 'Arm Blade',
                'Nhảy Đột Kích': 'Assault Leap',
                'Pulse Rifle': 'Pulse Rifle',
                'Thùng Dầu': 'Oil Barrel',
                'Đại Bác Lửa': 'Fire Cannon',
                'Gattling Fire': 'Gattling Fire',
                'Xây Sentry': 'Deploy Sentry',
                'Cổng Dịch Chuyển': 'Teleporter',
                'Súng Thanh Sắt': 'Iron Rod Gun',
                'Tầm Nhìn Dò Nhiệt': 'Thermal Vision',
                'Phát Bắn Hủy Diệt': 'Destructive Shot',
                'Bắn Súng Tỉa': 'Sniper Shot',
                'Ngắm Bắn': 'Scope In',
                'Necromancy': 'Necromancy',
                'Telekinesis': 'Telekinesis',
                'Revolver': 'Revolver',
                'Hộ Thuẫn Bất Tử': 'Invulnerability Shield',
                'Trạm Hồi Máu': 'Healing Station',
                'Machine Pistol': 'Machine Pistol',
                'Cú Bật Nhảy': 'Invulnerable Leap',
                'Phát Bắn Rối Loạn': 'Chaos Shot',
                'Bắn Nòng Xe Tăng': 'Tank Cannon Shot',
                'Ngắm Nòng Pháo': 'Scope In'
            };
            if (act.name && actionNameMap[act.name]) return actionNameMap[act.name];

            if (typeof act.name === 'string' && act.name.startsWith('Lộ Trình')) {
                return act.name.replace('Lộ Trình', 'Route').replace('b)', ' steps)').replace('b', ' steps');
            }

            const skillMap = {
                'TROOPER_MOVE': 'Route',
                'TROOPER_RIFLE': 'Assault Rifle',
                'TROOPER_ROCKET': 'Rocket Launcher',
                'TROOPER_GRENADE': 'Frag Grenade',
                'HOOKMAN_MOVE': 'Patrol Route',
                'HOOKMAN_PISTOL': 'Silence Pistol',
                'HOOKMAN_ADRENALINE': 'Adrenaline Stim',
                'HOOKMAN_HOOK': 'Grappling Hook',
                'SMOKE_MOVE': 'Route',
                'SMOKE_RIFLE': 'Combat Rifle',
                'SMOKE_BOMB_LAUNCHER': 'Smoke Bomb Launcher',
                'SMOKE_CIGARETTE': 'Light Cigarette',
                'RAZOR_MOVE': 'Route',
                'RAZOR_PULSE_RIFLE': 'Pulse Rifle',
                'RAZOR_LEAP': 'Assault Leap',
                'RAZOR_BLADE': 'Arm Blade',
                'FIREMAN_MOVE': 'Route',
                'FIREMAN_GATTLING_FIRE': 'Gatling Inferno',
                'FIREMAN_OIL_BARREL': 'Oil Barrel',
                'FIREMAN_OIL_BOMB': 'Oil Barrel',
                'FIREMAN_FIRE_CANNON': 'Fire Cannon',
                'ENGIE_MOVE': 'Route',
                'ENGIE_NAILGUN': 'Iron Rod Gun',
                'ENGIE_SENTRY': 'Deploy Sentry',
                'ENGIE_TELEPORTER': 'Teleporter',
                'SNIPER_MOVE': 'Route',
                'SNIPER_RIFLE': 'Sniper Rifle',
                'SNIPER_SCOPE': 'Scope In',
                'SNIPER_SHOT': 'Sniper Shot',
                'SNIPER_DESTRUCTIVE': 'Destructive Shot',
                'SNIPER_THERMAL': 'Thermal Vision',
                'BOOM_MOVE': 'Route',
                'BOOM_SCOPE': 'Scope In',
                'BOOM_SHOT': 'Tank Cannon Shot',
                'TANK_CANNON': 'Tank Cannon Shot',
                'BOOM_LEAP': 'Invulnerable Leap',
                'BOOM_CHAOS_SHOT': 'Chaos Shot',
                'SAVIOR_MOVE': 'Route',
                'SAVIOR_REVOLVER': 'Revolver',
                'SAVIOR_TELEKINESIS': 'Telekinesis',
                'SAVIOR_NECROMANCY': 'Necromancy',
                'MEDIC_MOVE': 'Route',
                'MEDIC_MACHINE_PISTOL': 'Machine Pistol',
                'MEDIC_HEAL_STATION': 'Healing Station',
                'MEDIC_INVULNERABILITY_SHIELD': 'Invulnerability Shield'
            };
            if (act.skillId && skillMap[act.skillId]) return skillMap[act.skillId];
            if (act.type === 'PATH_MOVE') return 'Route';
            if (act.type === 'SHIELD') return 'Shield';
            if (act.type === 'LEAP') return 'Assault Leap';
            if (act.type === 'BOOM_LEAP') return 'Invulnerable Leap';
            if (act.type === 'ATTACK') return 'Melee Attack';
            if (act.type === 'RECT_SLASH') return 'Arm Blade';
            if (act.type === 'GRENADE') return 'Frag Grenade';
            if (act.type === 'ROCKET') return 'Rocket Launcher';
            if (act.type === 'BOMB_LAUNCHER') return 'Smoke Bomb Launcher';
            if (act.type === 'OIL_BARREL' || act.type === 'OIL_BOMB') return 'Oil Barrel';
            if (act.type === 'FIRE_CANNON') return 'Fire Cannon';
            if (act.type === 'DEPLOY_SENTRY') return 'Deploy Sentry';
            if (act.type === 'DEPLOY_TELEPORTER') return 'Teleporter';
            if (act.type === 'TELEKINESIS') return 'Telekinesis';
            if (act.type === 'NECROMANCY') return 'Necromancy';
            if (act.type === 'HEAL_STATION') return 'Healing Station';
            if (act.type === 'INVULNERABILITY_SHIELD') return 'Invulnerability Shield';
            if (act.type === 'SNIPER_SHOT') return 'Sniper Shot';
            if (act.type === 'SNIPER_SCOPE') return 'Scope In';
            if (act.type === 'TANK_SHOT') return 'Tank Cannon Shot';
            if (act.type === 'TANK_SCOPE') return 'Scope In';
            if (act.type === 'HOOK_PULL') return 'Grappling Hook';
            if (act.type === 'REVOLVER') return 'Revolver';
            if (act.type === 'MACHINE_PISTOL') return 'Machine Pistol';
            if (act.type === 'BUFF_HEAL') return 'Adrenaline Stim';
            if (act.type === 'BUFF_SMOKE') return 'Cigarette';
            if (act.type === 'BUFF_DESTRUCTIVE') return 'Destructive Shot';
            if (act.type === 'BUFF_THERMAL') return 'Thermal Vision';
            if (act.type === 'BUFF_CHAOS_SHOT') return 'Chaos Shot';
        }
        return act.name || '';
    }

    addCombatLog(msg, type = 'normal') {
        const log = document.getElementById('combatLog');
        const div = document.createElement('div');
        div.className = `log-entry ${type}`;
        div.innerText = msg;
        log.appendChild(div);
        log.scrollTop = log.scrollHeight;
    }

    isOutside7x7(posA, posB) {
        if (!posA || !posB) return false;
        return Math.abs(posA.x - posB.x) > 3 || Math.abs(posA.y - posB.y) > 3;
    }

    isPlayerStealthed() {
        const isHookman = this.player.charId === 'hookman' || (this.selectedCharacter && this.selectedCharacter.id === 'hookman');
        if (!isHookman) return false;
        if (this.playerRevealedTurns > 0) return false;
        return this.isOutside7x7(this.player, this.cpu);
    }

    isCpuStealthed() {
        const isHookman = this.cpu.charId === 'hookman' || (this.cpu.name && this.cpu.name.includes('Hookman'));
        if (!isHookman) return false;
        if (this.cpuRevealedTurns > 0) return false;
        return this.isOutside7x7(this.cpu, this.player);
    }

    getAlignedRangedDirection(fromX, fromY, toX, toY, maxRange = 5) {
        const dx = toX - fromX;
        const dy = toY - fromY;
        if (dy === 0 && Math.abs(dx) > 0 && Math.abs(dx) <= maxRange) {
            return dx > 0 ? 'RIGHT' : 'LEFT';
        }
        if (dx === 0 && Math.abs(dy) > 0 && Math.abs(dy) <= maxRange) {
            return dy > 0 ? 'DOWN' : 'UP';
        }
        if (Math.abs(dx) === Math.abs(dy) && Math.abs(dx) > 0 && Math.abs(dx) <= maxRange) {
            if (dx > 0 && dy > 0) return 'DOWN_RIGHT';
            if (dx > 0 && dy < 0) return 'UP_RIGHT';
            if (dx < 0 && dy > 0) return 'DOWN_LEFT';
            if (dx < 0 && dy < 0) return 'UP_LEFT';
        }
        return null;
    }

    // --- CPU AI Engine với Logic Chiến Thuật Riêng Biệt Cho Từng Nhân Vật ---
    getCpuBlindFireDir(simX, simY) {
        const allDirs = ['LEFT', 'UP_LEFT', 'DOWN_LEFT', 'UP', 'DOWN', 'RIGHT', 'UP_RIGHT', 'DOWN_RIGHT'];
        const validDirs = allDirs.filter(d => {
            const dObj = DIRECTIONS[d];
            const cx = simX + dObj.dx * 2;
            const cy = simY + dObj.dy * 2;
            return cx >= 0 && cx < GRID_COLS && cy >= 0 && cy < GRID_ROWS;
        });
        const preferredDirs = validDirs.filter(d => DIRECTIONS[d].dx < 0);
        const candidateDirs = (preferredDirs.length > 0 && Math.random() < 0.75) ? preferredDirs : validDirs;
        return candidateDirs[Math.floor(Math.random() * candidateDirs.length)] || 'LEFT';
    }

    createCpuPathMove(simX, simY, targetX, targetY, maxSteps = 2, away = false) {
        const path = [];
        let currX = simX, currY = simY;
        let dir = 'LEFT';

        for (let s = 0; s < maxSteps; s++) {
            const curDx = targetX - currX;
            const curDy = targetY - currY;
            if (!away && Math.abs(curDx) + Math.abs(curDy) <= 1 && s > 0) break;
            if (away && Math.abs(curDx) + Math.abs(curDy) === 0) break;

            const stepDir = away ? this.getDirectionAway(curDx, curDy, currX, currY) : this.getDirectionTowards(curDx, curDy);
            const dObj = DIRECTIONS[stepDir];
            currX = Math.max(0, Math.min(GRID_COLS - 1, currX + dObj.dx));
            currY = Math.max(0, Math.min(GRID_ROWS - 1, currY + dObj.dy));
            path.push({ dir: stepDir, x: currX, y: currY, symbol: dObj.symbol });
        }
        if (path.length > 0) dir = path[path.length - 1].dir;

        return {
            type: 'PATH_MOVE',
            name: `Lộ Trình (${path.length}b)`,
            name_en: `Route (${path.length} steps)`,
            icon: '👟',
            path: path,
            dir: dir,
            dirSymbol: path.map(p => p.symbol).join(' '),
            power: 0,
            range: 1
        };
    }

    findBestPathTowards(fromX, fromY, toX, toY, maxSteps = 2) {
        const move = this.createCpuPathMove(fromX, fromY, toX, toY, maxSteps);
        return move.path || [];
    }

    generateCpuQueue() {
        return this.generateCpuQueueForUnit(this.cpu);
    }

    generateCpuQueueForUnit(unit) {
        const queue = [];
        let simX = unit.x;
        let simY = unit.y;

        const charId = (unit.character && unit.character.id) || unit.charId || 'trooper';
        const simCooldowns = { ...unit.cooldowns };
        const simSkillAmmo = { ...unit.skillAmmo };
        const simBuffs = {
            adrenaline: { turnsLeft: (unit.buffs && unit.buffs.adrenaline) ? unit.buffs.adrenaline.turnsLeft : 0 },
            cigarette: { turnsLeft: (unit.buffs && unit.buffs.cigarette) ? unit.buffs.cigarette.turnsLeft : 0 },
            destructiveShot: (unit.buffs && unit.buffs.destructiveShot) || false,
            thermalVision: (unit.buffs && unit.buffs.thermalVision && unit.buffs.thermalVision.active) || false,
            chaosShot: (unit.buffs && unit.buffs.chaosShot) || false
        };

        const opposingTeam = unit.team === 'BLUE' ? this.redTeam : this.blueTeam;
        const livingOpponents = opposingTeam.filter(e => e.hp > 0);

        for (let i = 0; i < 4; i++) {
            let target = null;
            let minDist = 999;
            for (const opp of livingOpponents) {
                const d = Math.abs(opp.x - simX) + Math.abs(opp.y - simY);
                if (d < minDist) {
                    minDist = d;
                    target = opp;
                }
            }

            let targetX = (unit.team === 'BLUE' ? 15 : 4);
            let targetY = 3;
            let targetInvisible = false;

            if (this.gameMode === 'KOTH') {
                const opponentsInZone = livingOpponents.filter(opp => this.isInCaptureZone(opp.x, opp.y));
                if (opponentsInZone.length > 0) {
                    let minZDist = 999;
                    for (const opp of opponentsInZone) {
                        const d = Math.abs(opp.x - simX) + Math.abs(opp.y - simY);
                        if (d < minZDist) {
                            minZDist = d;
                            target = opp;
                        }
                    }
                } else if (!this.isInCaptureZone(simX, simY) && minDist > 2) {
                    target = null;
                    targetX = 10;
                    targetY = 3;
                }
            }

            if (target) {
                targetX = target.x;
                targetY = target.y;
                if (target.charId === 'hookman' && target.stealthRadius > 0 && target.revealedTurns <= 0) {
                    if (this.isOutside7x7(simX, simY, target.x, target.y)) {
                        targetInvisible = true;
                        targetX = 10;
                        targetY = 3;
                    }
                }
            }

            const dx = targetX - simX;
            const dy = targetY - simY;
            const dist = Math.abs(dx) + Math.abs(dy);

            let action = null;
            if (charId === 'trooper') {
                action = this.generateCpuActionTrooper(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'hookman') {
                action = this.generateCpuActionHookman(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'smoke_guy') {
                action = this.generateCpuActionSmokeGuy(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'razor') {
                action = this.generateCpuActionRazor(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'fireman') {
                action = this.generateCpuActionFireman(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'engie') {
                action = this.generateCpuActionEngie(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            } else if (charId === 'snipeman') {
                action = this.generateCpuActionSnipeman(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit);
            } else if (charId === 'hat_boom_man') {
                action = this.generateCpuActionHatBoomMan(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit);
            } else if (charId === 'fake_savior') {
                action = this.generateCpuActionFakeSavior(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit);
            } else if (charId === 'medic') {
                action = this.generateCpuActionMedic(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit);
            } else {
                action = this.generateCpuActionTrooper(i, simX, simY, dx, dy, dist, targetInvisible, simCooldowns, simSkillAmmo, simBuffs);
            }

            // Cập nhật vị trí mô phỏng
            if (action.type === 'PATH_MOVE' && action.path && action.path.length > 0) {
                const lastStep = action.path[action.path.length - 1];
                simX = lastStep.x;
                simY = lastStep.y;
            } else if (action.type === 'LEAP' || action.type === 'BOOM_LEAP') {
                const lD = DIRECTIONS[action.dir];
                const jumpDist = action.type === 'BOOM_LEAP' ? (action.range || 2) : (action.range || 3);
                let destX = Math.max(0, Math.min(GRID_COLS - 1, simX + lD.dx * jumpDist));
                let destY = Math.max(0, Math.min(GRID_ROWS - 1, simY + lD.dy * jumpDist));
                if (action.type === 'LEAP') {
                    const hasObstacle = livingOpponents.some(e => e.x === destX && e.y === destY) || this.groundHazards.some(h => h.x === destX && h.y === destY);
                    if (hasObstacle) {
                        destX = Math.max(0, Math.min(GRID_COLS - 1, destX + lD.dx * 2));
                        destY = Math.max(0, Math.min(GRID_ROWS - 1, destY + lD.dy * 2));
                    }
                }
                simX = destX;
                simY = destY;
            }

            if (action && !action.name_en) {
                const savedLang = this.lang;
                this.lang = 'en';
                action.name_en = this.getActionName(action);
                this.lang = savedLang;
            }
            queue.push(action);
        }

        return queue;
    }

    generateCpuActionTrooper(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        if (playerInvisible) {
            const shouldBlindFire = (stepIdx === 1 || stepIdx === 3 || Math.random() < 0.45);
            if (shouldBlindFire) {
                const bDir = this.getCpuBlindFireDir(simX, simY);
                if (!simCooldowns['TROOPER_ROCKET'] && Math.random() < 0.35) {
                    simCooldowns['TROOPER_ROCKET'] = 4;
                    return {
                        type: 'ROCKET',
                        skillId: 'TROOPER_ROCKET',
                        name: 'Bắn Bừa Tên Lửa',
                        icon: '🚀',
                        dir: bDir,
                        dirSymbol: DIRECTIONS[bDir].symbol,
                        power: 30,
                        range: 6,
                        cooldown: 4,
                        aoeRadius: 1,
                        isBlindFire: true
                    };
                }
                return {
                    type: 'RANGED_LINE',
                    skillId: 'TROOPER_RIFLE',
                    name: 'Bắn Bừa Bãi',
                    icon: '🔫',
                    dir: bDir,
                    dirSymbol: DIRECTIONS[bDir].symbol,
                    power: 20,
                    range: 5,
                    isBlindFire: true
                };
            }
            return this.createCpuPathMove(simX, simY, 10, 3, 2, false);
        }

        const alignedDir6 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 6);
        const alignedDir5 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 5);

        // 1. Tên lửa tầm 6 (Rocket)
        if (!simCooldowns['TROOPER_ROCKET'] && alignedDir6 && dist >= 2) {
            simCooldowns['TROOPER_ROCKET'] = 4;
            return {
                type: 'ROCKET',
                skillId: 'TROOPER_ROCKET',
                name: 'Tên Lửa',
                icon: '🚀',
                dir: alignedDir6,
                dirSymbol: DIRECTIONS[alignedDir6].symbol,
                power: 30,
                range: 6,
                cooldown: 4,
                aoeRadius: 1
            };
        }

        // 2. Lựu đạn hẹn giờ (Grenade)
        if (!simCooldowns['TROOPER_GRENADE'] && dist <= 5 && dist >= 2 && Math.random() < 0.65) {
            simCooldowns['TROOPER_GRENADE'] = 3;
            const gDir = this.getDirectionTowards(dx, dy);
            return {
                type: 'GRENADE',
                skillId: 'TROOPER_GRENADE',
                name: 'Lựu Đạn',
                icon: '💣',
                dir: gDir,
                dirSymbol: DIRECTIONS[gDir].symbol,
                power: 50,
                range: 5,
                cooldown: 3,
                fuse: 2,
                aoeRadius: 1,
                targetX: this.player.x,
                targetY: this.player.y
            };
        }

        // 3. Assault Rifle tầm 5
        if (alignedDir5 && Math.random() < 0.75) {
            return {
                type: 'RANGED_LINE',
                skillId: 'TROOPER_RIFLE',
                name: 'Assault Rifle',
                icon: '🔫',
                dir: alignedDir5,
                dirSymbol: DIRECTIONS[alignedDir5].symbol,
                power: 20,
                range: 5
            };
        }

        // 4. Nếu quá gần (dist <= 1)
        if (dist <= 1) {
            if (Math.random() < 0.35) {
                const sDir = this.getDirectionTowards(dx, dy);
                return { type: 'SHIELD', name: 'Khiên', icon: '🛡️', dir: sDir, dirSymbol: DIRECTIONS[sDir].symbol, power: 0, range: 1 };
            }
            return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 2, true);
        }

        // 5. Di chuyển duy trì cự ly tầm trung (3-4 ô)
        const shouldRetreat = (dist < 3);
        return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 2, shouldRetreat);
    }

    generateCpuActionHookman(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        // 1. Tiêm Adrenaline
        if (!simCooldowns['HOOKMAN_ADRENALINE'] && simBuffs.adrenaline.turnsLeft <= 0) {
            if (this.cpu.hp <= 75 || dist <= 5 || Math.random() < 0.3) {
                simCooldowns['HOOKMAN_ADRENALINE'] = 3;
                simBuffs.adrenaline.turnsLeft = 3;
                return {
                    type: 'BUFF_HEAL',
                    skillId: 'HOOKMAN_ADRENALINE',
                    name: 'Adrenaline',
                    icon: '💉',
                    dir: 'LEFT',
                    dirSymbol: '⚡',
                    power: 0,
                    duration: 3,
                    cooldown: 3
                };
            }
        }

        if (playerInvisible) {
            const shouldBlindFire = (stepIdx === 1 || stepIdx === 3 || Math.random() < 0.45);
            if (shouldBlindFire) {
                const bDir = this.getCpuBlindFireDir(simX, simY);
                return {
                    type: 'RANGED_VARIABLE',
                    skillId: 'HOOKMAN_PISTOL',
                    name: 'Bắn Bừa Bãi',
                    icon: '🔫',
                    dir: bDir,
                    dirSymbol: DIRECTIONS[bDir].symbol,
                    minPower: 15,
                    maxPower: 20,
                    range: 5,
                    isBlindFire: true
                };
            }
            // Hookman di chuyển tuần tra với budget = 3
            return this.createCpuPathMove(simX, simY, 10, 3, 3, false);
        }

        const alignedDir6 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 6);
        const alignedDir5 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 5);

        // 2. Móc Kéo (Hook Pull)
        const isTethered = this.activeHookTethers && this.activeHookTethers.some(t => t.source === 'CPU');
        if (!simCooldowns['HOOKMAN_HOOK'] && !isTethered && alignedDir6 && dist >= 2 && Math.random() < 0.8) {
            return {
                type: 'HOOK_PULL',
                skillId: 'HOOKMAN_HOOK',
                name: 'Móc Kéo',
                icon: '🪝',
                dir: alignedDir6,
                dirSymbol: DIRECTIONS[alignedDir6].symbol,
                power: 15,
                range: 6,
                cooldown: 4
            };
        }

        // 3. Silence Pistol
        if (alignedDir5 && Math.random() < 0.7) {
            return {
                type: 'RANGED_VARIABLE',
                skillId: 'HOOKMAN_PISTOL',
                name: 'Silence Pistol',
                icon: '🔫',
                dir: alignedDir5,
                dirSymbol: DIRECTIONS[alignedDir5].symbol,
                minPower: 15,
                maxPower: 20,
                range: 5
            };
        }

        // 4. Nếu quá gần (dist <= 1)
        if (dist <= 1) {
            if (Math.random() < 0.3) {
                const sDir = this.getDirectionTowards(dx, dy);
                return { type: 'SHIELD', name: 'Khiên', icon: '🛡️', dir: sDir, dirSymbol: DIRECTIONS[sDir].symbol, power: 0, range: 1 };
            }
            return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 3, true);
        }

        // 5. Di chuyển lẩn khuất (Hookman có 3 bước di chuyển)
        return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 3, false);
    }

    generateCpuActionSmokeGuy(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        // 1. Châm Thuốc Lá
        if (!simCooldowns['SMOKE_CIGARETTE'] && simBuffs.cigarette.turnsLeft <= 0 && Math.random() < 0.75) {
            simBuffs.cigarette.turnsLeft = 2;
            return {
                type: 'BUFF_SMOKE',
                skillId: 'SMOKE_CIGARETTE',
                name: 'Thuốc Lá',
                icon: '🚬',
                dir: 'LEFT',
                dirSymbol: '🔥',
                power: 0,
                duration: 2,
                cooldown: 3
            };
        }

        const bombAmmo = simSkillAmmo['SMOKE_BOMB_LAUNCHER'] !== undefined ? simSkillAmmo['SMOKE_BOMB_LAUNCHER'] : 2;

        if (playerInvisible) {
            const shouldBlindFire = (stepIdx === 1 || stepIdx === 3 || Math.random() < 0.45);
            if (shouldBlindFire) {
                const bDir = this.getCpuBlindFireDir(simX, simY);
                if (!simCooldowns['SMOKE_BOMB_LAUNCHER'] && bombAmmo > 0 && Math.random() < 0.4) {
                    simSkillAmmo['SMOKE_BOMB_LAUNCHER'] = bombAmmo - 1;
                    if (simSkillAmmo['SMOKE_BOMB_LAUNCHER'] === 0) {
                        simCooldowns['SMOKE_BOMB_LAUNCHER'] = 4;
                    }
                    return {
                        type: 'BOMB_LAUNCHER',
                        skillId: 'SMOKE_BOMB_LAUNCHER',
                        name: 'Bắn Bừa Bom Pháo',
                        icon: '💣',
                        dir: bDir,
                        dirSymbol: DIRECTIONS[bDir].symbol,
                        power: 30,
                        range: 6,
                        cooldown: 4,
                        aoeRadius: 1,
                        isBlindFire: true
                    };
                }
                return {
                    type: 'RANGED_LINE',
                    skillId: 'SMOKE_RIFLE',
                    name: 'Bắn Bừa Bãi',
                    icon: '🔫',
                    dir: bDir,
                    dirSymbol: DIRECTIONS[bDir].symbol,
                    power: 18,
                    range: 5,
                    isBlindFire: true
                };
            }
            const moveBudget = simBuffs.cigarette.turnsLeft > 0 ? 3 : 2;
            return this.createCpuPathMove(simX, simY, 10, 3, moveBudget, false);
        }

        const alignedDir6 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 6);
        const alignedDir5 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 5);

        // 2. Súng Bắn Bom (2 viên đạn)
        if (!simCooldowns['SMOKE_BOMB_LAUNCHER'] && bombAmmo > 0 && alignedDir6 && dist >= 2) {
            simSkillAmmo['SMOKE_BOMB_LAUNCHER'] = bombAmmo - 1;
            if (simSkillAmmo['SMOKE_BOMB_LAUNCHER'] === 0) {
                simCooldowns['SMOKE_BOMB_LAUNCHER'] = 4;
            }
            return {
                type: 'BOMB_LAUNCHER',
                skillId: 'SMOKE_BOMB_LAUNCHER',
                name: 'Súng Bắn Bom',
                icon: '💣',
                dir: alignedDir6,
                dirSymbol: DIRECTIONS[alignedDir6].symbol,
                power: 30,
                range: 6,
                cooldown: 4,
                aoeRadius: 1
            };
        }

        // 3. Combat Rifle
        if (alignedDir5 && Math.random() < 0.75) {
            return {
                type: 'RANGED_LINE',
                skillId: 'SMOKE_RIFLE',
                name: 'Combat Rifle',
                icon: '🔫',
                dir: alignedDir5,
                dirSymbol: DIRECTIONS[alignedDir5].symbol,
                power: 18,
                range: 5
            };
        }

        // 4. Nếu quá gần (dist <= 1)
        const moveBudget = simBuffs.cigarette.turnsLeft > 0 ? 3 : 2;
        if (dist <= 1) {
            if (Math.random() < 0.35) {
                const sDir = this.getDirectionTowards(dx, dy);
                return { type: 'SHIELD', name: 'Khiên', icon: '🛡️', dir: sDir, dirSymbol: DIRECTIONS[sDir].symbol, power: 0, range: 1 };
            }
            return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, moveBudget, true);
        }

        // 5. Di chuyển
        return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, moveBudget, false);
    }

    generateCpuActionRazor(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        const bladeAmmo = simSkillAmmo['RAZOR_BLADE'] !== undefined ? simSkillAmmo['RAZOR_BLADE'] : 2;

        if (!playerInvisible && !simCooldowns['RAZOR_BLADE'] && bladeAmmo > 0) {
            // 1. Kiểm tra Kiếm Gắn Tay (3x2 trong 4 hướng chính)
            const cardinalDirs = ['RIGHT', 'LEFT', 'UP', 'DOWN'];
            for (const cDir of cardinalDirs) {
                const slashTiles = this.getRectSlashTiles(simX, simY, cDir);
                if (slashTiles.some(t => t.x === this.player.x && t.y === this.player.y)) {
                    simSkillAmmo['RAZOR_BLADE'] = bladeAmmo - 1;
                    if (simSkillAmmo['RAZOR_BLADE'] === 0) {
                        simCooldowns['RAZOR_BLADE'] = 4;
                    }
                    return {
                        type: 'RECT_SLASH',
                        skillId: 'RAZOR_BLADE',
                        name: 'Kiếm Gắn Tay',
                        icon: '🗡️',
                        dir: cDir,
                        dirSymbol: DIRECTIONS[cDir].symbol,
                        power: 60,
                        cooldown: 4
                    };
                }
            }
        }

        if (playerInvisible) {
            const shouldBlindFire = (stepIdx === 1 || stepIdx === 3 || Math.random() < 0.45);
            if (shouldBlindFire) {
                const bDir = this.getCpuBlindFireDir(simX, simY);
                return {
                    type: 'RANGED_LINE',
                    skillId: 'RAZOR_PULSE_RIFLE',
                    name: 'Bắn Bừa Bãi',
                    icon: '⚡',
                    dir: bDir,
                    dirSymbol: DIRECTIONS[bDir].symbol,
                    power: 25,
                    range: 4,
                    isBlindFire: true
                };
            }
            return this.createCpuPathMove(simX, simY, 10, 3, 2, false);
        }

        // 2. Nhảy Đột Kích (Leap tầm 3)
        if (!simCooldowns['RAZOR_LEAP'] && dist >= 3 && dist <= 6 && Math.random() < 0.75) {
            simCooldowns['RAZOR_LEAP'] = 3;
            const leapDir = this.getDirectionTowards(dx, dy);
            return {
                type: 'LEAP',
                skillId: 'RAZOR_LEAP',
                name: 'Nhảy Đột Kích',
                icon: '🦘',
                dir: leapDir,
                dirSymbol: DIRECTIONS[leapDir].symbol,
                range: 3,
                leapExtra: 2,
                cooldown: 3
            };
        }

        // 3. Pulse Rifle tầm 4
        const alignedDir4 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 4);
        if (alignedDir4 && Math.random() < 0.7) {
            return {
                type: 'RANGED_LINE',
                skillId: 'RAZOR_PULSE_RIFLE',
                name: 'Pulse Rifle',
                icon: '⚡',
                dir: alignedDir4,
                dirSymbol: DIRECTIONS[alignedDir4].symbol,
                power: 25,
                range: 4
            };
        }

        // 4. Nếu quá gần (dist <= 1)
        if (dist <= 1) {
            if (Math.random() < 0.3) {
                const sDir = this.getDirectionTowards(dx, dy);
                return { type: 'SHIELD', name: 'Khiên', icon: '🛡️', dir: sDir, dirSymbol: DIRECTIONS[sDir].symbol, power: 0, range: 1 };
            }
            return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 2, true);
        }

        // 5. Di chuyển áp sát
        return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 2, false);
    }

    generateCpuActionFireman(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        if (playerInvisible) {
            const shouldBlindFire = (stepIdx === 1 || stepIdx === 3 || Math.random() < 0.45);
            if (shouldBlindFire) {
                const bDir = this.getCpuBlindFireDir(simX, simY);
                if (!simCooldowns['FIREMAN_FIRE_CANNON'] && Math.random() < 0.35) {
                    simCooldowns['FIREMAN_FIRE_CANNON'] = 4;
                    return {
                        type: 'FIRE_CANNON',
                        skillId: 'FIREMAN_FIRE_CANNON',
                        name: 'Bắn Bừa Đại Bác Lửa',
                        icon: '💥',
                        dir: bDir,
                        dirSymbol: DIRECTIONS[bDir].symbol,
                        power: 15,
                        range: 5,
                        cooldown: 4,
                        aoeRadius: 1,
                        fireZoneDuration: 2,
                        isBlindFire: true
                    };
                }
                if (!simCooldowns['FIREMAN_OIL_BARREL'] && Math.random() < 0.35) {
                    simCooldowns['FIREMAN_OIL_BARREL'] = 3;
                    return {
                        type: 'OIL_BARREL',
                        skillId: 'FIREMAN_OIL_BARREL',
                        name: 'Ném Bừa Thùng Dầu',
                        icon: '🛢️',
                        dir: bDir,
                        dirSymbol: DIRECTIONS[bDir].symbol,
                        power: 0,
                        range: 6,
                        cooldown: 3,
                        aoeRadius: 1,
                        isBlindFire: true
                    };
                }
                return {
                    type: 'RANGED_LINE',
                    skillId: 'FIREMAN_GATTLING_FIRE',
                    name: 'Bắn Bừa Gattling Fire',
                    icon: '🔥',
                    dir: bDir,
                    dirSymbol: DIRECTIONS[bDir].symbol,
                    power: 15,
                    range: 5,
                    burnTurns: 3,
                    burnDmg: 5,
                    isBlindFire: true
                };
            }
            return this.createCpuPathMove(simX, simY, 10, 3, 2, false);
        }

        const alignedDir6 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 6);
        const alignedDir5 = this.getAlignedRangedDirection(simX, simY, this.player.x, this.player.y, 5);

        // 1. Thùng Dầu tầm 6 ô (Oil Barrel): Ưu tiên ném khi đối thủ chưa dính dầu
        if (!simCooldowns['FIREMAN_OIL_BARREL'] && dist <= 6 && dist >= 2 && (!this.player.isOiled || Math.random() < 0.3)) {
            const barrelDir = alignedDir6 || this.getDirectionTowards(dx, dy);
            simCooldowns['FIREMAN_OIL_BARREL'] = 3;
            return {
                type: 'OIL_BARREL',
                skillId: 'FIREMAN_OIL_BARREL',
                name: 'Thùng Dầu',
                icon: '🛢️',
                dir: barrelDir,
                dirSymbol: DIRECTIONS[barrelDir].symbol,
                power: 0,
                range: 6,
                cooldown: 3,
                aoeRadius: 1
            };
        }

        // 2. Đại Bác Lửa tầm 5 ô (Fire Cannon)
        if (!simCooldowns['FIREMAN_FIRE_CANNON'] && dist <= 5 && dist >= 2 && Math.random() < 0.7) {
            const cannonDir = alignedDir5 || this.getDirectionTowards(dx, dy);
            simCooldowns['FIREMAN_FIRE_CANNON'] = 4;
            return {
                type: 'FIRE_CANNON',
                skillId: 'FIREMAN_FIRE_CANNON',
                name: 'Đại Bác Lửa',
                icon: '💥',
                dir: cannonDir,
                dirSymbol: DIRECTIONS[cannonDir].symbol,
                power: 15,
                range: 5,
                cooldown: 4,
                aoeRadius: 1,
                fireZoneDuration: 2
            };
        }

        // 3. Gattling Fire tầm 5 ô (Vũ khí chính)
        if (alignedDir5 && dist <= 5) {
            return {
                type: 'RANGED_LINE',
                skillId: 'FIREMAN_GATTLING_FIRE',
                name: 'Gattling Fire',
                icon: '🔥',
                dir: alignedDir5,
                dirSymbol: DIRECTIONS[alignedDir5].symbol,
                power: 15,
                range: 5,
                burnTurns: 3,
                burnDmg: 5
            };
        }

        // 4. Nếu chưa vào tầm ngắm hoặc khoảng cách xa: Di chuyển tiếp cận
        return this.createCpuPathMove(simX, simY, this.player.x, this.player.y, 2, false);
    }

    generateCpuActionEngie(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs) {
        const moveBudget = 2;
        const targetDir = this.getDirectionTowards(dx, dy);

        // 1. Xây Sentry tự động (DEPLOY_SENTRY) nếu chưa hồi chiêu
        if (!simCooldowns['ENGIE_SENTRY'] && Math.random() < 0.75) {
            simCooldowns['ENGIE_SENTRY'] = 2;
            return {
                type: 'DEPLOY_SENTRY',
                skillId: 'ENGIE_SENTRY',
                name: 'Xây Sentry',
                icon: '🤖',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                power: 10,
                sentryHp: 50,
                sentryRange: 5,
                cooldown: 2
            };
        }

        // 2. Mở Cổng Dịch Chuyển (DEPLOY_TELEPORTER) nếu ở xa (dist >= 4) và chưa hồi chiêu
        if (!simCooldowns['ENGIE_TELEPORTER'] && dist >= 4 && Math.random() < 0.7) {
            simCooldowns['ENGIE_TELEPORTER'] = 3;
            return {
                type: 'DEPLOY_TELEPORTER',
                skillId: 'ENGIE_TELEPORTER',
                name: 'Cổng Dịch Chuyển',
                icon: '🌀',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                range: 5,
                portalHp: 60,
                cooldown: 3
            };
        }

        // 3. Bắn Súng Thanh Sắt (ENGIE_NAILGUN) nếu thẳng hàng tầm 5 hoặc trong tầm 5
        const alignedDir5 = this.getAlignedRangedDirection(simX, simY, simX + dx, simY + dy, 5);
        if (alignedDir5 && Math.random() < 0.8) {
            return {
                type: 'RANGED_LINE',
                skillId: 'ENGIE_NAILGUN',
                name: 'Súng Thanh Sắt',
                icon: '🔩',
                dir: alignedDir5,
                dirSymbol: DIRECTIONS[alignedDir5].symbol,
                power: 15,
                range: 5
            };
        }

        // 4. Di chuyển tiếp cận hoặc giữ cự ly bằng Lộ Trình (PATH_MOVE)
        if (dist > 3 || Math.random() < 0.6) {
            return this.createCpuPathMove(simX, simY, simX + dx, simY + dy, moveBudget, false);
        }

        // Bắn ngắm
        return {
            type: 'RANGED_LINE',
            skillId: 'ENGIE_NAILGUN',
            name: 'Súng Thanh Sắt',
            icon: '🔩',
            dir: targetDir,
            dirSymbol: DIRECTIONS[targetDir].symbol,
            power: 15,
            range: 5
        };
    }

    generateCpuActionSnipeman(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit) {
        let isScoped = (unit && unit.isScoped) || false;
        if (queue) {
            for (const a of queue) {
                if (a.type === 'SNIPER_SCOPE') isScoped = true;
                else if (a.type === 'SNIPER_SHOT') isScoped = false;
            }
        }
        const hasDestructive = Boolean(simBuffs.destructiveShot);
        const hasThermal = Boolean(simBuffs.thermalVision);
        const sniperRange = 6 + (hasThermal ? 1 : 0);
        const targetDir = this.getDirectionTowards(dx, dy);

        // 1. Tầm Nhìn Dò Nhiệt (BUFF_THERMAL): hỗ trợ toàn đội nếu chưa hồi chiêu
        if (!simCooldowns['SNIPER_THERMAL'] && Math.random() < 0.6) {
            simCooldowns['SNIPER_THERMAL'] = 4;
            simBuffs.thermalVision = true;
            return {
                type: 'BUFF_THERMAL',
                skillId: 'SNIPER_THERMAL',
                name: 'Tầm Nhìn Dò Nhiệt',
                icon: '🔭',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                rangeBonus: 1,
                cooldown: 4
            };
        }

        // 2. Phát Bắn Hủy Diệt (BUFF_DESTRUCTIVE): cường hóa súng tỉa +30% và xuyên thấu
        if (!simCooldowns['SNIPER_DESTRUCTIVE'] && !hasDestructive && Math.random() < 0.75) {
            simCooldowns['SNIPER_DESTRUCTIVE'] = 3;
            simBuffs.destructiveShot = true;
            return {
                type: 'BUFF_DESTRUCTIVE',
                skillId: 'SNIPER_DESTRUCTIVE',
                name: 'Phát Bắn Hủy Diệt',
                icon: '⚡',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                dmgBonusPercent: 30,
                cooldown: 3
            };
        }

        // 3. Kiểm tra mục tiêu có thẳng hàng trong tầm sniperRange không
        const alignedDir = this.getAlignedRangedDirection(simX, simY, simX + dx, simY + dy, sniperRange);
        if (alignedDir) {
            if (isScoped) {
                // Đã ngắm -> BẮN SÚNG TỈA
                simBuffs.destructiveShot = false;
                simBuffs.thermalVision = false;
                return {
                    type: 'SNIPER_SHOT',
                    skillId: 'SNIPER_SHOT',
                    name: 'Bắn Súng Tỉa',
                    icon: '💥',
                    dir: alignedDir,
                    dirSymbol: DIRECTIONS[alignedDir].symbol,
                    range: 6,
                    minPower: 25,
                    maxPower: 50
                };
            } else {
                // Chưa ngắm -> VÀO CHẾ ĐỘ NGẮM BẮN
                return {
                    type: 'SNIPER_SCOPE',
                    skillId: 'SNIPER_SCOPE',
                    name: 'Ngắm Bắn',
                    icon: '🎯',
                    dir: alignedDir,
                    dirSymbol: DIRECTIONS[alignedDir].symbol,
                    range: 0,
                    power: 0
                };
            }
        }

        // 4. Di chuyển giữ cự ly sniping (cự ly 3-6)
        const moveBudget = isScoped ? 1 : 2;
        if (dist < 3) {
            // Quá gần! Lùi lại để tăng sát thương tầm xa
            return this.createCpuPathMove(simX, simY, simX - dx, simY - dy, moveBudget, false);
        } else if (dist > sniperRange || Math.random() < 0.6) {
            // Tiếp cận vào tầm bắn
            return this.createCpuPathMove(simX, simY, simX + dx, simY + dy, moveBudget, false);
        }

        // 5. Nếu chưa ngắm và đã ở vị trí tốt: Ngắm bắn
        if (!isScoped) {
            return {
                type: 'SNIPER_SCOPE',
                skillId: 'SNIPER_SCOPE',
                name: 'Ngắm Bắn',
                icon: '🎯',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                range: 0,
                power: 0
            };
        }

        // 6. Đã ngắm nhưng không thẳng hàng: bắn thăm dò theo hướng mục tiêu
        return {
            type: 'SNIPER_SHOT',
            skillId: 'SNIPER_SHOT',
            name: 'Bắn Súng Tỉa',
            icon: '💥',
            dir: targetDir,
            dirSymbol: DIRECTIONS[targetDir].symbol,
            range: 6,
            minPower: 25,
            maxPower: 50
        };
    }

    generateCpuActionFakeSavior(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit) {
        const targetDir = this.getDirectionTowards(dx, dy);

        // 1. Necromancy: Triệu hồi 2 thây ma CPU nếu chưa có thây ma sống hoặc chưa hồi chiêu
        const hasLiveZombies = this.zombies && this.zombies.some(z => z.owner === unit && z.hp > 0);
        if (!simCooldowns['SAVIOR_NECROMANCY'] && (!hasLiveZombies || Math.random() < 0.35)) {
            simCooldowns['SAVIOR_NECROMANCY'] = 4;
            return {
                type: 'NECROMANCY',
                skillId: 'SAVIOR_NECROMANCY',
                name: 'Necromancy',
                icon: '🧟',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                zombieHp: 40,
                zombiePower: 35,
                cooldown: 4
            };
        }

        // 2. Telekinesis: Nếu kẻ địch trong vùng 5x5 (Chebyshev <= 2)
        if (!simCooldowns['SAVIOR_TELEKINESIS'] && Math.abs(dx) <= 2 && Math.abs(dy) <= 2) {
            simCooldowns['SAVIOR_TELEKINESIS'] = 3;
            return {
                type: 'TELEKINESIS',
                skillId: 'SAVIOR_TELEKINESIS',
                name: 'Telekinesis',
                icon: '🔮',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                range: 2,
                power: 20,
                comboPower: 30,
                knockback: 3,
                cooldown: 3
            };
        }

        // 3. Revolver: Bắn súng ổ xoay tầm 4 nếu thẳng hàng
        const alignedDir = this.getAlignedRangedDirection(simX, simY, simX + dx, simY + dy, 4);
        if (alignedDir && (!playerInvisible || dist <= 3)) {
            return {
                type: 'REVOLVER',
                skillId: 'SAVIOR_REVOLVER',
                name: 'Revolver',
                icon: '🔫',
                dir: alignedDir,
                dirSymbol: DIRECTIONS[alignedDir].symbol,
                range: 4,
                power: 25
            };
        }

        // 4. Di chuyển tiếp cận hoặc căn chỉnh góc bắn bằng Lộ Trình (PATH_MOVE 2 bước)
        const moveBudget = (unit && unit.moveBudget) || 2;
        const path = this.findBestPathTowards(simX, simY, simX + dx, simY + dy, moveBudget);
        return {
            type: 'PATH_MOVE',
            skillId: 'SAVIOR_MOVE',
            name: `Lộ Trình (${path.length}b)`,
            name_en: `Route (${path.length} steps)`,
            icon: '👟',
            path: path,
            steps: path.length,
            dir: path.length > 0 ? path[path.length - 1].dir : targetDir,
            dirSymbol: DIRECTIONS[path.length > 0 ? path[path.length - 1].dir : targetDir].symbol
        };
    }

    generateCpuActionMedic(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit) {
        const targetDir = this.getDirectionTowards(dx, dy);
        const myTeam = unit ? (unit.team === 'BLUE' ? this.blueTeam : this.redTeam) : [];
        const livingAllies = myTeam.filter(u => u.hp > 0);

        // 1. Hộ Thuẫn Bất Tử: Dùng nếu có đồng đội (hoặc Medic) thấp máu (<= 75 HP) hoặc chưa hồi chiêu
        if (!simCooldowns['MEDIC_INVULNERABILITY_SHIELD']) {
            const injuredAlly = livingAllies.find(u => u.hp <= 75 && Math.hypot(u.x - simX, u.y - simY) <= 8);
            if (injuredAlly || (unit && unit.hp <= 75) || Math.random() < 0.25) {
                simCooldowns['MEDIC_INVULNERABILITY_SHIELD'] = 4;
                const targetAlly = injuredAlly || unit;
                const shieldDir = targetAlly ? this.getDirectionTowards(targetAlly.x - simX, targetAlly.y - simY) : targetDir;
                return {
                    type: 'INVULNERABILITY_SHIELD',
                    skillId: 'MEDIC_INVULNERABILITY_SHIELD',
                    name: 'Hộ Thuẫn Bất Tử',
                    icon: '🛡️',
                    dir: shieldDir,
                    dirSymbol: DIRECTIONS[shieldDir].symbol,
                    range: 8,
                    cooldown: 4,
                    targetUnit: targetAlly
                };
            }
        }

        // 2. Trạm Hồi Máu (HEAL_STATION): Không cooldown. Dùng nếu bản thân hoặc đồng đội trong 5x5 mất máu
        const woundedNearby = livingAllies.some(u => u.hp < u.maxHp && Math.abs(u.x - simX) <= 2 && Math.abs(u.y - simY) <= 2);
        if (woundedNearby || (unit && unit.hp <= 85)) {
            return {
                type: 'HEAL_STATION',
                skillId: 'MEDIC_HEAL_STATION',
                name: 'Trạm Hồi Máu',
                icon: '🏥',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                range: 2,
                power: 10,
                cooldown: 0
            };
        }

        // 3. Machine Pistol: Bắn tiểu liên tầm 5 theo 8 hướng (12.5 DMG)
        const alignedDir = this.getAlignedRangedDirection(simX, simY, simX + dx, simY + dy, 5);
        if (alignedDir && (!playerInvisible || dist <= 3)) {
            return {
                type: 'MACHINE_PISTOL',
                skillId: 'MEDIC_MACHINE_PISTOL',
                name: 'Machine Pistol',
                icon: '🔫',
                dir: alignedDir,
                dirSymbol: DIRECTIONS[alignedDir].symbol,
                range: 5,
                power: 12.5
            };
        }

        // 4. Di chuyển bằng Lộ Trình (PATH_MOVE 2 bước) tiếp cận hoặc hỗ trợ
        const moveBudget = (unit && unit.moveBudget) || 2;
        const path = this.findBestPathTowards(simX, simY, simX + dx, simY + dy, moveBudget);
        return {
            type: 'PATH_MOVE',
            skillId: 'MEDIC_MOVE',
            name: "Lộ Trình (" + path.length + "b)",
            name_en: "Route (" + path.length + " steps)",
            icon: '👟',
            path: path,
            steps: path.length,
            dir: path.length > 0 ? path[path.length - 1].dir : targetDir,
            dirSymbol: DIRECTIONS[path.length > 0 ? path[path.length - 1].dir : targetDir].symbol
        };
    }

    generateCpuActionHatBoomMan(stepIdx, simX, simY, dx, dy, dist, playerInvisible, simCooldowns, simSkillAmmo, simBuffs, queue, unit) {
        let isScoped = (unit && unit.isScoped) || false;
        if (queue) {
            for (const a of queue) {
                if (a.type === 'TANK_SCOPE') isScoped = true;
                else if (a.type === 'TANK_SHOT') isScoped = false;
            }
        }
        const hasChaos = Boolean(simBuffs.chaosShot);
        const cannonRange = 6;
        const targetDir = this.getDirectionTowards(dx, dy);

        // 1. Cú Bật Nhảy (BOOM_LEAP): Bật nhảy thoát hiểm hoặc tiếp cận nếu bị áp sát (dist <= 2) hoặc né đòn
        if (!simCooldowns['BOOM_LEAP'] && (dist <= 2 || Math.random() < 0.35)) {
            simCooldowns['BOOM_LEAP'] = 2;
            const leapDir = dist <= 2 ? this.getDirectionAway(dx, dy, simX, simY) : targetDir;
            return {
                type: 'BOOM_LEAP',
                skillId: 'BOOM_LEAP',
                name: 'Cú Bật Nhảy',
                icon: '🦘',
                dir: leapDir,
                dirSymbol: DIRECTIONS[leapDir].symbol,
                range: 2,
                cooldown: 2
            };
        }

        // 2. Phát Bắn Rối Loạn (BUFF_CHAOS_SHOT): Cường hóa đại bác +30% & nổ 5x5
        if (!simCooldowns['BOOM_CHAOS_SHOT'] && !hasChaos && Math.random() < 0.75) {
            simCooldowns['BOOM_CHAOS_SHOT'] = 3;
            simBuffs.chaosShot = true;
            return {
                type: 'BUFF_CHAOS_SHOT',
                skillId: 'BOOM_CHAOS_SHOT',
                name: 'Phát Bắn Rối Loạn',
                icon: '🌀',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                dmgBonusPercent: 30,
                aoeRadius: 2,
                cooldown: 3
            };
        }

        // 3. Kiểm tra mục tiêu có thẳng hàng trong tầm 6 không
        const alignedDir = this.getAlignedRangedDirection(simX, simY, simX + dx, simY + dy, cannonRange);
        if (alignedDir) {
            if (isScoped) {
                // Đã ngắm -> BẮN ĐẠI BÁC
                simBuffs.chaosShot = false;
                return {
                    type: 'TANK_SHOT',
                    skillId: 'TANK_SHOT',
                    name: 'Bắn Nòng Xe Tăng',
                    icon: '💥',
                    dir: alignedDir,
                    dirSymbol: DIRECTIONS[alignedDir].symbol,
                    range: 6,
                    minPower: 15,
                    maxPower: 45,
                    aoeRadius: 1,
                    splashPower: 10
                };
            } else {
                // Chưa ngắm -> VÀO CHẾ ĐỘ NGẮM BẮN
                return {
                    type: 'TANK_SCOPE',
                    skillId: 'TANK_SCOPE',
                    name: 'Ngắm Nòng Pháo',
                    icon: '🎯',
                    dir: alignedDir,
                    dirSymbol: DIRECTIONS[alignedDir].symbol,
                    range: 0,
                    power: 0
                };
            }
        }

        // 4. Di chuyển giữ cự ly sniping 3-6 ô
        const moveBudget = isScoped ? 1 : 2;
        if (dist < 3) {
            return this.createCpuPathMove(simX, simY, simX - dx, simY - dy, moveBudget, false);
        } else if (dist > cannonRange || Math.random() < 0.6) {
            return this.createCpuPathMove(simX, simY, simX + dx, simY + dy, moveBudget, false);
        }

        // 5. Nếu chưa ngắm và đã ở vị trí tốt: Ngắm bắn
        if (!isScoped) {
            return {
                type: 'TANK_SCOPE',
                skillId: 'TANK_SCOPE',
                name: 'Ngắm Nòng Pháo',
                icon: '🎯',
                dir: targetDir,
                dirSymbol: DIRECTIONS[targetDir].symbol,
                range: 0,
                power: 0
            };
        }

        // 6. Đã ngắm: Bắn theo hướng mục tiêu
        return {
            type: 'TANK_SHOT',
            skillId: 'TANK_SHOT',
            name: 'Bắn Nòng Xe Tăng',
            icon: '💥',
            dir: targetDir,
            dirSymbol: DIRECTIONS[targetDir].symbol,
            range: 6,
            minPower: 15,
            maxPower: 45,
            aoeRadius: 1,
            splashPower: 10
        };
    }

    getDirectionTowards(dx, dy) {
        if (dx !== 0 && dy !== 0 && Math.random() < 0.6) {
            if (dx > 0 && dy < 0) return 'UP_RIGHT';
            if (dx > 0 && dy > 0) return 'DOWN_RIGHT';
            if (dx < 0 && dy < 0) return 'UP_LEFT';
            if (dx < 0 && dy > 0) return 'DOWN_LEFT';
        }
        if (Math.abs(dx) > Math.abs(dy)) {
            return dx > 0 ? 'RIGHT' : 'LEFT';
        } else if (dy !== 0) {
            return dy > 0 ? 'DOWN' : 'UP';
        }
        return dx > 0 ? 'RIGHT' : 'LEFT';
    }

    getDirectionAway(dx, dy, x, y) {
        if (dx !== 0 && dy !== 0 && Math.random() < 0.5) {
            const diagX = dx > 0 ? -1 : 1;
            const diagY = dy > 0 ? -1 : 1;
            const targetX = x + diagX;
            const targetY = y + diagY;
            if (targetX >= 0 && targetX < GRID_COLS && targetY >= 0 && targetY < GRID_ROWS) {
                if (diagX > 0 && diagY < 0) return 'UP_RIGHT';
                if (diagX > 0 && diagY > 0) return 'DOWN_RIGHT';
                if (diagX < 0 && diagY < 0) return 'UP_LEFT';
                if (diagX < 0 && diagY > 0) return 'DOWN_LEFT';
            }
        }
        const oppX = dx > 0 ? 'LEFT' : 'RIGHT';
        if (oppX === 'LEFT' && x === 0) return y < 3 ? 'DOWN' : 'UP';
        if (oppX === 'RIGHT' && x === GRID_COLS - 1) return y < 3 ? 'DOWN' : 'UP';
        return oppX;
    }

    // --- Khóa lệnh & Thực thi lượt đồng thời ---
    commitTurn() {
        if (this.phase !== 'PLANNING') return;

        if (this.isTwoPlayerMode) {
            if (this.p1Queue.length !== 4 || this.p2Queue.length !== 4) return;
            this.cancelPathPlanning();
            this.phase = 'RESOLVING';
            if (window.soundCtrl) window.soundCtrl.playCommit();
            this.addCombatLog(`--- [${this.lang === 'en' ? 'TURN' : 'LƯỢT'} ${this.turn}] ${this.lang === 'en' ? 'WEGO SIMULTANEOUS RESOLUTION' : 'THỰC THI ĐỒNG THỜI WEGO'} ---`, 'system');

            // 1. Gán queue và hồi chiêu cho P1
            this.p1Unit.queue = [...this.p1Queue];
            for (const act of this.p1Queue) {
                if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                    this.p1Unit.cooldowns[act.skillId] = act.cooldown;
                }
            }

            // 2. Gán queue và hồi chiêu cho P2
            this.p2Unit.queue = [...this.p2Queue];
            for (const act of this.p2Queue) {
                if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                    this.p2Unit.cooldowns[act.skillId] = act.cooldown;
                }
            }

            // 3. Sinh hàng đợi hành động cho toàn bộ CPU còn lại
            const allUnits = [...this.blueTeam, ...this.redTeam];
            for (const u of allUnits) {
                if (u !== this.p1Unit && u !== this.p2Unit) {
                    if (u.hp > 0) {
                        u.queue = this.generateCpuQueueForUnit(u);
                        for (const act of u.queue) {
                            if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                                u.cooldowns[act.skillId] = act.cooldown;
                            }
                        }
                    } else {
                        u.queue = [];
                    }
                }
            }

            this.playerQueue = this.p1Unit.queue;
            this.cpuQueue = this.p2Unit.queue;

            for (let i = 0; i < 4; i++) {
                const cSlot = document.getElementById(`c-slot-${i}`);
                if (cSlot) {
                    cSlot.className = 'queue-slot';
                    cSlot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${this.lang === 'en' ? 'Secret' : 'Bí mật'}</span>`;
                }
                const pSlot = document.getElementById(`p-slot-${i}`);
                if (pSlot) {
                    pSlot.className = 'queue-slot';
                    pSlot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${this.lang === 'en' ? 'Secret' : 'Bí mật'}</span>`;
                }
            }

            this.updateHUD();
            this.currentStep = 0;
            this.executeResolutionStep(0);
            return;
        }

        if (this.playerQueue.length !== 4) return;

        this.cancelPathPlanning();
        this.phase = 'RESOLVING';
        if (window.soundCtrl) window.soundCtrl.playCommit();
        this.addCombatLog(`--- [${this.lang === 'en' ? 'TURN' : 'LƯỢT'} ${this.turn}] ${this.lang === 'en' ? 'EXECUTION LOCKED' : 'KHÓA LỆNH THỰC THI'} ---`, 'system');

        // 1. Đặt hồi chiêu cho các kỹ năng được chọn của Người chơi
        for (const act of this.playerQueue) {
            if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                this.cooldowns[act.skillId] = act.cooldown;
            }
        }
        this.player.queue = [...this.playerQueue];

        // 2. Sinh hàng đợi hành động cho toàn bộ Đồng minh CPU Đội Xanh
        for (let i = 1; i < this.blueTeam.length; i++) {
            const ally = this.blueTeam[i];
            if (ally.hp > 0) {
                ally.queue = this.generateCpuQueueForUnit(ally);
                for (const act of ally.queue) {
                    if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                        ally.cooldowns[act.skillId] = act.cooldown;
                    }
                }
            } else {
                ally.queue = [];
            }
        }

        // 3. Sinh hàng đợi hành động cho toàn bộ Kẻ địch CPU Đội Đỏ
        for (let j = 0; j < this.redTeam.length; j++) {
            const enemy = this.redTeam[j];
            if (enemy.hp > 0) {
                enemy.queue = this.generateCpuQueueForUnit(enemy);
                for (const act of enemy.queue) {
                    if (act.cooldown && act.type !== 'HOOK_PULL' && act.type !== 'BUFF_SMOKE' && act.type !== 'BOMB_LAUNCHER' && act.type !== 'RECT_SLASH') {
                        enemy.cooldowns[act.skillId] = act.cooldown;
                    }
                }
            } else {
                enemy.queue = [];
            }
        }

        this.cpuQueue = (this.cpu && this.cpu.queue) ? this.cpu.queue : [];

        for (let i = 0; i < 4; i++) {
            const slot = document.getElementById(`c-slot-${i}`);
            if (slot) {
                slot.className = 'queue-slot';
                slot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${this.lang === 'en' ? 'Secret' : 'Bí mật'}</span>`;
            }
        }

        this.updateHUD();
        this.currentStep = 0;
        this.executeResolutionStep(0);
    }

    async executeResolutionStep(stepIndex) {
        if (stepIndex >= 4) {
            this.finishTurn();
            return;
        }

        // Đồng bộ hàng đợi với playerQueue và cpuQueue
        if (this.player && this.playerQueue && (!this.player.queue || this.player.queue.length === 0 || this.player.queue !== this.playerQueue)) {
            this.player.queue = this.playerQueue;
        }
        if (this.cpu && this.cpuQueue && (!this.cpu.queue || this.cpu.queue.length === 0 || this.cpu.queue !== this.cpuQueue)) {
            this.cpu.queue = this.cpuQueue;
        }

        this.currentStep = stepIndex;
        this.updateHUD();

        for (let i = 0; i < 4; i++) {
            const pSlot = document.getElementById(`p-slot-${i}`);
            const cSlot = document.getElementById(`c-slot-${i}`);
            if (pSlot) pSlot.classList.toggle('active-step', i === stepIndex);
            if (cSlot) cSlot.classList.toggle('active-step', i === stepIndex);
        }

        const pAct = this.playerQueue[stepIndex];
        const cAct = (this.cpu && this.cpu.queue && this.cpu.queue[stepIndex]) ? this.cpu.queue[stepIndex] : null;

        if (this.isTwoPlayerMode) {
            const p1Act = (this.p1Unit && this.p1Unit.queue) ? this.p1Unit.queue[stepIndex] : pAct;
            const p2Act = (this.p2Unit && this.p2Unit.queue) ? this.p2Unit.queue[stepIndex] : cAct;

            const pSlot = document.getElementById(`p-slot-${stepIndex}`);
            if (pSlot && p1Act) {
                pSlot.className = 'queue-slot filled active-step';
                pSlot.innerHTML = `
                    <span class="slot-step-num">#${stepIndex + 1}</span>
                    <span class="slot-icon">${p1Act.icon}</span>
                    <span class="slot-name">${this.getActionName(p1Act)}</span>
                    <span class="slot-dir" style="letter-spacing: 2px;">${p1Act.dirSymbol || ''}</span>
                `;
            }

            const cSlot = document.getElementById(`c-slot-${stepIndex}`);
            if (cSlot && p2Act) {
                cSlot.className = 'queue-slot filled active-step';
                cSlot.innerHTML = `
                    <span class="slot-step-num">#${stepIndex + 1}</span>
                    <span class="slot-icon">${p2Act.icon}</span>
                    <span class="slot-name">${this.getActionName(p2Act)}</span>
                    <span class="slot-dir" style="letter-spacing: 2px;">${p2Act.dirSymbol || ''}</span>
                `;
            }
        } else {
            // Giải mã lệnh CPU chủ lực cho giao diện
            const cSlot = document.getElementById(`c-slot-${stepIndex}`);
            if (cSlot && cAct) {
                cSlot.className = 'queue-slot filled active-step';
                cSlot.innerHTML = `
                    <span class="slot-step-num">#${stepIndex + 1}</span>
                    <span class="slot-icon">${cAct.icon}</span>
                    <span class="slot-name">${this.getActionName(cAct)}</span>
                    <span class="slot-dir" style="letter-spacing: 2px;">${cAct.dirSymbol || ''}</span>
                `;
            }
        }

        // Lấy danh sách toàn bộ chiến binh còn sống
        const allAlive = [...this.blueTeam, ...this.redTeam].filter(u => u.hp > 0);

        // Đặt lại trạng thái Khiên và hướng nhìn
        for (const unit of allAlive) {
            unit.shieldDir = null;
            unit.stepStartX = unit.x;
            unit.stepStartY = unit.y;
            unit.lastMoveDx = 0;
            unit.lastMoveDy = 0;
            const act = unit.queue ? unit.queue[stepIndex] : null;
            if (act && act.dir) {
                unit.dir = act.dir;
            }
        }

        // --- BƯỚC 1: Xử lý Khiên chắn (Shield Resolution) ---
        for (const unit of allAlive) {
            const act = unit.queue ? unit.queue[stepIndex] : null;
            if (act && act.type === 'SHIELD') {
                unit.shieldDir = act.dir;
                this.createShieldSpark(unit.x, unit.y, unit.color);
                this.addFloatingText(this.lang === 'en' ? 'SHIELD!' : 'KHIÊN!', unit.x, unit.y, unit.team === 'BLUE' ? '#38bdf8' : '#f43f5e');
                if (unit.isPlayer && window.soundCtrl) window.soundCtrl.playShield();
            }
        }

        await this.delay(180);

        // --- BƯỚC 2: Xử lý Nhảy Đột Kích & Bật Nhảy Miễn Nhiễm (Leap Resolution) ---
        for (const unit of allAlive) {
            if (unit.hp <= 0) continue;
            const act = unit.queue ? unit.queue[stepIndex] : null;
            if (act && act.type === 'BOOM_LEAP') {
                unit.isImmune = true;
                const uD = DIRECTIONS[act.dir];
                const startX = unit.x;
                const startY = unit.y;
                const leapDist = act.range || 2;
                let destX = Math.max(0, Math.min(GRID_COLS - 1, startX + uD.dx * leapDist));
                let destY = Math.max(0, Math.min(GRID_ROWS - 1, startY + uD.dy * leapDist));

                if (window.soundCtrl && (unit.isPlayer || allAlive.length <= 4)) window.soundCtrl.playBoomLeap();
                this.createLeapArc(startX, startY, destX, destY, '#f59e0b');
                unit.x = destX;
                unit.y = destY;
                this.checkFireZones(unit);
                this.checkTeleporters(unit);
                this.addFloatingText(this.lang === 'en' ? '🛡️ LEAP (IMMUNE)!' : '🛡️ BẬT NHẢY (MIỄN NHIỄM)!', destX, destY, '#eab308');
                this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${unit.name} [${this.getActionName(act)}] leaped 2 tiles to (${destX}, ${destY}) with complete damage immunity!` : `Nhịp #${stepIndex + 1}: ${unit.name} [${act.name}] bật nhảy 2 ô tới (${destX}, ${destY}) và miễn nhiễm mọi sát thương!`, 'buff');
            } else if (act && act.type === 'LEAP') {
                const uD = DIRECTIONS[act.dir];
                const startX = unit.x;
                const startY = unit.y;
                let destX = Math.max(0, Math.min(GRID_COLS - 1, startX + uD.dx * (act.range || 3)));
                let destY = Math.max(0, Math.min(GRID_ROWS - 1, startY + uD.dy * (act.range || 3)));

                const hasObstacle = allAlive.some(o => o !== unit && o.hp > 0 && o.x === destX && o.y === destY) ||
                                    this.groundHazards.some(h => h.x === destX && h.y === destY);
                let extraJump = false;
                if (hasObstacle) {
                    extraJump = true;
                    destX = Math.max(0, Math.min(GRID_COLS - 1, destX + uD.dx * (act.leapExtra || 2)));
                    destY = Math.max(0, Math.min(GRID_ROWS - 1, destY + uD.dy * (act.leapExtra || 2)));
                }

                if (window.soundCtrl && (unit.isPlayer || allAlive.length <= 4)) window.soundCtrl.playLeap();
                this.createLeapArc(startX, startY, destX, destY, unit.charThemeColor || unit.color);
                unit.x = destX;
                unit.y = destY;
                this.checkFireZones(unit);
                this.checkTeleporters(unit);

                if (extraJump) {
                    this.addFloatingText(this.lang === 'en' ? '🦘 OBSTACLE! EXTRA 2 STEPS!' : '🦘 ĐÍCH CÓ VẬT THỂ/ĐỊCH! NHẢY THÊM 2 BƯỚC!', destX, destY, '#06b6d4');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${unit.name} [${this.getActionName(act)}] detected obstacle/enemy, leaped 2 extra steps to (${destX}, ${destY})!` : `Nhịp #${stepIndex + 1}: ${unit.name} [${act.name}] phát hiện vật thể/địch, nhảy tiếp 2 bước tới (${destX}, ${destY})!`, 'buff');
                } else {
                    this.addFloatingText(this.lang === 'en' ? '🦘 LEAP 3 TILES!' : '🦘 NHẢY 3 Ô!', destX, destY, '#06b6d4');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${unit.name} [${this.getActionName(act)}] traversed terrain to (${destX}, ${destY})!` : `Nhịp #${stepIndex + 1}: ${unit.name} [${act.name}] vượt địa hình tới (${destX}, ${destY})!`, 'system');
                }
            }
        }

        // --- BƯỚC 3: Di chuyển Vi mô Đồng thời (Sub-tick Simultaneous Movement: PATH_MOVE & DASH) ---
        const movers = [];
        for (const unit of allAlive) {
            if (unit.hp <= 0) continue;
            const act = unit.queue ? unit.queue[stepIndex] : null;
            if (!act) continue;

            let subSteps = [];
            if (act.type === 'PATH_MOVE' && act.path) {
                subSteps = act.path;
            } else if (act.type === 'DASH') {
                const d = DIRECTIONS[act.dir];
                subSteps = [{ x: unit.x + d.dx * 2, y: unit.y + d.dy * 2, dir: act.dir }];
            }

            if (subSteps.length > 0) {
                movers.push({ unit, subSteps, act });
            }
        }

        const maxSubSteps = movers.reduce((max, m) => Math.max(max, m.subSteps.length), 0);

        for (let sub = 0; sub < maxSubSteps; sub++) {
            const nextPositions = new Map();
            for (const m of movers) {
                if (m.unit.hp <= 0) continue;
                if (sub < m.subSteps.length) {
                    const step = m.subSteps[sub];
                    const nx = Math.max(0, Math.min(GRID_COLS - 1, step.x));
                    const ny = Math.max(0, Math.min(GRID_ROWS - 1, step.y));
                    nextPositions.set(m.unit, { nx, ny, dir: step.dir || m.unit.dir, moving: true });
                } else {
                    nextPositions.set(m.unit, { nx: m.unit.x, ny: m.unit.y, dir: m.unit.dir, moving: false });
                }
            }

            // Kiểm tra va chạm đối đầu trực diện (Head-on collision: đổi chỗ cho nhau)
            for (let i = 0; i < movers.length; i++) {
                for (let j = i + 1; j < movers.length; j++) {
                    const uA = movers[i].unit;
                    const uB = movers[j].unit;
                    if (uA.team === uB.team) continue;
                    const pA = nextPositions.get(uA);
                    const pB = nextPositions.get(uB);
                    if (pA && pB && pA.moving && pB.moving && pA.nx === uB.x && pA.ny === uB.y && pB.nx === uA.x && pB.ny === uA.y) {
                        if (window.soundCtrl) window.soundCtrl.playClash();
                        const midX = (uA.x + uB.x) / 2;
                        const midY = (uA.y + uB.y) / 2;
                        this.createClashBurst(midX, midY);
                        this.addFloatingText(this.lang === 'en' ? 'HEAD-ON CLASH!' : 'ĐÂM NHAU!', midX, midY, '#fbbf24');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${uA.name} and ${uB.name} collided head-on! Bounced back and lost 5 HP!` : `Nhịp #${stepIndex + 1}: ${uA.name} và ${uB.name} đâm trực diện! Dội lùi và mất 5 HP!`, 'clash');
                        this.applyDamage(uA, 5, uB);
                        this.applyDamage(uB, 5, uA);
                        pA.nx = uA.x; pA.ny = uA.y; pA.moving = false;
                        pB.nx = uB.x; pB.ny = uB.y; pB.moving = false;
                    }
                }
            }

            // Kiểm tra tranh chấp ô (Tile Contention: nhiều đơn vị cùng bước vào 1 ô)
            const tileClaims = new Map();
            for (const [unit, pos] of nextPositions.entries()) {
                if (!pos.moving) continue;
                const key = `${pos.nx},${pos.ny}`;
                if (!tileClaims.has(key)) tileClaims.set(key, []);
                tileClaims.get(key).push(unit);
            }

            for (const [key, claimants] of tileClaims.entries()) {
                if (claimants.length > 1) {
                    const [cx, cy] = key.split(',').map(Number);
                    if (window.soundCtrl) window.soundCtrl.playClash();
                    this.createClashBurst(cx, cy);
                    this.addFloatingText(this.lang === 'en' ? 'CLASH!' : 'VA CHẠM!', cx, cy, '#fbbf24');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: Multiple units rushed into tile (${cx}, ${cy}) -> BOUNCED BACK!` : `Nhịp #${stepIndex + 1}: Nhiều đơn vị cùng lao vào ô (${cx}, ${cy}) -> DỘI LÙI!`, 'clash');
                    for (const u of claimants) {
                        this.applyDamage(u, 5);
                        const pos = nextPositions.get(u);
                        pos.nx = u.x; pos.ny = u.y; pos.moving = false;
                    }
                }
            }

            // Áp dụng di chuyển thực tế
            for (const [unit, pos] of nextPositions.entries()) {
                if (!pos.moving) continue;
                const isBlockedByStationary = allAlive.some(other => {
                    if (other === unit || other.hp <= 0) return false;
                    const otherPos = nextPositions.get(other);
                    const destX = otherPos ? otherPos.nx : other.x;
                    const destY = otherPos ? otherPos.ny : other.y;
                    return destX === pos.nx && destY === pos.ny && otherPos && !otherPos.moving;
                });

                if (isBlockedByStationary) {
                    this.addFloatingText(this.lang === 'en' ? 'BLOCKED!' : 'BỊ CHẶN!', unit.x, unit.y, '#cbd5e1');
                } else {
                    unit.x = pos.nx;
                    unit.y = pos.ny;
                    unit.dir = pos.dir;
                    this.checkFireZones(unit);
                    this.checkTeleporters(unit);
                    if (unit.isPlayer && window.soundCtrl) window.soundCtrl.playMove();
                }
            }

            await this.delay(200);
        }

        for (const unit of allAlive) {
            unit.lastMoveDx = unit.x - unit.stepStartX;
            unit.lastMoveDy = unit.y - unit.stepStartY;
        }

        await this.delay(120);

        // --- BƯỚC 4: Thực thi Tấn công & Kỹ năng (Attacks & Abilities) ---
        for (const actor of allAlive) {
            if (actor.hp <= 0) continue;
            const act = actor.queue ? actor.queue[stepIndex] : null;
            if (!act || act.type === 'SHIELD' || act.type === 'PATH_MOVE' || act.type === 'DASH' || act.type === 'LEAP' || act.type === 'BOOM_LEAP') continue;

            await this.resolveUnitAttack(actor, act, stepIndex);
        }

        // --- BƯỚC 4.5: Sentry Tự Động Quét & Khai Hỏa (11x11, 10 DMG) ---
        await this.resolveSentryAttacks(stepIndex);

        // --- BƯỚC 4.6: Thây Ma CPU Tự Động Quét & Tấn Công (3x3, 35 DMG vào 1 kẻ địch ngẫu nhiên) ---
        await this.resolveZombieAttacks(stepIndex);
        if (this.zombies) this.zombies = this.zombies.filter(z => z.hp > 0);

        this.updateHUD();

        if (this.gameMode === 'DUEL') {
            const blueAliveCount = this.blueTeam.filter(u => u.hp > 0).length;
            const redAliveCount = this.redTeam.filter(u => u.hp > 0).length;

            if (blueAliveCount === 0 || redAliveCount === 0) {
                this.handleGameOver();
                return;
            }
        }

        for (const u of allAlive) {
            u.isImmune = false;
        }

        await this.delay(450);
        this.executeResolutionStep(stepIndex + 1);
    }

    async resolveUnitAttack(actor, act, stepIndex) {
        const opposingTeam = (actor.team === 'BLUE') ? this.redTeam : this.blueTeam;
        const livingOpponents = opposingTeam.filter(u => u.hp > 0);
        const allLivingUnits = [...this.blueTeam, ...this.redTeam].filter(u => u.hp > 0);

        // Tính Buff sát thương của actor
        const hasAdrenaline = (actor.buffs && actor.buffs.adrenaline && actor.buffs.adrenaline.turnsLeft > 0);
        const hasCigarette = (actor.buffs && actor.buffs.cigarette && actor.buffs.cigarette.turnsLeft > 0);
        let dmgMult = 1.0;
        let buffTag = '';
        if (hasAdrenaline) {
            dmgMult *= 1.2;
            buffTag += ' (+20% Adrenaline)';
        }
        if (hasCigarette) {
            dmgMult *= 1.3;
            buffTag += (this.lang === 'en' ? ' (+30% Cigarette)' : ' (+30% Thuốc Lá)');
        }
        const hasBuffDmg = hasAdrenaline || hasCigarette;

        if (act.type === 'ATTACK') {
            const uD = DIRECTIONS[act.dir];
            const attackRange = act.range || 1;
            const targetX = actor.x + uD.dx * attackRange;
            const targetY = actor.y + uD.dy * attackRange;
            this.createSlashEffect(targetX, targetY, actor.charThemeColor || actor.color);

            const target = livingOpponents.find(u => u.x === targetX && u.y === targetY);
            if (target) {
                if (target.shieldDir) {
                    if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playShield();
                    this.addFloatingText(this.lang === 'en' ? 'BLOCKED!' : 'CHẶN ĐƯỢC!', target.x, target.y, '#60a5fa');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name}'s slash against ${target.name} was BLOCKED by Shield! (0 DMG)` : `Nhịp #${stepIndex + 1}: ${actor.name} chém ${target.name} bị Khiên chặn đứng! (0 DMG)`, 'block');
                } else {
                    if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHit();
                    let dmg = act.power || 25;
                    if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                    const targetAct = target.queue ? target.queue[stepIndex] : null;
                    if (targetAct && targetAct.type === 'LEAP') dmg = Math.round(dmg * 0.75);

                    this.applyDamage(target, dmg, actor);
                    this.createHitSparks(target.x, target.y, target.color);
                    this.addFloatingText(`-${dmg} HP!`, target.x, target.y, '#f87171');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: [${this.getActionName(act)}] ${actor.name} HIT ${target.name}! (-${dmg} HP${buffTag})` : `Nhịp #${stepIndex + 1}: [${act.name}] ${actor.name} ĐÁNH TRÚNG ${target.name}! (-${dmg} HP${buffTag})`, 'hit');

                    if (target.charId === 'hookman') {
                        target.revealedTurns = 2;
                        if (target.isPlayer) this.playerRevealedTurns = 2;
                        this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', target.x, target.y, '#f43f5e');
                    }
                }
            } else {
                const enemyDep = this.getEnemyDeployableAt(targetX, targetY, actor.team);
                if (enemyDep) {
                    if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playHit();
                    let dmg = act.power || 25;
                    if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                    this.damageDeployable(enemyDep, dmg, actor);
                } else {
                    if (window.soundCtrl && actor.isPlayer) window.soundCtrl.playAttack();
                    this.addFloatingText(this.lang === 'en' ? 'MISS!' : 'HỤT!', targetX, targetY, '#94a3b8');
                }
            }
        }
        else if (act.type === 'RANGED_LINE' || act.type === 'RANGED_VARIABLE' || act.type === 'REVOLVER' || act.type === 'MACHINE_PISTOL') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 5) + thermalBonus;
            if (act.type === 'REVOLVER' || act.skillId === 'SAVIOR_REVOLVER') {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playRevolver();
            } else if (act.type === 'MACHINE_PISTOL' || act.skillId === 'MEDIC_MACHINE_PISTOL') {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playMachinePistol();
            } else if (act.skillId === 'ENGIE_NAILGUN') {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playNailgun();
            } else if (act.skillId === 'RAZOR_PULSE_RIFLE') {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playPulseRifle();
            } else if (act.type === 'RANGED_VARIABLE') {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playSilencedPistol();
            } else {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playRifleShot();
            }

            let hit = false;
            let endX = actor.x + uD.dx * maxRange;
            let endY = actor.y + uD.dy * maxRange;

            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                endX = cx;
                endY = cy;

                const target = livingOpponents.find(u => u.x === cx && u.y === cy);
                if (target) {
                    hit = true;
                    if (target.shieldDir) {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playShield();
                        this.addFloatingText(this.lang === 'en' ? 'BLOCKED BULLET!' : 'CHẶN ĐƯỢC ĐẠN!', target.x, target.y, '#60a5fa');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${target.name} raised Shield, blocking ${this.getActionName(act)} burst from ${actor.name}!` : `Nhịp #${stepIndex + 1}: ${target.name} giương Khiên chặn loạt đạn ${act.name} từ ${actor.name}!`, 'block');
                    } else {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHit();
                        let dmg = (act.type === 'RANGED_VARIABLE') 
                            ? Math.floor(Math.random() * ((act.maxPower || 20) - (act.minPower || 15) + 1)) + (act.minPower || 15)
                            : (act.power || 20);
                        if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                        const targetAct = target.queue ? target.queue[stepIndex] : null;
                        if (targetAct && targetAct.type === 'LEAP') dmg = Math.round(dmg * 0.75);

                        this.applyDamage(target, dmg, actor);
                        if (act.skillId === 'FIREMAN_GATTLING_FIRE') {
                            this.applyBurn(target, act.burnTurns || 3, act.burnDmg || 5, actor);
                            this.createHitSparks(target.x, target.y, '#ea580c');
                            this.addFloatingText(this.lang === 'en' ? `-${dmg} HP + 🔥 BURN!` : `-${dmg} HP + 🔥 CHÁY!`, target.x, target.y, '#ea580c');
                            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: [${this.getActionName(act)}] ${actor.name} HIT ${target.name}! Dealt ${dmg} DMG and ignited Burn (-5 HP/turn for 3 turns)!` : `Nhịp #${stepIndex + 1}: [${act.name}] ${actor.name} BẮN TRÚNG ${target.name}! Gây ${dmg} sát thương và thiêu đốt (-5 HP/lượt trong 3 lượt)!`, 'hit');
                        } else {
                            this.createHitSparks(target.x, target.y, target.color);
                            this.addFloatingText(`-${dmg} HP!`, target.x, target.y, '#f87171');
                            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: [${this.getActionName(act)}] ${actor.name} HIT ${target.name}! Dealt ${dmg} damage${buffTag}!` : `Nhịp #${stepIndex + 1}: [${act.name}] ${actor.name} BẮN TRÚNG ${target.name}! Gây ${dmg} sát thương${buffTag}!`, 'hit');
                        }

                        if (target.charId === 'hookman') {
                            target.revealedTurns = 2;
                            if (target.isPlayer) this.playerRevealedTurns = 2;
                            this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', target.x, target.y, '#f43f5e');
                        }
                    }
                    break;
                }

                const enemyDep = this.getEnemyDeployableAt(cx, cy, actor.team);
                if (enemyDep) {
                    hit = true;
                    if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playHit();
                    let dmg = (act.type === 'RANGED_VARIABLE') 
                        ? Math.floor(Math.random() * ((act.maxPower || 20) - (act.minPower || 15) + 1)) + (act.minPower || 15)
                        : (act.power || 20);
                    if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                    this.damageDeployable(enemyDep, dmg, actor);
                    break;
                }
            }

            let tracerColor = '#34d399';
            if (act.type === 'REVOLVER' || act.skillId === 'SAVIOR_REVOLVER') tracerColor = '#c084fc';
            else if (act.type === 'MACHINE_PISTOL' || act.skillId === 'MEDIC_MACHINE_PISTOL') tracerColor = '#10b981';
            else if (act.skillId === 'ENGIE_NAILGUN') tracerColor = '#fbbf24';
            else if (act.skillId === 'FIREMAN_GATTLING_FIRE') tracerColor = '#ea580c';
            else if (act.skillId === 'SMOKE_RIFLE') tracerColor = '#fb923c';
            else if (act.skillId === 'RAZOR_PULSE_RIFLE') tracerColor = '#06b6d4';
            else if (act.type === 'RANGED_VARIABLE') tracerColor = '#a78bfa';
            this.createBulletTracer(actor.x, actor.y, endX, endY, tracerColor);

            if (!hit) {
                this.addFloatingText(this.lang === 'en' ? 'MISS!' : 'ĐẠN TRƯỢT!', endX, endY, '#94a3b8');
            }
        }
        else if (act.type === 'BUFF_HEAL') {
            if (window.soundCtrl && actor.isPlayer) window.soundCtrl.playAdrenaline();
            if (!actor.buffs) actor.buffs = {};
            if (!actor.buffs.adrenaline) actor.buffs.adrenaline = { turnsLeft: 0, healPerTurn: 5, dmgBonusPercent: 20 };
            actor.buffs.adrenaline.turnsLeft = act.duration || 3;
            if (actor.isPlayer && this.playerBuffs) this.playerBuffs.adrenaline.turnsLeft = act.duration || 3;

            this.createBuffSparks(actor.x, actor.y, '#10b981');
            this.addFloatingText(this.lang === 'en' ? '💉 ADRENALINE! (+20% DMG)' : '💉 TIÊM ADRENALINE! (+20% DMG)', actor.x, actor.y, '#10b981');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} injected [Adrenaline]! +20% DMG and regenerates 5 HP/turn!` : `Nhịp #${stepIndex + 1}: ${actor.name} tiêm [Adrenaline]! Tăng +20% Sát thương và hồi 5 HP/lượt!`, 'hit');
            actor.cooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'BUFF_SMOKE') {
            if (window.soundCtrl && actor.isPlayer) window.soundCtrl.playCigarette();
            if (!actor.buffs) actor.buffs = {};
            if (!actor.buffs.cigarette) actor.buffs.cigarette = { turnsLeft: 0, dmgBonusPercent: 30, moveBonus: 1 };
            actor.buffs.cigarette.turnsLeft = act.duration || 2;
            if (actor.isPlayer && this.playerBuffs) this.playerBuffs.cigarette.turnsLeft = act.duration || 2;

            this.createBuffSparks(actor.x, actor.y, '#f97316');
            this.addFloatingText(this.lang === 'en' ? '🚬 SMOKING! (+30% DMG & +1 SPEED)' : '🚬 HÚT THUỐC! (+30% DMG & +1 BƯỚC)', actor.x, actor.y, '#f97316');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} lit a [Cigarette]! +30% DMG and +1 Movement Speed!` : `Nhịp #${stepIndex + 1}: ${actor.name} châm [Thuốc Lá]! Tăng +30% Sát thương và +1 Tốc độ di chuyển!`, 'hit');
        }
        else if (act.type === 'BUFF_DESTRUCTIVE') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playDestructiveShot();
            if (!actor.buffs) actor.buffs = {};
            actor.buffs.destructiveShot = true;
            this.createBuffSparks(actor.x, actor.y, '#ec4899');
            this.addFloatingText(this.lang === 'en' ? '⚡ DESTRUCTIVE (+30% & PIERCE)!' : '⚡ PHÁT BẮN HỦY DIỆT (+30% & XUYÊN)!', actor.x, actor.y, '#ec4899');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} activated [Destructive Shot]! Next sniper shot gets +30% DMG and pierces all enemies!` : `Nhịp #${stepIndex + 1}: ${actor.name} kích hoạt [Phát Bắn Hủy Diệt]! Phát súng tỉa tiếp theo +30% sát thương và xuyên thấu mọi kẻ địch!`, 'buff');
            actor.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'BUFF_THERMAL') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playThermalVision();
            const allies = (actor.team === 'BLUE' ? this.blueTeam : this.redTeam).filter(u => u.hp > 0);
            for (const ally of allies) {
                if (!ally.buffs) ally.buffs = {};
                ally.buffs.thermalVision = { active: true, rangeBonus: act.rangeBonus || 1 };
                this.createBuffSparks(ally.x, ally.y, '#06b6d4');
                this.addFloatingText(this.lang === 'en' ? '🔭 THERMAL (+1 RANGE)!' : '🔭 TẦM NHIỆT (+1 TẦM)!', ally.x, ally.y, '#06b6d4');
            }
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} activated [Thermal Vision]! All teammates gain +1 range on their next ability!` : `Nhịp #${stepIndex + 1}: ${actor.name} kích hoạt [Tầm Nhìn Dò Nhiệt]! Toàn bộ đồng đội nhận +1 phạm vi cho lần dùng kế tiếp!`, 'buff');
            actor.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 4;
        }
        else if (act.type === 'SNIPER_SCOPE') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playSniperScope();
            actor.isScoped = true;
            this.createBuffSparks(actor.x, actor.y, '#818cf8');
            this.addFloatingText(this.lang === 'en' ? '🎯 SCOPE ON!' : '🎯 CHẾ ĐỘ NGẮM BẮN!', actor.x, actor.y, '#818cf8');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} entered [Scope In Mode]! Ready for long-range precision shot.` : `Nhịp #${stepIndex + 1}: ${actor.name} vào [Chế độ Ngắm Bắn]! Sẵn sàng tung đòn bắn tỉa tầm xa.`, 'system');
        }
        else if (act.type === 'SNIPER_SHOT') {
            const isDestructive = Boolean(actor.buffs && actor.buffs.destructiveShot);
            if (isDestructive) {
                actor.buffs.destructiveShot = false;
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playDestructiveShot();
            } else {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playSniperShot();
            }
            actor.isScoped = false;

            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }

            const maxRange = (act.range || 6) + thermalBonus;
            const uD = DIRECTIONS[act.dir];
            let hitAny = false;
            let endX = actor.x + uD.dx * maxRange;
            let endY = actor.y + uD.dy * maxRange;

            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                endX = cx;
                endY = cy;

                const target = livingOpponents.find(u => u.x === cx && u.y === cy);
                if (target) {
                    hitAny = true;
                    if (target.shieldDir) {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playShield();
                        this.addFloatingText(this.lang === 'en' ? 'BLOCKED SNIPER!' : 'CHẶN ĐƯỢC BẮN TỈA!', target.x, target.y, '#60a5fa');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${target.name} raised Shield, blocking sniper shot from ${actor.name}!` : `Nhịp #${stepIndex + 1}: ${target.name} giương Khiên chặn phát súng tỉa từ ${actor.name}!`, 'block');
                    } else {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHit();
                        // Công thức sát thương theo cự ly: 20 + 5 * d (25, 30, 35, 40, 45, 50, 55)
                        let dmg = 20 + 5 * r;
                        if (isDestructive) dmg = Math.round(dmg * 1.3);
                        if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                        const targetAct = target.queue ? target.queue[stepIndex] : null;
                        if (targetAct && targetAct.type === 'LEAP') dmg = Math.round(dmg * 0.75);

                        this.applyDamage(target, dmg, actor);
                        this.createHitSparks(target.x, target.y, isDestructive ? '#ec4899' : '#818cf8');
                        this.addFloatingText(`-${dmg} HP!`, target.x, target.y, isDestructive ? '#ec4899' : '#f87171');

                        const destructiveTag = isDestructive ? (this.lang === 'en' ? ' [⚡DESTRUCTIVE +30%]' : ' [⚡HỦY DIỆT +30%]') : '';
                        const distTag = this.lang === 'en' ? ` (Dist: ${r} tiles)` : ` (Cự ly: ${r} ô)`;
                        this.addCombatLog(
                            this.lang === 'en'
                                ? `Beat #${stepIndex + 1}: 🎯 [Sniper Shot] ${actor.name} HIT ${target.name}! (-${dmg} HP${destructiveTag}${distTag}${buffTag})!`
                                : `Nhịp #${stepIndex + 1}: 🎯 [Súng Tỉa] ${actor.name} BẮN TRÚNG ${target.name}! (-${dmg} HP${destructiveTag}${distTag}${buffTag})!`,
                            'hit'
                        );

                        if (target.charId === 'hookman') {
                            target.revealedTurns = 2;
                            if (target.isPlayer) this.playerRevealedTurns = 2;
                            this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', target.x, target.y, '#f43f5e');
                        }
                    }

                    if (!isDestructive) {
                        break;
                    }
                }

                const enemyDep = this.getEnemyDeployableAt(cx, cy, actor.team);
                if (enemyDep) {
                    hitAny = true;
                    if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playHit();
                    let dmg = 20 + 5 * r;
                    if (isDestructive) dmg = Math.round(dmg * 1.3);
                    if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                    this.damageDeployable(enemyDep, dmg, actor);
                    if (!isDestructive) {
                        break;
                    }
                }
            }

            const tracerColor = isDestructive ? '#ec4899' : '#818cf8';
            this.createBulletTracer(actor.x, actor.y, endX, endY, tracerColor);

            if (!hitAny) {
                this.addFloatingText(this.lang === 'en' ? 'SNIPER MISS!' : 'BẮN TỈA TRƯỢT!', endX, endY, '#94a3b8');
            }
        }
        else if (act.type === 'BUFF_CHAOS_SHOT') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playChaosCharge();
            if (!actor.buffs) actor.buffs = {};
            actor.buffs.chaosShot = true;
            this.createBuffSparks(actor.x, actor.y, '#a855f7');
            this.addFloatingText(this.lang === 'en' ? '🌀 CHAOS SHOT (+30% & 5x5)!' : '🌀 PHÁT BẮN RỐI LOẠN (+30% & 5x5)!', actor.x, actor.y, '#a855f7');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} activated [Chaos Shot]! Next tank cannon shot gains +30% direct DMG and 5x5 explosion!` : `Nhịp #${stepIndex + 1}: ${actor.name} kích hoạt [Phát Bắn Rối Loạn]! Phát bắn Nòng Xe Tăng tiếp theo tăng +30% sát thương trực diện và nổ 5x5!`, 'buff');
            actor.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'TANK_SCOPE') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playTankScope();
            actor.isScoped = true;
            this.createBuffSparks(actor.x, actor.y, '#e11d48');
            this.addFloatingText(this.lang === 'en' ? '🎯 TANK SCOPE ON!' : '🎯 NGẮM NÒNG PHÁO!', actor.x, actor.y, '#e11d48');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} entered [Tank Cannon Scope In Mode]! Preparing long-range artillery shot.` : `Nhịp #${stepIndex + 1}: ${actor.name} vào [Chế độ Ngắm Nòng Pháo]! Chuẩn bị khai hỏa đại bác tầm xa.`, 'system');
        }
        else if (act.type === 'TANK_SHOT') {
            const hasChaos = Boolean(actor.buffs && actor.buffs.chaosShot);
            if (hasChaos) {
                actor.buffs.chaosShot = false;
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playChaosCharge();
            }
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playTankShot();

            actor.isScoped = false;

            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }

            const maxRange = (act.range || 6) + thermalBonus;
            const uD = DIRECTIONS[act.dir];
            let detX = actor.x + uD.dx * maxRange;
            let detY = actor.y + uD.dy * maxRange;
            let directTarget = null;
            let hitDep = null;
            let hitDist = maxRange;

            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                detX = cx;
                detY = cy;
                hitDist = r;

                const enemy = livingOpponents.find(u => u.x === cx && u.y === cy);
                const dep = this.getEnemyDeployableAt(cx, cy, actor.team);
                const haz = this.groundHazards && this.groundHazards.some(h => h.x === cx && h.y === cy);

                if (enemy) {
                    directTarget = enemy;
                    break;
                }
                if (dep) {
                    hitDep = dep;
                    break;
                }
                if (haz) {
                    break;
                }
            }

            detX = Math.max(0, Math.min(GRID_COLS - 1, detX));
            detY = Math.max(0, Math.min(GRID_ROWS - 1, detY));

            const tracerColor = hasChaos ? '#a855f7' : '#e11d48';
            this.createRocketTrail(actor.x, actor.y, detX, detY, tracerColor);
            await this.delay(180);

            const aoeRadius = hasChaos ? 2 : 1;
            const blastSizeStr = hasChaos ? '5x5' : '3x3';
            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.createExplosionBurst(detX, detY, hasChaos ? 60 : 35);

            // Bảng sát thương trực tiếp: 15-20-30-35-40-45
            const TANK_CANNON_DMG = [0, 15, 20, 30, 35, 40, 45];
            let directDmg = hitDist <= 6 ? TANK_CANNON_DMG[hitDist] : (45 + (hitDist - 6) * 5);
            if (hasChaos) directDmg = Math.round(directDmg * 1.3);
            if (hasBuffDmg) directDmg = Math.round(directDmg * dmgMult);

            const chaosTag = hasChaos ? (this.lang === 'en' ? ' [🌀CHAOS +30% & 5x5]' : ' [🌀RỐI LOẠN +30% & 5x5]') : '';
            this.addFloatingText(this.lang === 'en' ? `💥 BLAST ${blastSizeStr}!` : `💥 NỔ ${blastSizeStr}!`, detX, detY, tracerColor);
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} fired [Tank Cannon] exploding ${blastSizeStr} at (${detX}, ${detY})!${chaosTag}` : `Nhịp #${stepIndex + 1}: ${actor.name} bắn [Nòng Xe Tăng] nổ ${blastSizeStr} tại (${detX}, ${detY})!${chaosTag}`, 'clash');

            // 1. Sát thương chính tại tâm
            if (directTarget) {
                const targetAct = directTarget.queue ? directTarget.queue[stepIndex] : null;
                if (directTarget.isImmune || (targetAct && targetAct.type === 'BOOM_LEAP')) {
                    this.addFloatingText(this.lang === 'en' ? 'IMMUNE!' : 'MIỄN NHIỄM!', directTarget.x, directTarget.y, '#eab308');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${directTarget.name} leaped with full immunity against Tank Cannon!` : `Nhịp #${stepIndex + 1}: ${directTarget.name} bật nhảy miễn nhiễm hoàn toàn phát bắn Nòng Xe Tăng!`, 'block');
                } else if (directTarget.shieldDir) {
                    if (window.soundCtrl && (actor.isPlayer || directTarget.isPlayer)) window.soundCtrl.playShield();
                    this.addFloatingText(this.lang === 'en' ? 'BLOCKED SHELL!' : 'CHẶN ĐƯỢC ĐẠN PHÁO!', directTarget.x, directTarget.y, '#60a5fa');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${directTarget.name} raised Shield, blocking cannon shell from ${actor.name}!` : `Nhịp #${stepIndex + 1}: ${directTarget.name} giương Khiên chặn trực tiếp đạn pháo từ ${actor.name}!`, 'block');
                } else {
                    let dDmg = directDmg;
                    if (targetAct && targetAct.type === 'LEAP') dDmg = Math.round(dDmg * 0.75);

                    this.applyDamage(directTarget, dDmg, actor);
                    this.createHitSparks(directTarget.x, directTarget.y, tracerColor);
                    this.addFloatingText(`-${dDmg} HP!`, directTarget.x, directTarget.y, '#f87171');
                    this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: 🎯 [Tank Cannon] ${actor.name} DIRECT HIT ${directTarget.name}! (-${dDmg} HP${chaosTag}, distance: ${hitDist} tiles)!` : `Nhịp #${stepIndex + 1}: 🎯 [Nòng Xe Tăng] ${actor.name} BẮN TRÚNG TRỰC DIỆN ${directTarget.name}! (-${dDmg} HP${chaosTag}, cự ly: ${hitDist} ô)!`, 'hit');

                    if (directTarget.charId === 'hookman') {
                        directTarget.revealedTurns = 2;
                        if (directTarget.isPlayer) this.playerRevealedTurns = 2;
                        this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', directTarget.x, directTarget.y, '#f43f5e');
                    }
                }
            } else if (hitDep) {
                this.damageDeployable(hitDep, directDmg, actor);
            }

            // 2. Sát thương nổ lan 10 DMG ở mọi chỗ trừ chính giữa
            for (const u of allLivingUnits) {
                if (Math.abs(u.x - detX) <= aoeRadius && Math.abs(u.y - detY) <= aoeRadius) {
                    if (u.x === detX && u.y === detY) continue;

                    const uAct = u.queue ? u.queue[stepIndex] : null;
                    if (u.isImmune || (uAct && uAct.type === 'BOOM_LEAP')) {
                        this.addFloatingText(this.lang === 'en' ? 'IMMUNE!' : 'MIỄN NHIỄM!', u.x, u.y, '#eab308');
                        continue;
                    }

                    let splashDmg = 10;
                    if (uAct && uAct.type === 'LEAP') splashDmg = Math.round(splashDmg * 0.75);

                    this.applyDamage(u, splashDmg, actor);
                    this.createHitSparks(u.x, u.y, u.color);
                    this.addFloatingText(`-${splashDmg} HP!`, u.x, u.y, '#f87171');
                    this.addCombatLog(this.lang === 'en' ? `💥 Tank Cannon ${blastSizeStr} blast dealt -${splashDmg} HP splash damage to ${u.name}!` : `💥 Vụ nổ ${blastSizeStr} Nòng Xe Tăng gây -${splashDmg} HP nổ lan lên ${u.name}!`, 'hit');

                    if (u.charId === 'hookman') {
                        u.revealedTurns = 2;
                        if (u.isPlayer) this.playerRevealedTurns = 2;
                    }
                }
            }

            // Sát thương nổ lan lên Deployables trong vùng nổ trừ tâm
            if (this.sentries) {
                for (const s of this.sentries) {
                    if (Math.abs(s.x - detX) <= aoeRadius && Math.abs(s.y - detY) <= aoeRadius) {
                        if (s.x === detX && s.y === detY) continue;
                        if (s.team !== actor.team) this.damageDeployable({ type: 'SENTRY', obj: s }, 10, actor);
                    }
                }
            }
            if (this.teleporters) {
                for (const t of this.teleporters) {
                    if (t.team !== actor.team) {
                        if (Math.abs(t.inX - detX) <= aoeRadius && Math.abs(t.inY - detY) <= aoeRadius && !(t.inX === detX && t.inY === detY)) {
                            this.damageDeployable({ type: 'TELE_IN', obj: t }, 10, actor);
                        }
                        if (Math.abs(t.outX - detX) <= aoeRadius && Math.abs(t.outY - detY) <= aoeRadius && !(t.outX === detX && t.outY === detY)) {
                            this.damageDeployable({ type: 'TELE_OUT', obj: t }, 10, actor);
                        }
                    }
                }
            }
        }
        else if (act.type === 'HOOK_PULL') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 5) + thermalBonus;
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playHookThrow();

            let hit = false;
            let endX = actor.x + uD.dx * maxRange;
            let endY = actor.y + uD.dy * maxRange;

            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                endX = cx;
                endY = cy;

                const target = livingOpponents.find(u => u.x === cx && u.y === cy);
                if (target) {
                    hit = true;
                    if (target.shieldDir) {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playShield();
                        this.addFloatingText(this.lang === 'en' ? 'BLOCKED HOOK!' : 'KHIÊN CHẶN MÓC!', target.x, target.y, '#60a5fa');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${target.name} raised Shield, blocking Grappling Hook from ${actor.name}!` : `Nhịp #${stepIndex + 1}: ${target.name} giương Khiên chặn đứng Móc Kéo từ ${actor.name}!`, 'block');
                    } else {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHit();
                        let dmg = act.power || 15;
                        if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                        this.applyDamage(target, dmg, actor);
                        this.createHitSparks(target.x, target.y, '#ef4444');

                        const pullX = Math.max(0, Math.min(GRID_COLS - 1, target.x - uD.dx));
                        const pullY = Math.max(0, Math.min(GRID_ROWS - 1, target.y - uD.dy));
                        if (pullX !== actor.x || pullY !== actor.y) {
                            target.x = pullX;
                            target.y = pullY;
                            this.checkFireZones(target);
                            this.checkTeleporters(target);
                            if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHookPull();
                        }

                        this.addFloatingText(this.lang === 'en' ? `-${dmg} HP & PULL 1!` : `-${dmg} HP & KÉO 1 Ô!`, target.x, target.y, '#ef4444');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: [Grappling Hook] ${actor.name} HOOKED ${target.name}! (-${dmg} HP${buffTag}) and pulled 1 tile closer!` : `Nhịp #${stepIndex + 1}: [Móc Kéo] ${actor.name} GĂM TRÚNG ${target.name}! (-${dmg} HP${buffTag}) và kéo lại gần 1 ô!`, 'hit');

                        this.activeHookTethers = this.activeHookTethers.filter(t => t.sourceId !== actor.id);
                        this.activeHookTethers.push({
                            sourceId: actor.id,
                            targetId: target.id,
                            source: actor.isPlayer ? 'PLAYER' : 'CPU',
                            target: target.isPlayer ? 'PLAYER' : 'CPU',
                            sourceUnit: actor,
                            targetUnit: target,
                            turnsUntilPull: 1,
                            pullDist: 2,
                            skillId: act.skillId,
                            cdAfterPull: act.cooldown || 4
                        });
                        this.addCombatLog(this.lang === 'en' ? `🪝 Hook chain is tethered to ${target.name}! Will be jerked 2 tiles closer at the end of next turn!` : `🪝 Dây móc đã găm chặt vào ${target.name}! Hết lượt sau sẽ bị giật kéo thêm 2 ô!`, 'clash');
                    }
                    break;
                }
            }

            this.createHookChainEffect(actor.x, actor.y, endX, endY);
            if (!hit) {
                this.addFloatingText(this.lang === 'en' ? 'HOOK MISSED!' : 'MÓC HỤT!', endX, endY, '#94a3b8');
                actor.cooldowns[act.skillId] = act.cooldown || 4;
            }
        }
        else if (act.type === 'ROCKET' || act.type === 'BOMB_LAUNCHER') {
            const isBombLauncher = (act.type === 'BOMB_LAUNCHER');
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 6) + thermalBonus;

            if (isBombLauncher) {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playBombLauncher();
                const curAmmo = actor.skillAmmo[act.skillId] !== undefined ? actor.skillAmmo[act.skillId] : 2;
                const remAmmo = Math.max(0, curAmmo - 1);
                actor.skillAmmo[act.skillId] = remAmmo;
                if (actor.isPlayer && this.skillAmmo) this.skillAmmo[act.skillId] = remAmmo;
                if (actor === this.cpu && this.cpuSkillAmmo) this.cpuSkillAmmo[act.skillId] = remAmmo;
                if (remAmmo === 0) {
                    actor.cooldowns[act.skillId] = act.cooldown || 4;
                    if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 4;
                    if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 4;
                    this.addCombatLog(this.lang === 'en' ? `⚠️ ${actor.name} [Smoke Bomb Launcher] out of ammo! 4-turn cooldown to reload!` : `⚠️ ${actor.name} [Súng Bắn Bom] hết đạn! Hồi chiêu 4 lượt để nạp đạn!`, 'system');
                }
            } else {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playRocketLaunch();
            }

            let targetX = actor.x + uD.dx * maxRange;
            let targetY = actor.y + uD.dy * maxRange;

            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                targetX = cx;
                targetY = cy;

                const hitUnit = livingOpponents.find(u => u.x === cx && u.y === cy);
                const hitDep = this.getEnemyDeployableAt(cx, cy, actor.team);
                if (hitUnit || hitDep) break;
            }

            targetX = Math.max(0, Math.min(GRID_COLS - 1, targetX));
            targetY = Math.max(0, Math.min(GRID_ROWS - 1, targetY));

            this.createRocketTrail(actor.x, actor.y, targetX, targetY, isBombLauncher ? '#f97316' : '#ef4444');
            await this.delay(180);

            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.createExplosionBurst(targetX, targetY, 40);

            this.addFloatingText(this.lang === 'en' ? '💥 3x3 BLAST!' : '💥 NỔ 3x3!', targetX, targetY, isBombLauncher ? '#f97316' : '#ef4444');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} fired [${this.getActionName(act)}] exploding 3x3 at (${targetX}, ${targetY})!` : `Nhịp #${stepIndex + 1}: ${actor.name} bắn [${act.name}] phát nổ 3x3 tại (${targetX}, ${targetY})!`, 'clash');

            let baseDmg = act.power || 30;
            if (hasBuffDmg) baseDmg = Math.round(baseDmg * dmgMult);

            for (const u of allLivingUnits) {
                if (Math.abs(u.x - targetX) <= 1 && Math.abs(u.y - targetY) <= 1) {
                    const uAct = u.queue ? u.queue[stepIndex] : null;
                    let uDmg = (u === actor) ? (act.power || 30) : baseDmg;
                    if (uAct && uAct.type === 'LEAP') uDmg = Math.round(uDmg * 0.75);

                    this.applyDamage(u, uDmg, actor);
                    this.createHitSparks(u.x, u.y, u.color);
                    this.addFloatingText(`-${uDmg} HP!`, u.x, u.y, '#f87171');
                    this.addCombatLog(this.lang === 'en' ? `💥 [${this.getActionName(act)}] blast hit ${u.name}! (-${uDmg} HP)!` : `💥 Vụ nổ ${act.name} trúng ${u.name}! (-${uDmg} HP)!`, 'hit');

                    if (u.charId === 'hookman') {
                        u.revealedTurns = 2;
                        if (u.isPlayer) this.playerRevealedTurns = 2;
                    }
                }
            }
            this.damageDeployablesInArea(targetX, targetY, 1, baseDmg, actor.team, actor);
        }
        else if (act.type === 'GRENADE') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 5) + thermalBonus;
            let targetX = (act.targetX !== undefined) ? act.targetX : actor.x + uD.dx * maxRange;
            let targetY = (act.targetY !== undefined) ? act.targetY : actor.y + uD.dy * maxRange;

            if (act.targetX === undefined) {
                for (let r = 1; r <= maxRange; r++) {
                    const cx = actor.x + uD.dx * r;
                    const cy = actor.y + uD.dy * r;
                    if (livingOpponents.some(u => u.x === cx && u.y === cy)) {
                        targetX = cx; targetY = cy;
                        break;
                    }
                }
            }

            targetX = Math.max(0, Math.min(GRID_COLS - 1, targetX));
            targetY = Math.max(0, Math.min(GRID_ROWS - 1, targetY));

            this.createGrenadeArc(actor.x, actor.y, targetX, targetY);
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playGrenadeTick();

            this.groundHazards.push({
                id: Date.now() + Math.random(),
                type: 'GRENADE',
                x: targetX,
                y: targetY,
                turnsLeft: 2,
                power: act.power || 50,
                aoeRadius: 1,
                owner: actor.isPlayer ? 'PLAYER' : 'CPU',
                ownerId: actor.id,
                ownerName: actor.name,
                ownerUnit: actor
            });

            this.addFloatingText(this.lang === 'en' ? '💣 GRENADE (2 TURNS)!' : '💣 LỰU ĐẠN (ĐẾM 2 LƯỢT)!', targetX, targetY, '#f59e0b');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} threw a grenade to (${targetX}, ${targetY})! Will detonate 3x3 in 2 turns!` : `Nhịp #${stepIndex + 1}: ${actor.name} ném lựu đạn tới (${targetX}, ${targetY})! Sẽ nổ 3x3 sau 2 lượt!`, 'clash');
        }
        else if (act.type === 'OIL_BARREL') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 6) + thermalBonus;
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playBombLauncher();

            let targetX = actor.x + uD.dx * maxRange;
            let targetY = actor.y + uD.dy * maxRange;

            // Nổ tung sớm nếu có tương tác vật thể ngay trong phạm vi
            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                targetX = cx;
                targetY = cy;

                const hitUnit = livingOpponents.find(u => u.x === cx && u.y === cy);
                const hitHazard = this.groundHazards && this.groundHazards.some(h => h.x === cx && h.y === cy);
                const hitDep = this.getEnemyDeployableAt(cx, cy, actor.team);
                if (hitUnit || hitHazard || hitDep) break;
            }

            targetX = Math.max(0, Math.min(GRID_COLS - 1, targetX));
            targetY = Math.max(0, Math.min(GRID_ROWS - 1, targetY));

            this.createRocketTrail(actor.x, actor.y, targetX, targetY, '#d97706');
            await this.delay(180);

            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.createExplosionBurst(targetX, targetY, 35);

            this.addFloatingText(this.lang === 'en' ? '🛢️ 3x3 OIL SLICK!' : '🛢️ DẦU LOANG 3x3!', targetX, targetY, '#d97706');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} threw [${this.getActionName(act)}] splashing oil 3x3 at (${targetX}, ${targetY})!` : `Nhịp #${stepIndex + 1}: ${actor.name} ném [${act.name}] phát nổ dầu loang 3x3 tại (${targetX}, ${targetY})!`, 'clash');

            // Kẻ thù trúng dầu sẽ dính debuff isOiled, bốc cháy khi nhận sát thương từ mọi nguồn
            for (const u of livingOpponents) {
                if (Math.abs(u.x - targetX) <= 1 && Math.abs(u.y - targetY) <= 1) {
                    u.isOiled = true;
                    this.createBuffSparks(u.x, u.y, '#d97706');
                    this.addFloatingText(this.lang === 'en' ? '🛢️ OILED!' : '🛢️ DÍNH DẦU!', u.x, u.y, '#d97706');
                    this.addCombatLog(this.lang === 'en' ? `🛢️ ${u.name} is coated in Slick Oil! Will ignite (-5 HP/turn for 3 turns) upon taking damage from any source!` : `🛢️ ${u.name} dính Dầu Trơn! Bị bắt lửa cháy (-5 HP/lượt trong 3 lượt) khi nhận sát thương từ bất kỳ nguồn nào!`, 'hit');

                    if (u.charId === 'hookman') {
                        u.revealedTurns = 2;
                        if (u.isPlayer) this.playerRevealedTurns = 2;
                        this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', u.x, u.y, '#f43f5e');
                    }
                }
            }

            actor.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'FIRE_CANNON') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 5) + thermalBonus;
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playRocketLaunch();

            let targetX = actor.x + uD.dx * maxRange;
            let targetY = actor.y + uD.dy * maxRange;

            // Nổ tung sớm nếu có tương tác vật thể ngay trong phạm vi
            for (let r = 1; r <= maxRange; r++) {
                const cx = actor.x + uD.dx * r;
                const cy = actor.y + uD.dy * r;
                if (cx < 0 || cx >= GRID_COLS || cy < 0 || cy >= GRID_ROWS) break;

                targetX = cx;
                targetY = cy;

                const hitUnit = livingOpponents.find(u => u.x === cx && u.y === cy);
                const hitHazard = this.groundHazards && this.groundHazards.some(h => h.x === cx && h.y === cy);
                const hitDep = this.getEnemyDeployableAt(cx, cy, actor.team);
                if (hitUnit || hitHazard || hitDep) break;
            }

            targetX = Math.max(0, Math.min(GRID_COLS - 1, targetX));
            targetY = Math.max(0, Math.min(GRID_ROWS - 1, targetY));

            this.createRocketTrail(actor.x, actor.y, targetX, targetY, '#dc2626');
            await this.delay(180);

            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.createExplosionBurst(targetX, targetY, 45);

            this.addFloatingText(this.lang === 'en' ? '💥 3x3 FIRE CANNON!' : '💥 ĐẠI BÁC LỬA 3x3!', targetX, targetY, '#dc2626');
            this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${actor.name} fired [${this.getActionName(act)}] exploding 3x3 at (${targetX}, ${targetY}) (15 DMG) and created FIRE ZONE for 2 turns!` : `Nhịp #${stepIndex + 1}: ${actor.name} bắn [${act.name}] nổ 3x3 tại (${targetX}, ${targetY}) (15 DMG) và tạo VÙNG CHÁY 2 lượt!`, 'clash');

            let baseDmg = act.power || 15;
            if (hasBuffDmg) baseDmg = Math.round(baseDmg * dmgMult);

            for (const u of allLivingUnits) {
                if (Math.abs(u.x - targetX) <= 1 && Math.abs(u.y - targetY) <= 1) {
                    const uAct = u.queue ? u.queue[stepIndex] : null;
                    let uDmg = (u === actor) ? (act.power || 15) : baseDmg;
                    if (uAct && uAct.type === 'LEAP') uDmg = Math.round(uDmg * 0.75);

                    this.applyDamage(u, uDmg, actor);
                    this.createHitSparks(u.x, u.y, '#ea580c');
                    this.addFloatingText(`-${uDmg} HP!`, u.x, u.y, '#ea580c');
                    this.addCombatLog(this.lang === 'en' ? `💥 Fire Cannon blast hit ${u.name}! (-${uDmg} HP)!` : `💥 Vụ nổ Đại Bác Lửa trúng ${u.name}! (-${uDmg} HP)!`, 'hit');

                    if (u.charId === 'hookman') {
                        u.revealedTurns = 2;
                        if (u.isPlayer) this.playerRevealedTurns = 2;
                    }
                }
            }
            this.damageDeployablesInArea(targetX, targetY, 1, baseDmg, actor.team, actor);

            // Tạo Vùng Cháy tồn tại trong 2 lượt
            if (!this.fireZones) this.fireZones = [];
            this.fireZones.push({
                id: Date.now() + Math.random(),
                team: actor.team,
                x: targetX,
                y: targetY,
                aoeRadius: 1,
                turnsLeft: act.fireZoneDuration || 2,
                creatorName: actor.name,
                ownerUnit: actor
            });

            // Kẻ địch trong vùng kể từ thời điểm sau khi nổ tung sẽ bị hiệu ứng cháy
            for (const enemy of livingOpponents) {
                if (Math.abs(enemy.x - targetX) <= 1 && Math.abs(enemy.y - targetY) <= 1) {
                    if (enemy.hp > 0) {
                        this.applyBurn(enemy, 3, 5);
                        this.addFloatingText(this.lang === 'en' ? '🔥 BURNING!' : '🔥 BỐC CHÁY!', enemy.x, enemy.y, '#ea580c');
                    }
                }
            }

            actor.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 4;
        }
        else if (act.type === 'RECT_SLASH') {
            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playCyberBladeSlash();

            const curAmmo = actor.skillAmmo[act.skillId] !== undefined ? actor.skillAmmo[act.skillId] : 2;
            const remAmmo = Math.max(0, curAmmo - 1);
            actor.skillAmmo[act.skillId] = remAmmo;
            if (actor.isPlayer && this.skillAmmo) this.skillAmmo[act.skillId] = remAmmo;
            if (actor === this.cpu && this.cpuSkillAmmo) this.cpuSkillAmmo[act.skillId] = remAmmo;

            if (remAmmo === 0) {
                actor.cooldowns[act.skillId] = act.cooldown || 4;
                if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 4;
                if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 4;
                this.addCombatLog(this.lang === 'en' ? `⚠️ ${actor.name} [Wrist Blades] expended 2 uses! Starting 4-turn cooldown!` : `⚠️ ${actor.name} [Kiếm Gắn Tay] dùng hết 2 lượt! Bắt đầu hồi chiêu 4 lượt!`, 'system');
            }

            const slashTiles = this.getRectSlashTiles(actor.x, actor.y, act.dir);
            this.createRectSlashEffect(slashTiles, actor.charThemeColor || '#06b6d4');
            await this.delay(220);

            let hitAny = false;
            for (const target of livingOpponents) {
                if (slashTiles.some(t => t.x === target.x && t.y === target.y)) {
                    hitAny = true;
                    if (target.shieldDir) {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playShield();
                        this.addFloatingText(this.lang === 'en' ? 'BLOCKED BLADE!' : 'CHẶN ĐỨNG KIẾM!', target.x, target.y, '#60a5fa');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${target.name} raised Shield, blocking Wrist Blades from ${actor.name}! (0 DMG)` : `Nhịp #${stepIndex + 1}: ${target.name} giương Khiên chặn đứng Kiếm Gắn Tay từ ${actor.name}! (0 DMG)`, 'block');
                    } else {
                        if (window.soundCtrl && (actor.isPlayer || target.isPlayer)) window.soundCtrl.playHit();
                        let dmg = act.power || 60;
                        if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                        const targetAct = target.queue ? target.queue[stepIndex] : null;
                        if (targetAct && targetAct.type === 'LEAP') dmg = Math.round(dmg * 0.75);

                        this.applyDamage(target, dmg, actor);
                        this.createHitSparks(target.x, target.y, '#06b6d4');
                        this.addFloatingText(`-${dmg} HP!`, target.x, target.y, '#f87171');
                        this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: 🗡️ [Wrist Blades] ${actor.name} SWEEP-SLASHED 3x2 HIT ${target.name}! (-${dmg} HP${buffTag})!` : `Nhịp #${stepIndex + 1}: 🗡️ [Kiếm Gắn Tay] ${actor.name} CHÉM QUÉT 3x2 TRÚNG ${target.name}! (-${dmg} HP${buffTag})!`, 'hit');

                        if (target.charId === 'hookman') {
                            target.revealedTurns = 2;
                            if (target.isPlayer) this.playerRevealedTurns = 2;
                            this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', target.x, target.y, '#f43f5e');
                        }
                    }
                }
            }

            for (const tile of slashTiles) {
                const enemyDep = this.getEnemyDeployableAt(tile.x, tile.y, actor.team);
                if (enemyDep) {
                    hitAny = true;
                    let dmg = act.power || 60;
                    if (hasBuffDmg) dmg = Math.round(dmg * dmgMult);
                    this.damageDeployable(enemyDep, dmg, actor);
                }
            }

            if (!hitAny) {
                this.addFloatingText(this.lang === 'en' ? 'MISS!' : 'CHÉM HỤT!', actor.x, actor.y, '#94a3b8');
            }
        }
        else if (act.type === 'DEPLOY_SENTRY') {
            const uD = DIRECTIONS[act.dir];
            let sx = actor.x + (uD ? uD.dx : 1);
            let sy = actor.y + (uD ? uD.dy : 0);
            sx = Math.max(0, Math.min(GRID_COLS - 1, sx));
            sy = Math.max(0, Math.min(GRID_ROWS - 1, sy));

            if (!this.sentries) this.sentries = [];
            // Quy tắc sở hữu: Mỗi Engie chỉ duy trì tối đa 1 Sentry. Đặt mới tự động thay thế cái cũ
            this.sentries = this.sentries.filter(s => s.owner !== actor);

            const sentry = {
                id: Date.now() + Math.random(),
                team: actor.team,
                owner: actor,
                ownerName: actor.name,
                x: sx,
                y: sy,
                hp: act.sentryHp || 50,
                maxHp: act.sentryHp || 50,
                power: act.power || 10,
                range: act.sentryRange || 5,
                color: actor.charThemeColor || '#f59e0b'
            };
            this.sentries.push(sentry);

            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playWrench();
            this.createBuffSparks(sx, sy, '#f59e0b');
            this.addFloatingText(this.lang === 'en' ? '🤖 SENTRY (50 HP)!' : '🤖 XÂY SENTRY (50 HP)!', sx, sy, '#f59e0b');
            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${actor.name} deployed [Auto-Sentry] at (${sx}, ${sy}) (50 HP, 11x11 Zone, 10 DMG)!`
                    : `Nhịp #${stepIndex + 1}: ${actor.name} triển khai [Auto-Sentry] tại (${sx}, ${sy}) (50 HP, Quét 11x11, 10 DMG)!`,
                'buff'
            );

            actor.cooldowns[act.skillId] = act.cooldown || 2;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 2;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 2;
        }
        else if (act.type === 'DEPLOY_TELEPORTER') {
            const uD = DIRECTIONS[act.dir];
            let thermalBonus = 0;
            if (actor.buffs && actor.buffs.thermalVision && actor.buffs.thermalVision.active) {
                thermalBonus = actor.buffs.thermalVision.rangeBonus || 1;
                actor.buffs.thermalVision.active = false;
            }
            const maxRange = (act.range || 5) + thermalBonus;
            const inX = actor.x;
            const inY = actor.y;
            let outX = actor.x + (uD ? uD.dx : 1) * maxRange;
            let outY = actor.y + (uD ? uD.dy : 0) * maxRange;
            outX = Math.max(0, Math.min(GRID_COLS - 1, outX));
            outY = Math.max(0, Math.min(GRID_ROWS - 1, outY));

            if (outX === inX && outY === inY) {
                const altDx = (uD && uD.dx !== 0) ? -uD.dx : 1;
                outX = Math.max(0, Math.min(GRID_COLS - 1, inX + altDx * maxRange));
            }

            if (!this.teleporters) this.teleporters = [];
            // Quy tắc sở hữu: Mỗi Engie chỉ duy trì tối đa 1 cặp Teleporter. Đặt mới tự động thay thế cái cũ
            this.teleporters = this.teleporters.filter(t => t.owner !== actor);

            const tele = {
                id: Date.now() + Math.random(),
                team: actor.team,
                owner: actor,
                ownerName: actor.name,
                inX: inX,
                inY: inY,
                outX: outX,
                outY: outY,
                hp: act.portalHp || 60,
                maxHp: act.portalHp || 60,
                color: '#06b6d4'
            };
            this.teleporters.push(tele);

            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playPortalOpen();
            this.createBuffSparks(inX, inY, '#06b6d4');
            this.createBuffSparks(outX, outY, '#06b6d4');
            this.addFloatingText(this.lang === 'en' ? '🌀 TELEPORTER (60 HP)!' : '🌀 CỔNG DỊCH CHUYỂN (60 HP)!', inX, inY, '#06b6d4');
            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${actor.name} opened Teleporter Entrance at (${inX}, ${inY}) and Exit at (${outX}, ${outY}) (60 HP)!`
                    : `Nhịp #${stepIndex + 1}: ${actor.name} mở Cổng Vào tại (${inX}, ${inY}) và Cổng Ra tại (${outX}, ${outY}) (60 HP)!`,
                'buff'
            );

            actor.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'TELEKINESIS') {
            // Phạm vi quét 5x5 quanh Fake Savior (bán kính Chebyshev <= 2)
            const scanRadius = 2;
            const inRangeEnemies = livingOpponents.filter(e =>
                Math.abs(e.x - actor.x) <= scanRadius &&
                Math.abs(e.y - actor.y) <= scanRadius
            );

            if (inRangeEnemies.length === 0) {
                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playTelekinesis();
                this.addFloatingText(this.lang === 'en' ? 'NO TARGET (5x5)!' : 'HỤT (KHÔNG CÓ ĐỊCH 5x5)!', actor.x, actor.y, '#94a3b8');
                this.addCombatLog(
                    this.lang === 'en'
                        ? `Beat #${stepIndex + 1}: ${actor.name} used Telekinesis, but no enemies within 5x5 range!`
                        : `Nhịp #${stepIndex + 1}: ${actor.name} thi triển Telekinesis, nhưng không có kẻ địch trong phạm vi 5x5!`,
                    'system'
                );
            } else {
                // Tìm kẻ địch gần nhất (theo khoảng cách Euclid)
                inRangeEnemies.sort((a, b) => {
                    const distA = Math.hypot(a.x - actor.x, a.y - actor.y);
                    const distB = Math.hypot(b.x - actor.x, b.y - actor.y);
                    return distA - distB;
                });
                const primaryTarget = inRangeEnemies[0];

                // Xác định hướng di chuyển gần nhất của kẻ thù
                let moveDx = 0;
                let moveDy = 0;
                if (primaryTarget.lastMoveDx !== undefined && primaryTarget.lastMoveDy !== undefined && (primaryTarget.lastMoveDx !== 0 || primaryTarget.lastMoveDy !== 0)) {
                    moveDx = primaryTarget.lastMoveDx;
                    moveDy = primaryTarget.lastMoveDy;
                } else if (primaryTarget.prevX !== undefined && primaryTarget.prevY !== undefined && (primaryTarget.x !== primaryTarget.prevX || primaryTarget.y !== primaryTarget.prevY)) {
                    moveDx = primaryTarget.x - primaryTarget.prevX;
                    moveDy = primaryTarget.y - primaryTarget.prevY;
                } else if (primaryTarget.dir && DIRECTIONS[primaryTarget.dir]) {
                    moveDx = DIRECTIONS[primaryTarget.dir].dx;
                    moveDy = DIRECTIONS[primaryTarget.dir].dy;
                } else {
                    moveDx = Math.sign(primaryTarget.x - actor.x) || 1;
                    moveDy = Math.sign(primaryTarget.y - actor.y) || 0;
                }

                // Hướng hất văng ngược lại:
                let kbDx = -Math.sign(moveDx);
                let kbDy = -Math.sign(moveDy);
                if (kbDx === 0 && kbDy === 0) {
                    kbDx = -Math.sign(primaryTarget.x - actor.x) || -1;
                    kbDy = -Math.sign(primaryTarget.y - actor.y) || 0;
                }

                const affected = [primaryTarget];

                // Hất văng mục tiêu chính 3 ô theo (kbDx, kbDy)
                let curX = primaryTarget.x;
                let curY = primaryTarget.y;

                for (let step = 1; step <= 3; step++) {
                    const nextX = Math.max(0, Math.min(GRID_COLS - 1, curX + kbDx));
                    const nextY = Math.max(0, Math.min(GRID_ROWS - 1, curY + kbDy));

                    if (this.isObstacle && this.isObstacle(nextX, nextY)) break;

                    // Nếu trong 3 ô có một kẻ địch khác thì kẻ địch đó cũng bị ảnh hưởng
                    const otherEnemy = livingOpponents.find(e => e !== primaryTarget && !affected.includes(e) && e.x === nextX && e.y === nextY);
                    if (otherEnemy) {
                        affected.push(otherEnemy);
                    }

                    curX = nextX;
                    curY = nextY;
                }

                // Cập nhật vị trí mới cho mục tiêu chính
                primaryTarget.prevX = primaryTarget.x;
                primaryTarget.prevY = primaryTarget.y;
                primaryTarget.x = curX;
                primaryTarget.y = curY;
                primaryTarget.renderX = curX;
                primaryTarget.renderY = curY;
                this.checkFireZones(primaryTarget);
                this.checkTeleporters(primaryTarget);

                // Nếu có kẻ địch khác trong 3 ô thì đẩy xa 3 ô theo cùng hướng
                for (let i = 1; i < affected.length; i++) {
                    const collateralEnemy = affected[i];
                    let colX = collateralEnemy.x;
                    let colY = collateralEnemy.y;
                    for (let s = 1; s <= 3; s++) {
                        const nX = Math.max(0, Math.min(GRID_COLS - 1, colX + kbDx));
                        const nY = Math.max(0, Math.min(GRID_ROWS - 1, colY + kbDy));
                        if (this.isObstacle && this.isObstacle(nX, nY)) break;
                        colX = nX;
                        colY = nY;
                    }
                    collateralEnemy.prevX = collateralEnemy.x;
                    collateralEnemy.prevY = collateralEnemy.y;
                    collateralEnemy.x = colX;
                    collateralEnemy.y = colY;
                    collateralEnemy.renderX = colX;
                    collateralEnemy.renderY = colY;
                    this.checkFireZones(collateralEnemy);
                    this.checkTeleporters(collateralEnemy);
                }

                // Sát thương: 1 kẻ thù -> 20 DMG. Nhiều kẻ thù -> 30 DMG mỗi người
                const baseDmg = (affected.length === 1) ? 20 : 30;
                let finalDmg = baseDmg;
                if (hasBuffDmg) finalDmg = Math.round(baseDmg * dmgMult);

                if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playTelekinesis();
                this.createHitSparks(actor.x, actor.y, '#c084fc');

                for (const target of affected) {
                    this.applyDamage(target, finalDmg, actor);
                    this.createHitSparks(target.x, target.y, '#c084fc');
                    this.addFloatingText(`🔮 TELEKINESIS -${finalDmg} HP!`, target.x, target.y, '#c084fc');
                    this.addCombatLog(
                        this.lang === 'en'
                            ? `Beat #${stepIndex + 1}: ${actor.name} Telekinesis knocked back ${target.name} for ${finalDmg} DMG${affected.length > 1 ? ' (Chain hit 30 DMG/each!)' : ''}!`
                            : `Nhịp #${stepIndex + 1}: ${actor.name} [Telekinesis] hất văng ${target.name} và gây ${finalDmg} sát thương${affected.length > 1 ? ' (Trúng nhiều mục tiêu: 30 DMG/người!)' : ''}!`,
                        'hit'
                    );
                }
            }

            actor.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 3;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 3;
        }
        else if (act.type === 'NECROMANCY') {
            if (!this.zombies) this.zombies = [];
            // Mỗi Fake Savior duy trì tối đa 2 thây ma. Đặt mới tự động dọn thây ma cũ của chủ nhân
            this.zombies = this.zombies.filter(z => z.owner !== actor);

            const spawnOffsets = [
                { dx: 1, dy: 0 }, { dx: -1, dy: 0 }, { dx: 0, dy: 1 }, { dx: 0, dy: -1 },
                { dx: 1, dy: 1 }, { dx: -1, dy: -1 }, { dx: 1, dy: -1 }, { dx: -1, dy: 1 },
                { dx: 2, dy: 0 }, { dx: -2, dy: 0 }, { dx: 0, dy: 2 }, { dx: 0, dy: -2 }
            ];

            const isOccupied = (x, y) => {
                if (x < 0 || x >= GRID_COLS || y < 0 || y >= GRID_ROWS) return true;
                if (this.isObstacle && this.isObstacle(x, y)) return true;
                if (this.blueTeam.some(u => u.hp > 0 && u.x === x && u.y === y)) return true;
                if (this.redTeam.some(u => u.hp > 0 && u.x === x && u.y === y)) return true;
                if (this.sentries && this.sentries.some(s => s.hp > 0 && s.x === x && s.y === y)) return true;
                if (this.teleporters && this.teleporters.some(t => t.hp > 0 && ((t.inX === x && t.inY === y) || (t.outX === x && t.outY === y)))) return true;
                if (this.zombies && this.zombies.some(z => z.hp > 0 && z.x === x && z.y === y)) return true;
                return false;
            };

            const createdZombies = [];
            for (const offset of spawnOffsets) {
                if (createdZombies.length >= 2) break;
                const zx = actor.x + offset.dx;
                const zy = actor.y + offset.dy;
                if (!isOccupied(zx, zy)) {
                    const z = {
                        id: Date.now() + Math.random(),
                        team: actor.team,
                        owner: actor,
                        ownerName: actor.name,
                        name: `${actor.team === 'BLUE' ? (this.lang === 'en' ? 'Blue Zombie' : 'Thây Ma Xanh') : (this.lang === 'en' ? 'Red Zombie' : 'Thây Ma Đỏ')}`,
                        avatar: '🧟',
                        x: zx,
                        y: zy,
                        hp: act.zombieHp || 40,
                        maxHp: act.zombieHp || 40,
                        power: act.zombiePower || 35,
                        range: 1, // 3x3
                        attackedThisTurn: false,
                        color: actor.team === 'BLUE' ? '#38bdf8' : '#f43f5e'
                    };
                    this.zombies.push(z);
                    createdZombies.push(z);
                }
            }

            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) window.soundCtrl.playNecromancy();
            for (const z of createdZombies) {
                this.createBuffSparks(z.x, z.y, '#10b981');
                this.addFloatingText(this.lang === 'en' ? '🧟 ZOMBIE (40 HP)!' : '🧟 THÂY MA (40 HP)!', z.x, z.y, '#10b981');
            }

            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${actor.name} cast Necromancy, summoning 2 CPU Zombies (40 HP, 3x3 35 DMG)!`
                    : `Nhịp #${stepIndex + 1}: ${actor.name} thi triển [Necromancy], triệu hồi 2 thây ma CPU (40 HP, Quét 3x3 gây 35 DMG)!`,
                'buff'
            );

            actor.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId] = act.cooldown || 4;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId] = act.cooldown || 4;
        }
        else if (act.type === 'HEAL_STATION') {
            const allies = (actor.team === 'BLUE' ? this.blueTeam : this.redTeam).filter(u => u.hp > 0);
            const healRange = act.range !== undefined ? act.range : 2; // Chebyshev distance <= 2 is 5x5 zone
            let totalHealed = 0;
            let healedUnits = 0;

            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) {
                window.soundCtrl.playHealStation();
            }

            for (const ally of allies) {
                // Check 5x5 area around Medic
                if (Math.abs(ally.x - actor.x) <= healRange && Math.abs(ally.y - actor.y) <= healRange) {
                    const healPower = act.power || 10;
                    const prevHp = ally.hp;
                    ally.hp = Math.min(ally.maxHp, ally.hp + healPower);
                    const actualHeal = ally.hp - prevHp;
                    totalHealed += actualHeal;
                    healedUnits++;

                    this.createBuffSparks(ally.x, ally.y, '#10b981');
                    this.addFloatingText(`+${healPower} HP!`, ally.x, ally.y, '#10b981');
                }
            }

            if (!actor.stats) {
                actor.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
            }
            actor.stats.healing = (actor.stats.healing || 0) + totalHealed;

            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${actor.name} deployed [Healing Station] (5x5 zone)! Restored HP to ${healedUnits} teammate(s) (Total +${totalHealed} HP)!`
                    : `Nhịp #${stepIndex + 1}: ${actor.name} triển khai [Trạm Hồi Máu] (khu vực 5x5)! Hồi 10 máu cho ${healedUnits} đồng đội (Tổng hồi +${totalHealed} HP)!`,
                'buff'
            );
        }
        else if (act.type === 'INVULNERABILITY_SHIELD') {
            const allies = (actor.team === 'BLUE' ? this.blueTeam : this.redTeam).filter(u => u.hp > 0);
            let targetAlly = act.targetUnit || (act.targetId ? allLivingUnits.find(u => u.id === act.targetId) : null);

            // 1. Kiểm tra theo hướng act.dir
            if (!targetAlly && act.dir && DIRECTIONS[act.dir]) {
                const uD = DIRECTIONS[act.dir];
                for (let r = 1; r <= (act.range || 8); r++) {
                    const tx = actor.x + uD.dx * r;
                    const ty = actor.y + uD.dy * r;
                    const match = allies.find(u => u.x === tx && u.y === ty);
                    if (match) {
                        targetAlly = match;
                        break;
                    }
                }
            }

            // 2. Nếu không tìm thấy theo hướng, ưu tiên đồng đội thấp máu nhất trong tầm (hoặc chính Medic)
            if (!targetAlly) {
                const candidateAllies = allies.filter(u => Math.hypot(u.x - actor.x, u.y - actor.y) <= (act.range || 8));
                if (candidateAllies.length > 0) {
                    candidateAllies.sort((a, b) => a.hp - b.hp);
                    targetAlly = candidateAllies[0];
                } else {
                    targetAlly = actor;
                }
            }

            if (!targetAlly.buffs) targetAlly.buffs = {};
            targetAlly.buffs.invulnerability = {
                active: false,
                primedForNextTurn: true,
                turnsLeft: 1,
                sourceName: actor.name
            };

            if (window.soundCtrl && (actor.isPlayer || livingOpponents.some(o => o.isPlayer))) {
                window.soundCtrl.playInvulnerabilityShield();
            }

            this.createBuffSparks(targetAlly.x, targetAlly.y, '#38bdf8');
            this.addFloatingText(this.lang === 'en' ? '🛡️ PRIMED SHIELD!' : '🛡️ NIỆM HỘ THUẪN!', targetAlly.x, targetAlly.y, '#38bdf8');
            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${actor.name} targeted ${targetAlly.name} with [Invulnerability Shield]! Immune to all damage next turn!`
                    : `Nhịp #${stepIndex + 1}: ${actor.name} niệm [Hộ Thuẫn Bất Tử] lên ${targetAlly.name}! Kháng mọi sát thương trong lượt tiếp theo!`,
                'buff'
            );

            actor.cooldowns[act.skillId || 'MEDIC_INVULNERABILITY_SHIELD'] = act.cooldown || 4;
            if (actor.isPlayer && this.cooldowns) this.cooldowns[act.skillId || 'MEDIC_INVULNERABILITY_SHIELD'] = act.cooldown || 4;
            if (actor === this.cpu && this.cpuCooldowns) this.cpuCooldowns[act.skillId || 'MEDIC_INVULNERABILITY_SHIELD'] = act.cooldown || 4;
        }
    }

    finishTurn() {
        this.addCombatLog(`${this.lang === 'en' ? 'Completed Turn' : 'Hoàn thành Lượt'} ${this.turn}!`, 'system');

        if (this.zombies) {
            this.zombies.forEach(z => z.attackedThisTurn = false);
            this.zombies = this.zombies.filter(z => z.hp > 0);
        }

        const allUnits = [...this.blueTeam, ...this.redTeam];

        // 0 & 1 & 2 & 3. Cập nhật trạng thái từng đấu thủ còn sống
        for (const unit of allUnits) {
            if (unit.hp <= 0) continue;

            // 0. Giảm thời gian lộ diện của Hookman
            if (unit.revealedTurns > 0) {
                unit.revealedTurns--;
                if (unit.isPlayer) this.playerRevealedTurns = unit.revealedTurns;
                if (unit.revealedTurns === 0) {
                    this.addCombatLog(this.lang === 'en' ? `👁️ ${unit.name} wiped all traces and can enter stealth again outside 7x7!` : `👁️ ${unit.name} đã xóa sạch dấu vết, có thể tàng hình trở lại nếu ngoài 7x7!`, 'system');
                }
            }

            // 1. Hồi phục máu Adrenaline cuối mỗi lượt (+5 HP, kéo dài 3 lượt)
            if (unit.buffs && unit.buffs.adrenaline && unit.buffs.adrenaline.turnsLeft > 0) {
                const healAmount = Math.min(5, unit.maxHp - unit.hp);
                unit.hp += healAmount;
                if (!unit.stats) unit.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
                unit.stats.healing += healAmount;
                unit.buffs.adrenaline.turnsLeft--;
                if (unit.isPlayer && this.playerBuffs) this.playerBuffs.adrenaline.turnsLeft = unit.buffs.adrenaline.turnsLeft;

                if (unit.isPlayer && window.soundCtrl) window.soundCtrl.playSelect();
                this.createBuffSparks(unit.x, unit.y, '#10b981');
                this.addFloatingText(`+${healAmount} HP (ADRENALINE)`, unit.x, unit.y, '#10b981');
                this.addCombatLog(this.lang === 'en' ? `💉 Turn end: ${unit.name} Adrenaline restored +${healAmount} HP! (${unit.buffs.adrenaline.turnsLeft} turns left)` : `💉 Cuối lượt: ${unit.name} Adrenaline hồi phục +${healAmount} HP! (Còn ${unit.buffs.adrenaline.turnsLeft}L)`, 'hit');
            }

            // 2. Giảm thời gian hồi chiêu
            for (const skillId in unit.cooldowns) {
                if (unit.cooldowns[skillId] > 0) {
                    unit.cooldowns[skillId]--;
                    if (unit.cooldowns[skillId] === 0) {
                        if (skillId === 'SMOKE_BOMB_LAUNCHER') {
                            unit.skillAmmo['SMOKE_BOMB_LAUNCHER'] = 2;
                            if (unit.isPlayer && this.skillAmmo) this.skillAmmo['SMOKE_BOMB_LAUNCHER'] = 2;
                            this.addCombatLog(this.lang === 'en' ? `🔄 ${unit.name} [Smoke Bomb Launcher] reloaded full 2/2 rounds!` : `🔄 ${unit.name} [Súng Bắn Bom] nạp lại đầy đủ 2/2 viên đạn!`, 'system');
                        } else if (skillId === 'RAZOR_BLADE') {
                            unit.skillAmmo['RAZOR_BLADE'] = 2;
                            if (unit.isPlayer && this.skillAmmo) this.skillAmmo['RAZOR_BLADE'] = 2;
                            this.addCombatLog(this.lang === 'en' ? `🔄 ${unit.name} [Wrist Blades] recharged full 2/2 uses!` : `🔄 ${unit.name} [Kiếm Gắn Tay] nạp lại đầy đủ 2/2 lượt chém!`, 'system');
                        } else {
                            this.addCombatLog(this.lang === 'en' ? `✨ ${unit.name}'s [${skillId}] is off cooldown!` : `✨ ${unit.name} Kỹ năng [${skillId}] đã hồi chiêu xong!`, 'system');
                        }
                    }
                }
            }

            // 3. Giảm thời gian Buff Thuốc Lá (Smoke guy: +30% DMG, +1 Bước trong 2 lượt)
            if (unit.buffs && unit.buffs.cigarette && unit.buffs.cigarette.turnsLeft > 0) {
                unit.buffs.cigarette.turnsLeft--;
                if (unit.isPlayer && this.playerBuffs) this.playerBuffs.cigarette.turnsLeft = unit.buffs.cigarette.turnsLeft;
                if (unit.buffs.cigarette.turnsLeft === 0) {
                    unit.cooldowns['SMOKE_CIGARETTE'] = 3;
                    this.addCombatLog(this.lang === 'en' ? `⏳ ${unit.name}'s [Cigarette] smoke has dissipated, 3-turn cooldown begins!` : `⏳ Khói [Thuốc Lá] của ${unit.name} đã tàn, bắt đầu hồi chiêu 3 lượt!`, 'system');
                }
            }

            // 5. Cập nhật Hộ Thuẫn Bất Tử (Medic)
            if (unit.buffs && unit.buffs.invulnerability) {
                const inv = unit.buffs.invulnerability;
                if (inv.active) {
                    inv.turnsLeft--;
                    if (inv.turnsLeft <= 0) {
                        inv.active = false;
                        this.addCombatLog(
                            this.lang === 'en'
                                ? `✨ [Invulnerability Shield] on ${unit.name} has expired!`
                                : `✨ [Hộ Thuẫn Bất Tử] trên ${unit.name} đã kết thúc hiệu lực!`,
                            'system'
                        );
                    }
                } else if (inv.primedForNextTurn) {
                    inv.primedForNextTurn = false;
                    inv.active = true;
                    inv.turnsLeft = 1;
                    if (window.soundCtrl) window.soundCtrl.playInvulnerabilityShield();
                    this.createBuffSparks(unit.x, unit.y, '#38bdf8');
                    this.addFloatingText(
                        this.lang === 'en' ? '🛡️ INVULNERABLE (1 TURN)!' : '🛡️ BẤT TỬ (1 LƯỢT)!',
                        unit.x,
                        unit.y,
                        '#38bdf8'
                    );
                    this.addCombatLog(
                        this.lang === 'en'
                            ? `🛡️ ${unit.name} is now protected by [Invulnerability Shield]! Immune to all damage this turn!`
                            : `🛡️ ${unit.name} bắt đầu kích hoạt [Hộ Thuẫn Bất Tử]! Kháng toàn bộ sát thương trong lượt này!`,
                        'shield'
                    );
                }
            }

            // 4. Sát thương Cháy (Burn DOT: -5 HP/lượt, không thể cộng dồn)
            if (unit.burnTurns > 0) {
                const burnDmg = unit.burnDmg || 5;
                this.applyDamage(unit, burnDmg, unit.burnSource || null);
                unit.burnTurns--;
                this.createHitSparks(unit.x, unit.y, '#ea580c');
                this.addFloatingText(this.lang === 'en' ? `-${burnDmg} HP (BURN 🔥)` : `-${burnDmg} HP (CHÁY 🔥)`, unit.x, unit.y, '#ea580c');
                this.addCombatLog(this.lang === 'en'
                    ? `🔥 Turn end: ${unit.name} suffers -${burnDmg} Burn damage! (${unit.burnTurns} turns left)`
                    : `🔥 Cuối lượt: ${unit.name} bị thiêu đốt mất -${burnDmg} HP! (Còn ${unit.burnTurns}L cháy)`, 'hit');
            }
        }

        // 4. Kích hoạt kéo Dây Móc Hookman (Hết lượt sau kéo 2 ô)
        const remainingTethers = [];
        for (const tether of this.activeHookTethers) {
            const hooker = tether.sourceUnit || (tether.source === 'PLAYER' ? this.player : this.cpu);
            const victim = tether.targetUnit || (tether.target === 'CPU' ? this.cpu : this.player);

            if (tether.turnsUntilPull <= 0) {
                if (hooker && victim && hooker.hp > 0 && victim.hp > 0) {
                    let pulledSteps = 0;
                    for (let s = 0; s < (tether.pullDist || 2); s++) {
                        const stepDx = Math.sign(hooker.x - victim.x);
                        const stepDy = Math.sign(hooker.y - victim.y);
                        if (stepDx === 0 && stepDy === 0) break;

                        const nextVx = Math.max(0, Math.min(GRID_COLS - 1, victim.x + stepDx));
                        const nextVy = Math.max(0, Math.min(GRID_ROWS - 1, victim.y + stepDy));
                        if (nextVx === hooker.x && nextVy === hooker.y) break;

                        victim.x = nextVx;
                        victim.y = nextVy;
                        pulledSteps++;
                    }

                    if (pulledSteps > 0) {
                        this.checkFireZones(victim);
                    }

                    if (window.soundCtrl) window.soundCtrl.playHookPull();
                    this.createHitSparks(victim.x, victim.y, '#ef4444');
                    this.addFloatingText(this.lang === 'en' ? `🪝 HOOK PULL ${pulledSteps} TILES!` : `🪝 GIẬT MÓC ${pulledSteps} Ô!`, victim.x, victim.y, '#ef4444');
                    this.addCombatLog(this.lang === 'en' ? `💥 TURN END: Chain tightened hard, pulling ${victim.name} ${pulledSteps} tiles closer!` : `💥 HẾT LƯỢT SAU: Dây xích siết mạnh, giật ${victim.name} lại gần ${pulledSteps} ô!`, 'clash');

                    hooker.cooldowns[tether.skillId] = tether.cdAfterPull || 4;
                    this.addCombatLog(this.lang === 'en' ? `⏳ ${hooker.name}'s [Grappling Hook] finished pull sequence, 4-turn cooldown!` : `⏳ [Móc Kéo] của ${hooker.name} đã hoàn tất chuỗi kéo, hồi chiêu 4 lượt!`, 'system');
                }
            } else {
                tether.turnsUntilPull--;
                this.addCombatLog(this.lang === 'en' ? `🪝 Hook is still anchored on ${victim ? victim.name : 'target'}, will pull at the end of next turn!` : `🪝 Dây móc vẫn đang găm chặt vào ${victim ? victim.name : 'đối thủ'}, sẽ siết kéo vào cuối lượt sau!`, 'system');
                remainingTethers.push(tether);
            }
        }
        this.activeHookTethers = remainingTethers;

        // 5. Kích hoạt đếm lùi lựu đạn hẹn giờ
        const detonatedHazards = [];
        this.groundHazards.forEach(h => {
            h.turnsLeft--;
            if (h.turnsLeft <= 0) {
                detonatedHazards.push(h);
            }
        });

        detonatedHazards.forEach(h => {
            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.createExplosionBurst(h.x, h.y, 45);
            this.addFloatingText(this.lang === 'en' ? '💥 BOOM! GRENADE (50 DMG)!' : '💥 BÙM! LỰU ĐẠN NỔ (50 DMG)!', h.x, h.y, '#ef4444');
            this.addCombatLog(this.lang === 'en' ? `💥 GRENADE AT (${h.x}, ${h.y}) DETONATED! Swept 3x3 area with 50 damage!` : `💥 LỰU ĐẠN TẠI (${h.x}, ${h.y}) PHÁT NỔ! Quét sạch khu vực 3x3 với 50 sát thương!`, 'clash');

            for (const u of allUnits) {
                if (u.hp > 0 && Math.abs(u.x - h.x) <= 1 && Math.abs(u.y - h.y) <= 1) {
                    this.applyDamage(u, h.power, h.ownerUnit || null);
                    this.createHitSparks(u.x, u.y, u.color);
                    this.addFloatingText(this.lang === 'en' ? `-${h.power} HP! (GRENADE)` : `-${h.power} HP! (LỰU ĐẠN)`, u.x, u.y, '#f87171');
                    this.addCombatLog(this.lang === 'en' ? `➔ ${u.name} caught in Grenade blast! Lost ${h.power} HP!` : `➔ ${u.name} dính trọn vụ nổ Lựu Đạn! Mất ${h.power} HP!`, 'hit');

                    if (u.charId === 'hookman') {
                        u.revealedTurns = 2;
                        if (u.isPlayer) this.playerRevealedTurns = 2;
                        this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', u.x, u.y, '#f43f5e');
                    }
                }
            }
            this.damageDeployablesInArea(h.x, h.y, 1, h.power, (h.owner === 'PLAYER' ? this.player.team : 'RED'), { name: h.ownerName || t('defaultGrenadeOwner') });
        });

        this.groundHazards = this.groundHazards.filter(h => h.turnsLeft > 0);

        // Giảm thời gian tồn tại của Vùng Cháy (Fire Zone: 2 lượt)
        if (this.fireZones && this.fireZones.length > 0) {
            for (const zone of this.fireZones) {
                zone.turnsLeft--;
                if (zone.turnsLeft === 0) {
                    this.addCombatLog(this.lang === 'en'
                        ? `💨 Fire Zone at (${zone.x}, ${zone.y}) has burned out!`
                        : `💨 Vùng Cháy tại (${zone.x}, ${zone.y}) đã tàn lụi!`, 'system');
                }
            }
            this.fireZones = this.fireZones.filter(z => z.turnsLeft > 0);
        }

        // 6. Xử lý Hồi sinh trong Chế độ KOTH (Áp dụng cho tất cả nhân vật sau 2 lượt)
        if (this.gameMode === 'KOTH') {
            for (const u of allUnits) {
                if (u.hp <= 0) {
                    if (u.respawnTurns > 0) {
                        u.respawnTurns--;
                    }
                    if (u.respawnTurns <= 0) {
                        u.hp = u.maxHp;
                        u.isDead = false;
                        u.alive = true;
                        u.isOiled = false;
                        u.burnTurns = 0;
                        u.isScoped = false;
                        u.isImmune = false;
                        if (u.buffs) {
                            u.buffs.destructiveShot = false;
                            u.buffs.thermalVision = { active: false, rangeBonus: 0 };
                            u.buffs.chaosShot = false;
                        }
                        const spawnPos = this.getRespawnPosition(u.team, u.index);
                        u.x = spawnPos.x;
                        u.y = spawnPos.y;
                        u.renderX = spawnPos.x;
                        u.renderY = spawnPos.y;
                        u.revealedTurns = 0;
                        for (const sId in u.cooldowns) {
                            u.cooldowns[sId] = 0;
                        }
                        if (u.character && u.character.skills) {
                            u.character.skills.forEach(s => {
                                if (s.maxAmmo) u.skillAmmo[s.id] = s.maxAmmo;
                            });
                        }
                        this.addCombatLog(t('respawnLogMsg', { name: u.name }), 'system');
                        this.addFloatingText(this.lang === 'en' ? '✨ RESPAWNED!' : '✨ HỒI SINH!', u.x, u.y, '#10b981');
                        this.createBuffSparks(u.x, u.y, '#10b981');
                        if (u.isPlayer && window.soundCtrl) window.soundCtrl.playSelect();
                    }
                }
            }
        }

        // 7. Đánh giá Cứ Điểm 5x5 & Tích lũy Điểm Chế độ KOTH (Chuẩn cơ chế Team Fortress 2)
        if (this.gameMode === 'KOTH') {
            const blueInZone = this.blueTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;
            const redInZone = this.redTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;

            // Đồng bộ hillOwner nếu hillScale đã ở mốc cực đại (hỗ trợ cả mock test và gameplay)
            if (this.hillScale >= 2) {
                this.hillOwner = 'BLUE';
            } else if (this.hillScale <= -2) {
                this.hillOwner = 'RED';
            }

            if (blueInZone > 0 && redInZone === 0) {
                // Đội Xanh chiếm mà không có đối thủ tranh chấp
                if (this.hillScale < 2) {
                    this.hillScale++;
                    if (this.hillScale === 2) {
                        this.hillOwner = 'BLUE';
                        this.addCombatLog(
                            this.lang === 'en' ? '🚩 BLUE SQUAD CAPTURED THE 5x5 HILL! (+1 Point/Turn)' : '🚩 ĐỘI XANH ĐÃ CHIẾM ĐƯỢC CỨ ĐIỂM 5x5! (+1 Điểm/Lượt)',
                            'hit'
                        );
                    } else {
                        this.addCombatLog(
                            this.lang === 'en' ? `🚩 Blue capturing the Hill (${this.hillScale}/2)` : `🚩 Đội Xanh đang tiến chiếm cứ điểm! (Trạng thái: ${this.hillScale}/2)`,
                            'hit'
                        );
                    }
                }
            } else if (redInZone > 0 && blueInZone === 0) {
                // Đội Đỏ chiếm mà không có đối thủ tranh chấp
                if (this.hillScale > -2) {
                    this.hillScale--;
                    if (this.hillScale === -2) {
                        this.hillOwner = 'RED';
                        this.addCombatLog(
                            this.lang === 'en' ? '🚩 RED SQUAD CAPTURED THE 5x5 HILL! (+1 Point/Turn)' : '🚩 ĐỘI ĐỎ ĐÃ CHIẾM ĐƯỢC CỨ ĐIỂM 5x5! (+1 Điểm/Lượt)',
                            'clash'
                        );
                    } else {
                        this.addCombatLog(
                            this.lang === 'en' ? `🚩 Red capturing the Hill (${Math.abs(this.hillScale)}/2)` : `🚩 Đội Đỏ đang tiến chiếm cứ điểm! (Trạng thái: ${Math.abs(this.hillScale)}/2)`,
                            'clash'
                        );
                    }
                }
            } else if (blueInZone > 0 && redInZone > 0) {
                this.addCombatLog(
                    this.lang === 'en'
                        ? `⚔️ CONTESTED! Both teams have units on the Hill (${blueInZone} Blue vs ${redInZone} Red)! Status frozen!`
                        : `⚔️ TRANH CHẤP! Cả 2 đội đều có người tại Cứ Điểm (${blueInZone} Xanh vs ${redInZone} Đỏ)! Trạng thái bị khóa!`,
                    'system'
                );
            } else {
                // blueInZone === 0 && redInZone === 0: Vắng bóng cả 2 đội
                // Tiêu biến tiến trình chiếm dở dang (Capture Progress Decay) chuẩn TF2
                if (this.hillOwner === 'BLUE' && this.hillScale < 2) {
                    this.hillScale++;
                } else if (this.hillOwner === 'RED' && this.hillScale > -2) {
                    this.hillScale--;
                } else if (!this.hillOwner) {
                    if (this.hillScale > 0) this.hillScale--;
                    else if (this.hillScale < 0) this.hillScale++;
                }
            }

            // Ghi 1 điểm cho mỗi lượt cho Đội Đang Sở Hữu Cứ Điểm (Chuẩn cơ chế TF2)
            // Kể cả khi cứ điểm đang bị Tranh Chấp (Contested) hay đối thủ đang lấn chiếm kéo thanh
            if (this.hillOwner === 'BLUE') {
                this.blueScore = Math.min(this.SCORE_LIMIT, this.blueScore + 1);
                for (const u of (this.blueTeam || [])) {
                    if (u.hp > 0 && Math.abs(u.x - this.HILL_CENTER_X) <= this.HILL_RADIUS && Math.abs(u.y - this.HILL_CENTER_Y) <= this.HILL_RADIUS) {
                        if (!u.stats) u.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
                        u.stats.hillPoints += 1;
                    }
                }
                this.addFloatingText(this.lang === 'en' ? '+1 POINT!' : '+1 ĐIỂM!', 10, 3, '#38bdf8');
                this.addCombatLog(
                    this.lang === 'en'
                        ? `⭐ Blue controls the Hill: +1 Point! (${this.blueScore}/${this.SCORE_LIMIT})`
                        : `⭐ Đội Xanh kiểm soát Cứ Điểm: +1 Điểm! (${this.blueScore}/${this.SCORE_LIMIT})`,
                    'system'
                );
            } else if (this.hillOwner === 'RED') {
                this.redScore = Math.min(this.SCORE_LIMIT, this.redScore + 1);
                for (const u of (this.redTeam || [])) {
                    if (u.hp > 0 && Math.abs(u.x - this.HILL_CENTER_X) <= this.HILL_RADIUS && Math.abs(u.y - this.HILL_CENTER_Y) <= this.HILL_RADIUS) {
                        if (!u.stats) u.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
                        u.stats.hillPoints += 1;
                    }
                }
                this.addFloatingText(this.lang === 'en' ? '+1 POINT!' : '+1 ĐIỂM!', 10, 3, '#f43f5e');
                this.addCombatLog(
                    this.lang === 'en'
                        ? `⭐ Red controls the Hill: +1 Point! (${this.redScore}/${this.SCORE_LIMIT})`
                        : `⭐ Đội Đỏ kiểm soát Cứ Điểm: +1 Điểm! (${this.redScore}/${this.SCORE_LIMIT})`,
                    'system'
                );
            }

            // Kiểm tra Điều kiện Thắng & Overtime (Chuẩn TF2)
            const blueReached = this.blueScore >= this.SCORE_LIMIT;
            const redReached = this.redScore >= this.SCORE_LIMIT;

            if (blueReached && !redReached) {
                if (this.hillOwner === 'BLUE') {
                    if (redInZone > 0 || this.hillScale < 2) {
                        this.inOvertime = true;
                        this.addCombatLog(t('kothOvertimeNotice'), 'clash');
                    } else {
                        this.inOvertime = false;
                        this.handleGameOver('BLUE_KOTH');
                        return;
                    }
                } else if (this.hillOwner === 'RED') {
                    // Đội Đỏ đã lật ngược chiếm thành công cứ điểm trong hiệp phụ -> Overtime kết thúc, game tiếp diễn với Đỏ giữ điểm
                    this.inOvertime = false;
                }
            } else if (redReached && !blueReached) {
                if (this.hillOwner === 'RED') {
                    if (blueInZone > 0 || this.hillScale > -2) {
                        this.inOvertime = true;
                        this.addCombatLog(t('kothOvertimeNotice'), 'clash');
                    } else {
                        this.inOvertime = false;
                        this.handleGameOver('RED_KOTH');
                        return;
                    }
                } else if (this.hillOwner === 'BLUE') {
                    this.inOvertime = false;
                }
            } else if (blueReached && redReached) {
                if (this.hillOwner === 'BLUE' && this.hillScale === 2 && redInZone === 0) {
                    this.inOvertime = false;
                    this.handleGameOver('BLUE_KOTH');
                    return;
                } else if (this.hillOwner === 'RED' && this.hillScale === -2 && blueInZone === 0) {
                    this.inOvertime = false;
                    this.handleGameOver('RED_KOTH');
                    return;
                } else {
                    this.inOvertime = true;
                    this.addCombatLog(t('kothOvertimeNotice'), 'clash');
                }
            }
        } else {
            // Chế độ DUEL 1v1
            const blueAliveCount = this.blueTeam.filter(u => u.hp > 0).length;
            const redAliveCount = this.redTeam.filter(u => u.hp > 0).length;

            if (blueAliveCount === 0 || redAliveCount === 0) {
                this.handleGameOver();
                return;
            }
        }

        this.turn++;
        this.phase = 'PLANNING';
        this.currentStep = -1;
        this.cpuQueue = [];
        for (const u of allUnits) {
            u.shieldDir = null;
        }

        if (this.isTwoPlayerMode) {
            this.activePlanningPlayer = 1;
            this.p1Queue = [];
            this.p2Queue = [];
            this.selectedCharacter = this.p1Unit.character;
            this.player = this.p1Unit;
            this.cpu = this.p2Unit;
            this.cooldowns = this.p1Unit.cooldowns;
            this.skillAmmo = this.p1Unit.skillAmmo;
            this.playerBuffs = this.p1Unit.buffs;
            this.currentSelectedDir = this.p1Unit.dir || (this.p1Unit.team === 'BLUE' ? 'RIGHT' : 'LEFT');
            this.highlightSelectedDirButton();

            if (this.gameMode === 'KOTH' && this.p1Unit && this.p1Unit.hp <= 0) {
                const respawnLabel = t('respawningTag', { turns: this.p1Unit.respawnTurns });
                this.p1Queue = [
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' }
                ];
            }
            this.playerQueue = this.p1Queue;
        } else {
            if (this.gameMode === 'KOTH' && this.player && this.player.hp <= 0) {
                const respawnLabel = t('respawningTag', { turns: this.player.respawnTurns });
                this.playerQueue = [
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' },
                    { type: 'WAIT', name: respawnLabel, icon: '💀', desc: t('waitingRespawnDesc'), desc_en: 'Awaiting respawn' }
                ];
            } else {
                this.playerQueue = [];
            }

            if (this.player) {
                this.cooldowns = this.player.cooldowns;
                this.skillAmmo = this.player.skillAmmo;
                this.playerBuffs = this.player.buffs;
            }
            if (this.cpu) {
                this.cpuCooldowns = this.cpu.cooldowns;
                this.cpuSkillAmmo = this.cpu.skillAmmo;
                this.cpuBuffs = this.cpu.buffs;
            }
        }

        for (let i = 0; i < 4; i++) {
            const pSlot = document.getElementById(`p-slot-${i}`);
            const cSlot = document.getElementById(`c-slot-${i}`);
            if (pSlot) pSlot.classList.remove('active-step');
            if (cSlot) {
                cSlot.classList.remove('active-step');
                cSlot.className = 'queue-slot';
                cSlot.innerHTML = `<span class="slot-step-num">#${i + 1}</span><span class="slot-icon">🔒</span><span class="slot-name">${this.lang === 'en' ? 'Secret' : 'Bí mật'}</span>`;
            }
        }

        this.updateSkillButtons();
        this.updateQueueDisplay();
        this.updateHUD();
    }

    applyBurn(target, turns = 3, dmg = 5, source = null) {
        if (!target || target.hp <= 0) return;
        target.burnTurns = Math.max(target.burnTurns || 0, turns);
        target.burnDmg = dmg; // không thể cộng dồn sát thương, duy trì 5 HP/lượt
        if (source) target.burnSource = source;
    }

    checkFireZones(unit) {
        if (!unit || unit.hp <= 0 || !this.fireZones || this.fireZones.length === 0) return;
        for (const zone of this.fireZones) {
            if (unit.team !== zone.team) {
                if (Math.abs(unit.x - zone.x) <= (zone.aoeRadius || 1) && Math.abs(unit.y - zone.y) <= (zone.aoeRadius || 1)) {
                    if (unit.isOiled) {
                        unit.isOiled = false;
                    }
                    this.applyBurn(unit, 3, 5, zone.ownerUnit || null);
                    this.createHitSparks(unit.x, unit.y, '#ea580c');
                    this.addFloatingText(this.lang === 'en' ? '🔥 BURNING!' : '🔥 BỐC CHÁY!', unit.x, unit.y, '#ea580c');
                    this.addCombatLog(this.lang === 'en'
                        ? `🔥 ${unit.name} entered Fire Zone and caught fire (-5 HP/turn for 3 turns)!`
                        : `🔥 ${unit.name} đi qua Vùng Cháy và bị thiêu đốt (-5 HP/lượt trong 3 lượt)!`, 'hit');
                    break;
                }
            }
        }
    }

    applyDamage(entity, amount, source = null) {
        if (!entity || entity.isImmune) return;
        const curAct = (entity.queue && this.currentStep >= 0) ? entity.queue[this.currentStep] : null;
        if (curAct && curAct.type === 'BOOM_LEAP') return;

        if (entity.buffs && entity.buffs.invulnerability && entity.buffs.invulnerability.active) {
            this.createHitSparks(entity.x, entity.y, '#38bdf8');
            this.addFloatingText(this.lang === 'en' ? '🛡️ DAMAGE IMMUNE!' : '🛡️ KHÁNG SÁT THƯƠNG!', entity.x, entity.y, '#38bdf8');
            this.addCombatLog(this.lang === 'en'
                ? `🛡️ ${entity.name}'s [Invulnerability Shield] completely absorbed ${amount} incoming damage!`
                : `🛡️ [Hộ Thuẫn Bất Tử] của ${entity.name} đã triệt tiêu hoàn toàn ${amount} sát thương!`, 'shield');
            return;
        }

        if (entity.isOiled && amount > 0) {
            entity.isOiled = false;
            this.applyBurn(entity, 3, 5, source);
            this.createHitSparks(entity.x, entity.y, '#ea580c');
            this.addFloatingText(this.lang === 'en' ? '🔥 OIL IGNITED!' : '🔥 DẦU BỐC CHÁY!', entity.x, entity.y, '#ea580c');
            this.addCombatLog(this.lang === 'en'
                ? `🔥 Oil on ${entity.name} ignited upon taking damage! Suffering Burn (-5 HP/turn for 3 turns)!`
                : `🔥 Lớp dầu trên ${entity.name} bốc cháy khi nhận sát thương! Bị thiêu đốt (-5 HP/lượt trong 3 lượt)!`, 'hit');
        }

        const prevHp = entity.hp;
        const actualDmg = Math.min(prevHp, amount);
        entity.hp = Math.max(0, entity.hp - amount);

        if (!entity.stats) {
            entity.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
        }
        entity.stats.damageTaken = (entity.stats.damageTaken || 0) + actualDmg;

        if (source && source !== entity) {
            if (!source.stats) {
                source.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
            }
            source.stats.damageDealt = (source.stats.damageDealt || 0) + actualDmg;
        }

        if (entity.hp === 0 && prevHp > 0) {
            entity.stats.deaths = (entity.stats.deaths || 0) + 1;
            if (source && source !== entity && source.stats) {
                source.stats.kills = (source.stats.kills || 0) + 1;
            }

            if (this.gameMode === 'KOTH' && !entity.isDead) {
                entity.isDead = true;
                entity.alive = false;
                entity.respawnTurns = this.RESPAWN_TURNS;
                this.addCombatLog(`💀 ${entity.name} ${this.lang === 'en' ? 'was eliminated! Respawning in 2 turns...' : 'đã hy sinh! Hồi sinh sau 2 lượt...'}`, 'clash');
                this.addFloatingText(this.lang === 'en' ? '💀 K.O! (RESPAWN 2T)' : '💀 K.O! (HỒI SINH 2L)', entity.x, entity.y, '#f43f5e');
            }
        }
    }

    handleGameOver(kothWinner = null) {
        this.triggerAd();
        this.phase = 'GAMEOVER';
        const modal = document.getElementById('gameModal');
        const title = document.getElementById('modalTitle');
        const desc = document.getElementById('modalDesc');

        if (this.isTwoPlayerMode) {
            const isPvp = this.p1Team !== this.p2Team;
            let p1Won = false;
            let p2Won = false;
            let isDraw = false;

            if (this.gameMode === 'KOTH') {
                const blueAlive = this.blueTeam.filter(u => u.hp > 0).length;
                const redAlive = this.redTeam.filter(u => u.hp > 0).length;
                const isBlueWinner = kothWinner === 'BLUE_KOTH' || (kothWinner === null && (this.blueScore > this.redScore || (redAlive === 0 && blueAlive > 0)));
                const isRedWinner = kothWinner === 'RED_KOTH' || (kothWinner === null && (this.redScore > this.blueScore || (blueAlive === 0 && redAlive > 0)));

                if (isPvp) {
                    if (isBlueWinner) {
                        p1Won = (this.p1Team === 'BLUE');
                        p2Won = (this.p2Team === 'BLUE');
                    } else if (isRedWinner) {
                        p1Won = (this.p1Team === 'RED');
                        p2Won = (this.p2Team === 'RED');
                    } else {
                        isDraw = true;
                    }
                } else {
                    const coopTeam = this.p1Team;
                    p1Won = p2Won = (coopTeam === 'BLUE' ? isBlueWinner : isRedWinner);
                }
            } else {
                // DUEL
                const blueAlive = this.blueTeam.filter(u => u.hp > 0).length;
                const redAlive = this.redTeam.filter(u => u.hp > 0).length;

                if (blueAlive === 0 && redAlive === 0) {
                    isDraw = true;
                } else if (redAlive === 0) {
                    if (isPvp) {
                        p1Won = (this.p1Team === 'BLUE');
                        p2Won = (this.p2Team === 'BLUE');
                    } else {
                        p1Won = p2Won = (this.p1Team === 'BLUE');
                    }
                } else if (blueAlive === 0) {
                    if (isPvp) {
                        p1Won = (this.p1Team === 'RED');
                        p2Won = (this.p2Team === 'RED');
                    } else {
                        p1Won = p2Won = (this.p1Team === 'RED');
                    }
                }
            }

            if (isPvp) {
                if (isDraw) {
                    title.innerText = t('modalDrawTitle');
                    title.className = 'modal-title clash';
                    desc.innerText = t('modalDrawDesc');
                } else if (p1Won) {
                    title.innerText = t('p1VictoryModal');
                    title.className = 'modal-title victory';
                    desc.innerText = this.lang === 'en'
                        ? `Player 1 [${getCharName(this.p1Unit.character, this.lang)}] defeated Player 2 on Turn ${this.turn}!`
                        : `Người chơi 1 [${getCharName(this.p1Unit.character, this.lang)}] đã đánh bại Người chơi 2 ở Lượt ${this.turn}!`;
                    if (window.soundCtrl) window.soundCtrl.playVictory();
                } else if (p2Won) {
                    title.innerText = t('p2VictoryModal');
                    title.className = 'modal-title victory';
                    desc.innerText = this.lang === 'en'
                        ? `Player 2 [${getCharName(this.p2Unit.character, this.lang)}] defeated Player 1 on Turn ${this.turn}!`
                        : `Người chơi 2 [${getCharName(this.p2Unit.character, this.lang)}] đã đánh bại Người chơi 1 ở Lượt ${this.turn}!`;
                    if (window.soundCtrl) window.soundCtrl.playVictory();
                }
            } else {
                if (p1Won) {
                    title.innerText = t('coopVictoryModal');
                    title.className = 'modal-title victory';
                    desc.innerText = this.lang === 'en'
                        ? `Player 1 & Player 2 successfully defeated all CPU enemies on Turn ${this.turn}!`
                        : `Cả Người chơi 1 & 2 đã phối hợp đánh bại toàn bộ quân CPU ở Lượt ${this.turn}!`;
                    if (window.soundCtrl) window.soundCtrl.playVictory();
                } else {
                    title.innerText = t('modalDefeatTitle');
                    title.className = 'modal-title defeat';
                    desc.innerText = this.lang === 'en'
                        ? `Both players were defeated on Turn ${this.turn}. Try again!`
                        : `Cả hai người chơi đã bị đối thủ CPU đánh bại ở Lượt ${this.turn}!`;
                    if (window.soundCtrl) window.soundCtrl.playDefeat();
                }
            }

            this.saveMatchRecord(kothWinner);
            this.renderPostMatchLeaderboard(kothWinner);

            modal.style.display = 'flex';
            this.updateHUD();
            return;
        }

        // --- 1P Mode ---
        if (this.gameMode === 'KOTH') {
            const blueAlive = this.blueTeam.filter(u => u.hp > 0).length;
            const redAlive = this.redTeam.filter(u => u.hp > 0).length;
            const isBlueVictory = kothWinner === 'BLUE_KOTH' || (kothWinner === null && (this.blueScore > this.redScore || (redAlive === 0 && blueAlive > 0)));
            if (isBlueVictory) {
                title.innerText = t('modalVictoryKothTitle');
                title.className = 'modal-title victory';
                desc.innerText = t('modalVictoryKothDesc');
                if (window.soundCtrl) window.soundCtrl.playVictory();
            } else {
                title.innerText = t('modalDefeatKothTitle');
                title.className = 'modal-title defeat';
                desc.innerText = t('modalDefeatKothDesc');
                if (window.soundCtrl) window.soundCtrl.playDefeat();
            }
        } else {
            const blueAlive = this.blueTeam.filter(u => u.hp > 0).length;
            const redAlive = this.redTeam.filter(u => u.hp > 0).length;

            if (blueAlive === 0 && redAlive === 0) {
                title.innerText = t('modalDrawTitle');
                title.className = 'modal-title clash';
                desc.innerText = t('modalDrawDesc');
            } else if (redAlive === 0) {
                title.innerText = t('modalVictoryTitle');
                title.className = 'modal-title victory';
                desc.innerText = this.lang === 'en'
                    ? `VICTORY! You eliminated your rival on Turn ${this.turn}!`
                    : `CHIẾN THẮNG! Bạn đã hạ gục đối thủ ở Lượt ${this.turn}!`;
                if (window.soundCtrl) window.soundCtrl.playVictory();
            } else {
                title.innerText = t('modalDefeatTitle');
                title.className = 'modal-title defeat';
                desc.innerText = this.lang === 'en'
                    ? `DEFEAT! You were eliminated on Turn ${this.turn}. Adjust your tactics!`
                    : `THẤT BẠI! Bạn đã bị hạ gục ở Lượt ${this.turn}. Hãy thử lại!`;
                if (window.soundCtrl) window.soundCtrl.playDefeat();
            }
        }

        this.saveMatchRecord(kothWinner);
        this.renderPostMatchLeaderboard(kothWinner);

        modal.style.display = 'flex';
        this.updateHUD();
    }

    // --- LEADERBOARD & STATS TRACKING ENGINE ---

    calculateUnitScore(unit) {
        if (!unit || !unit.stats) return 0;
        const s = unit.stats;
        const killScore = (s.kills || 0) * 100;
        const dmgScore = Math.round(s.damageDealt || 0);
        const healScore = Math.round((s.healing || 0) * 0.8);
        const hillScore = (s.hillPoints || 0) * 50;
        const deathPenalty = (s.deaths || 0) * 20;
        const aliveBonus = (unit.hp > 0) ? 50 : 0;
        const total = Math.max(0, killScore + dmgScore + healScore + hillScore + aliveBonus - deathPenalty);
        s.score = total;
        return total;
    }

    getMatchLeaderboard() {
        const allUnits = [...(this.blueTeam || []), ...(this.redTeam || [])];
        const entries = allUnits.map(u => {
            if (!u.stats) {
                u.stats = { kills: 0, deaths: 0, damageDealt: 0, damageTaken: 0, healing: 0, hillPoints: 0, score: 0 };
            }
            const score = this.calculateUnitScore(u);
            return {
                unit: u,
                id: u.id,
                name: u.name,
                avatar: u.avatar || '🪖',
                charId: u.charId,
                team: u.team,
                isPlayer: !!u.isPlayer,
                playerIndex: u.playerIndex || (u.isPlayer ? 1 : null),
                hp: Math.max(0, u.hp),
                maxHp: u.maxHp || 100,
                alive: u.hp > 0,
                kills: u.stats.kills || 0,
                deaths: u.stats.deaths || 0,
                damageDealt: u.stats.damageDealt || 0,
                damageTaken: u.stats.damageTaken || 0,
                healing: u.stats.healing || 0,
                hillPoints: u.stats.hillPoints || 0,
                score
            };
        });

        // Sắp xếp theo: Score DESC -> Kills DESC -> Damage DESC -> HP DESC
        entries.sort((a, b) => {
            if (b.score !== a.score) return b.score - a.score;
            if (b.kills !== a.kills) return b.kills - a.kills;
            if (b.damageDealt !== a.damageDealt) return b.damageDealt - a.damageDealt;
            return b.hp - a.hp;
        });

        entries.forEach((e, idx) => {
            e.rank = idx + 1;
            e.isMvp = (idx === 0);
        });

        return entries;
    }

    getTeamStats() {
        const blue = { score: 0, kills: 0, damageDealt: 0, aliveCount: 0, totalCount: (this.blueTeam || []).length };
        const red = { score: 0, kills: 0, damageDealt: 0, aliveCount: 0, totalCount: (this.redTeam || []).length };

        for (const u of (this.blueTeam || [])) {
            const score = this.calculateUnitScore(u);
            blue.score += score;
            blue.kills += (u.stats && u.stats.kills) || 0;
            blue.damageDealt += (u.stats && u.stats.damageDealt) || 0;
            if (u.hp > 0) blue.aliveCount++;
        }

        for (const u of (this.redTeam || [])) {
            const score = this.calculateUnitScore(u);
            red.score += score;
            red.kills += (u.stats && u.stats.kills) || 0;
            red.damageDealt += (u.stats && u.stats.damageDealt) || 0;
            if (u.hp > 0) red.aliveCount++;
        }

        return { blue, red };
    }

    openInMatchLeaderboard(filter = 'all') {
        const modal = document.getElementById('inMatchLeaderboardModal');
        if (!modal) return;
        this.isLeaderboardOpen = true;
        this.leaderboardFilter = filter;
        modal.style.display = 'flex';
        this.renderInMatchLeaderboard(filter);
        if (window.soundCtrl && window.soundCtrl.playSelect) window.soundCtrl.playSelect();
    }

    closeInMatchLeaderboard() {
        const modal = document.getElementById('inMatchLeaderboardModal');
        if (!modal) return;
        this.isLeaderboardOpen = false;
        modal.style.display = 'none';
        if (window.soundCtrl && window.soundCtrl.playUndo) window.soundCtrl.playUndo();
    }

    toggleInMatchLeaderboard() {
        if (this.isLeaderboardOpen) {
            this.closeInMatchLeaderboard();
        } else {
            if (this.phase === 'MAIN_MENU' || this.phase === 'LANG_SELECT') {
                this.openHallOfFame();
            } else {
                this.openInMatchLeaderboard(this.leaderboardFilter || 'all');
            }
        }
    }

    renderInMatchLeaderboard(filter = null) {
        if (filter) this.leaderboardFilter = filter;
        const curFilter = this.leaderboardFilter || 'all';

        const modal = document.getElementById('inMatchLeaderboardModal');
        if (!modal) return;

        // Cập nhật Subtitle thông tin trận
        const infoEl = document.getElementById('lbMatchInfo');
        if (infoEl) {
            const modeName = this.gameMode === 'KOTH' ? `KOTH (${(this.blueTeam || []).length}v${(this.redTeam || []).length})` : `DUEL (1v1)`;
            const blueScoreText = this.gameMode === 'KOTH' ? this.blueScore : (this.blueTeam || []).filter(u => u.hp > 0).length;
            const redScoreText = this.gameMode === 'KOTH' ? this.redScore : (this.redTeam || []).filter(u => u.hp > 0).length;
            infoEl.innerText = t('lbMatchInfo', {
                mode: modeName,
                turn: this.turn,
                blue: blueScoreText,
                red: redScoreText
            });
        }

        // Cập nhật Team Summary Bar
        const teamStats = this.getTeamStats();
        const bScore = document.getElementById('lbBlueScore');
        const bKills = document.getElementById('lbBlueKills');
        const bDmg = document.getElementById('lbBlueDmg');
        const bAlive = document.getElementById('lbBlueAlive');
        if (bScore) bScore.innerText = teamStats.blue.score;
        if (bKills) bKills.innerText = teamStats.blue.kills;
        if (bDmg) bDmg.innerText = teamStats.blue.damageDealt;
        if (bAlive) bAlive.innerText = `${teamStats.blue.aliveCount}/${teamStats.blue.totalCount}`;

        const rScore = document.getElementById('lbRedScore');
        const rKills = document.getElementById('lbRedKills');
        const rDmg = document.getElementById('lbRedDmg');
        const rAlive = document.getElementById('lbRedAlive');
        if (rScore) rScore.innerText = teamStats.red.score;
        if (rKills) rKills.innerText = teamStats.red.kills;
        if (rDmg) rDmg.innerText = teamStats.red.damageDealt;
        if (rAlive) rAlive.innerText = `${teamStats.red.aliveCount}/${teamStats.red.totalCount}`;

        // Cập nhật Tabs
        document.querySelectorAll('.lb-tab-btn').forEach(btn => {
            const f = btn.getAttribute('data-filter');
            btn.classList.toggle('active', f === curFilter);
        });

        // Ẩn/Hiện cột Hill nếu không phải KOTH
        const hillHeader = document.getElementById('colHeaderHill');
        if (hillHeader) {
            hillHeader.style.display = (this.gameMode === 'KOTH') ? '' : 'none';
        }

        // Render Table Body
        const tbody = document.getElementById('inMatchLbTbody');
        if (!tbody) return;

        let leaderboard = this.getMatchLeaderboard();
        if (curFilter === 'BLUE') leaderboard = leaderboard.filter(e => e.team === 'BLUE');
        else if (curFilter === 'RED') leaderboard = leaderboard.filter(e => e.team === 'RED');

        tbody.innerHTML = leaderboard.map(e => {
            const isMvp = e.isMvp;
            const isPlayer = e.isPlayer;
            const hpPct = Math.round((e.hp / e.maxHp) * 100);
            const teamBadgeClass = e.team === 'BLUE' ? 'blue' : 'red';
            const teamName = e.team === 'BLUE' ? (this.lang === 'en' ? 'Blue' : 'Xanh') : (this.lang === 'en' ? 'Red' : 'Đỏ');

            let rankBadge = `${e.rank}`;
            if (e.rank === 1) rankBadge = '🥇';
            else if (e.rank === 2) rankBadge = '🥈';
            else if (e.rank === 3) rankBadge = '🥉';

            const playerTag = isPlayer ? `<span class="lb-badge-you">${e.playerIndex === 2 ? 'P2' : (this.isTwoPlayerMode ? 'P1' : (this.lang === 'en' ? 'YOU' : 'BẠN'))}</span>` : '';
            const mvpTag = isMvp ? `<span class="lb-badge-mvp">MVP</span>` : '';

            const hillCell = (this.gameMode === 'KOTH') 
                ? `<td class="col-stat" style="color:#38bdf8; font-weight:700;">${e.hillPoints}</td>` 
                : '';

            return `
                <tr class="lb-row-${teamBadgeClass} ${isMvp ? 'lb-row-mvp' : ''} ${isPlayer ? 'lb-row-player' : ''} ${!e.alive ? 'lb-row-dead' : ''}">
                    <td class="col-rank">${rankBadge}</td>
                    <td class="col-char">
                        <div class="lb-avatar-tag">
                            <span class="lb-char-avatar">${e.avatar}</span>
                            <div class="lb-char-name-group">
                                <span class="lb-char-name">${e.name} ${playerTag} ${mvpTag}</span>
                                <span class="lb-char-subtag">${getCharTitle(getCharacterById(e.charId), this.lang)}</span>
                            </div>
                        </div>
                    </td>
                    <td class="col-team">
                        <span class="mvp-team-badge ${teamBadgeClass}">${teamName}</span>
                    </td>
                    <td class="col-hp">
                        <div style="font-size:0.75rem; font-weight:700; color:${e.alive ? '#f8fafc' : '#f43f5e'};">
                            ${e.alive ? `${e.hp}/${e.maxHp}` : (this.lang === 'en' ? '💀 DOWN' : '💀 HẠ GỤC')}
                        </div>
                        <div class="lb-hp-mini-bar">
                            <div class="lb-hp-mini-fill ${teamBadgeClass}" style="width: ${hpPct}%;"></div>
                        </div>
                    </td>
                    <td class="col-stat" style="color:#4ade80; font-weight:700;">${e.kills}</td>
                    <td class="col-stat" style="color:#f87171;">${e.deaths}</td>
                    <td class="col-stat" style="color:#fbbf24; font-weight:700;">${e.damageDealt}</td>
                    <td class="col-stat" style="color:#94a3b8;">${e.damageTaken}</td>
                    <td class="col-stat" style="color:#34d399;">${e.healing}</td>
                    ${hillCell}
                    <td class="col-score">${e.score}</td>
                </tr>
            `;
        }).join('');
    }

    renderPostMatchLeaderboard(kothWinner = null) {
        const leaderboard = this.getMatchLeaderboard();
        if (leaderboard.length === 0) return;

        const mvp = leaderboard[0];

        // 1. Cập nhật MVP Showcase Card
        const mvpCard = document.getElementById('postMatchMvpCard');
        if (mvpCard) {
            const mvpTag = document.getElementById('mvpHeaderTag');
            const mvpAvatar = document.getElementById('mvpAvatar');
            const mvpName = document.getElementById('mvpName');
            const mvpTeam = document.getElementById('mvpTeamBadge');
            const mvpKills = document.getElementById('mvpKills');
            const mvpDmg = document.getElementById('mvpDmg');
            const mvpScore = document.getElementById('mvpScore');

            if (mvpTag) {
                mvpTag.innerText = (mvp.unit === this.player || mvp.unit === this.p1Unit) 
                    ? t('lbPlayerMvpNotice') 
                    : t('lbMvpTitle');
            }
            if (mvpAvatar) mvpAvatar.innerText = mvp.avatar;
            if (mvpName) mvpName.innerText = mvp.name;
            if (mvpTeam) {
                mvpTeam.className = `mvp-team-badge ${mvp.team === 'BLUE' ? 'blue' : 'red'}`;
                mvpTeam.innerText = mvp.team === 'BLUE' ? (this.lang === 'en' ? 'Blue Team' : 'Đội Xanh') : (this.lang === 'en' ? 'Red Team' : 'Đội Đỏ');
            }
            if (mvpKills) mvpKills.innerText = mvp.kills;
            if (mvpDmg) mvpDmg.innerText = mvp.damageDealt;
            if (mvpScore) mvpScore.innerText = mvp.score;
        }

        // 2. Cập nhật Bảng Chung Cuộc
        const tbody = document.getElementById('postMatchLbTbody');
        if (tbody) {
            tbody.innerHTML = leaderboard.map(e => {
                const isPlayer = e.isPlayer;
                let rankBadge = `${e.rank}`;
                if (e.rank === 1) rankBadge = '🥇';
                else if (e.rank === 2) rankBadge = '🥈';
                else if (e.rank === 3) rankBadge = '🥉';

                const playerTag = isPlayer ? `<span class="lb-badge-you">${e.playerIndex === 2 ? 'P2' : (this.isTwoPlayerMode ? 'P1' : (this.lang === 'en' ? 'YOU' : 'BẠN'))}</span>` : '';
                const teamName = e.team === 'BLUE' ? (this.lang === 'en' ? 'Blue' : 'Xanh') : (this.lang === 'en' ? 'Red' : 'Đỏ');

                return `
                    <tr class="lb-row-${e.team === 'BLUE' ? 'blue' : 'red'} ${e.isMvp ? 'lb-row-mvp' : ''} ${isPlayer ? 'lb-row-player' : ''}">
                        <td class="col-rank">${rankBadge}</td>
                        <td class="col-char">
                            <span style="font-size:1.1rem; margin-right:6px;">${e.avatar}</span>
                            <b>${e.name}</b> ${playerTag}
                        </td>
                        <td class="col-team">
                            <span class="mvp-team-badge ${e.team === 'BLUE' ? 'blue' : 'red'}">${teamName}</span>
                        </td>
                        <td class="col-stat" style="color:#4ade80; font-weight:700;">${e.kills}</td>
                        <td class="col-stat" style="color:#f87171;">${e.deaths}</td>
                        <td class="col-stat" style="color:#fbbf24; font-weight:700;">${e.damageDealt}</td>
                        <td class="col-score">${e.score}</td>
                    </tr>
                `;
            }).join('');
        }
    }

    saveMatchRecord(kothWinner = null) {
        if (typeof localStorage === 'undefined') return null;
        try {
            const leaderboard = this.getMatchLeaderboard();
            const mvp = leaderboard.length > 0 ? leaderboard[0] : null;
            const playerUnit = this.player || this.p1Unit;
            const pStats = playerUnit && playerUnit.stats ? playerUnit.stats : { kills: 0, deaths: 0, damageDealt: 0, score: 0 };
            
            let outcome = 'DRAW';
            if (this.gameMode === 'KOTH') {
                const blueAlive = (this.blueTeam || []).filter(u => u.hp > 0).length;
                const redAlive = (this.redTeam || []).filter(u => u.hp > 0).length;
                const isBlueWinner = kothWinner === 'BLUE_KOTH' || (kothWinner === null && (this.blueScore > this.redScore || (redAlive === 0 && blueAlive > 0)));
                const isRedWinner = kothWinner === 'RED_KOTH' || (kothWinner === null && (this.redScore > this.blueScore || (blueAlive === 0 && redAlive > 0)));
                if (playerUnit) {
                    if (playerUnit.team === 'BLUE') outcome = isBlueWinner ? 'VICTORY' : (isRedWinner ? 'DEFEAT' : 'DRAW');
                    else outcome = isRedWinner ? 'VICTORY' : (isBlueWinner ? 'DEFEAT' : 'DRAW');
                }
            } else {
                const blueAlive = (this.blueTeam || []).filter(u => u.hp > 0).length;
                const redAlive = (this.redTeam || []).filter(u => u.hp > 0).length;
                if (blueAlive === 0 && redAlive === 0) {
                    outcome = 'DRAW';
                } else if (playerUnit) {
                    if (playerUnit.team === 'BLUE') outcome = (redAlive === 0) ? 'VICTORY' : 'DEFEAT';
                    else outcome = (blueAlive === 0) ? 'VICTORY' : 'DEFEAT';
                }
            }

            const record = {
                id: 'm_' + Date.now(),
                date: new Date().toISOString(),
                dateFormatted: new Date().toLocaleDateString(this.lang === 'en' ? 'en-US' : 'vi-VN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
                gameMode: this.gameMode,
                teamSize: `${(this.blueTeam || []).length}v${(this.redTeam || []).length}`,
                turns: this.turn,
                outcome,
                playerChar: playerUnit ? playerUnit.charId : 'trooper',
                playerCharName: playerUnit ? getCharName(playerUnit.character, this.lang) : 'Operator',
                playerAvatar: playerUnit ? playerUnit.avatar : '🪖',
                kills: pStats.kills || 0,
                deaths: pStats.deaths || 0,
                damageDealt: pStats.damageDealt || 0,
                score: pStats.score || 0,
                mvpName: mvp ? mvp.name : '',
                mvpAvatar: mvp ? mvp.avatar : '👑',
                mvpScore: mvp ? mvp.score : 0,
                isPlayerMvp: mvp && mvp.unit === playerUnit
            };

            const raw = localStorage.getItem('crazy_warfare_match_history');
            let history = raw ? JSON.parse(raw) : [];
            if (!Array.isArray(history)) history = [];
            history.unshift(record);
            if (history.length > 30) history = history.slice(0, 30);
            localStorage.setItem('crazy_warfare_match_history', JSON.stringify(history));
            return record;
        } catch (e) {
            console.warn('Failed to save match record:', e);
            return null;
        }
    }

    getMatchHistory() {
        if (typeof localStorage === 'undefined') return [];
        try {
            const raw = localStorage.getItem('crazy_warfare_match_history');
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            return [];
        }
    }

    getHallOfFameStats() {
        const history = this.getMatchHistory();
        let totalMatches = history.length;
        let wins = 0;
        let highestScore = 0;
        let mostKills = 0;
        let mostDamage = 0;

        for (const m of history) {
            if (m.outcome === 'VICTORY') wins++;
            if (m.score > highestScore) highestScore = m.score;
            if (m.kills > mostKills) mostKills = m.kills;
            if (m.damageDealt > mostDamage) mostDamage = m.damageDealt;
        }

        const winRate = totalMatches > 0 ? Math.round((wins / totalMatches) * 100) : 0;
        return {
            totalMatches,
            wins,
            winRate,
            highestScore,
            mostKills,
            mostDamage,
            history
        };
    }

    openHallOfFame() {
        const modal = document.getElementById('hallOfFameModal');
        if (!modal) return;
        this.isHofOpen = true;
        modal.style.display = 'flex';
        this.renderHallOfFame();
        if (window.soundCtrl && window.soundCtrl.playSelect) window.soundCtrl.playSelect();
    }

    closeHallOfFame() {
        const modal = document.getElementById('hallOfFameModal');
        if (!modal) return;
        this.isHofOpen = false;
        modal.style.display = 'none';
        if (window.soundCtrl && window.soundCtrl.playUndo) window.soundCtrl.playUndo();
    }

    clearHallOfFameHistory() {
        if (typeof localStorage !== 'undefined') {
            try {
                localStorage.removeItem('crazy_warfare_match_history');
            } catch (e) {}
        }
        this.renderHallOfFame();
        this.addCombatLog(t('hofClearedMsg'), 'system');
        if (window.soundCtrl && window.soundCtrl.playSelect) window.soundCtrl.playSelect();
    }

    renderHallOfFame() {
        const modal = document.getElementById('hallOfFameModal');
        if (!modal) return;

        const stats = this.getHallOfFameStats();

        const hsEl = document.getElementById('hofHighScoreVal');
        const mkEl = document.getElementById('hofMaxKillsVal');
        const mdEl = document.getElementById('hofMaxDmgVal');
        const wrEl = document.getElementById('hofWinRateVal');
        const wrLbl = document.getElementById('hofWinRateLabel');

        if (hsEl) hsEl.innerText = stats.highestScore;
        if (mkEl) mkEl.innerText = stats.mostKills;
        if (mdEl) mdEl.innerText = stats.mostDamage;
        if (wrEl) wrEl.innerText = `${stats.winRate}%`;
        if (wrLbl) wrLbl.innerText = `${t('hofWinRate')} (${stats.wins}/${stats.totalMatches} ${t('hofMatches')})`;

        const tbody = document.getElementById('hofTbody');
        if (!tbody) return;

        if (stats.history.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:32px; color:#64748b;">${t('hofNoHistory')}</td></tr>`;
            return;
        }

        tbody.innerHTML = stats.history.map(m => {
            let resBadge = `<span class="tag-outcome win">${t('hofVictory')}</span>`;
            if (m.outcome === 'DEFEAT') resBadge = `<span class="tag-outcome loss">${t('hofDefeat')}</span>`;
            else if (m.outcome === 'DRAW') resBadge = `<span class="tag-outcome draw">${t('hofDraw')}</span>`;

            return `
                <tr>
                    <td style="color:#94a3b8; font-size:0.75rem;">${m.dateFormatted || ''}</td>
                    <td style="font-weight:700;">${m.gameMode} (${m.teamSize})</td>
                    <td>
                        <span style="font-size:1.1rem; margin-right:4px;">${m.playerAvatar || '🪖'}</span>
                        <b>${m.playerCharName || m.playerChar}</b>
                    </td>
                    <td>${resBadge}</td>
                    <td style="font-weight:700; color:#4ade80;">${m.kills} / ${m.deaths}</td>
                    <td style="font-weight:700; color:#fbbf24;">${m.damageDealt}</td>
                    <td style="font-weight:900; color:#fbbf24;">${m.score}</td>
                    <td>
                        <span style="font-size:1rem; margin-right:4px;">${m.mvpAvatar || '👑'}</span>
                        <span style="font-size:0.78rem;">${m.mvpName || '-'}</span>
                    </td>
                </tr>
            `;
        }).join('');
    }

    restartGame() {
        this.triggerAd();
        const modal = document.getElementById('gameModal');
        if (modal) modal.style.display = 'none';
        const inMatchLb = document.getElementById('inMatchLeaderboardModal');
        if (inMatchLb) inMatchLb.style.display = 'none';
        this.isLeaderboardOpen = false;
        this.turn = 1;
        this.phase = 'PLANNING';
        this.currentStep = -1;
        this.cancelPathPlanning();
        this.setupTeams();
        this.hillScale = 0;
        this.hillOwner = null;
        this.blueScore = 0;
        this.redScore = 0;
        this.inOvertime = false;

        this.groundHazards = [];
        this.fireZones = [];
        this.sentries = [];
        this.teleporters = [];
        this.playerRevealedTurns = 0;
        this.cpuRevealedTurns = 0;
        this.activeHookTethers = [];

        if (this.isTwoPlayerMode) {
            this.activePlanningPlayer = 1;
            this.p1Queue = [];
            this.p2Queue = [];
        }

        this.playerQueue = [];
        this.cpuQueue = [];
        this.floatingTexts = [];
        this.particles = [];

        const logElem = document.getElementById('combatLog');
        if (logElem) {
            logElem.innerHTML = `<div class="log-entry system">${this.lang === 'en' ? 'New squad battle commenced!' : 'Trận đại chiến đội hình mới đã bắt đầu!'}</div>`;
        }
        this.addCombatLog(this.lang === 'en'
            ? `Squad Battle: Blue Team (${this.blueTeamSize} units) vs Red Team (${this.redTeamSize} units)!`
            : `Đại chiến Đội hình: Đội Xanh (${this.blueTeamSize} người) vs Đội Đỏ (${this.redTeamSize} người)!`, 'system');

        this.updateSkillButtons();
        this.updateHUD();
        this.updateQueueDisplay();
        this.updateCamera(true);
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // --- Tính toán phạm vi hình chữ nhật 3x2 của Kiếm Gắn Tay (Razor) ---
    getRectSlashTiles(fromX, fromY, dir) {
        const tiles = [];
        const validDir = ['UP', 'DOWN', 'LEFT', 'RIGHT'].includes(dir) ? dir : 'RIGHT';

        if (validDir === 'RIGHT') {
            // Xa 2 ô theo trục X (+1, +2), Rộng 3 ô theo trục Y (-1, 0, +1)
            for (let dx = 1; dx <= 2; dx++) {
                for (let dy = -1; dy <= 1; dy++) {
                    const tx = fromX + dx;
                    const ty = fromY + dy;
                    if (tx >= 0 && tx < GRID_COLS && ty >= 0 && ty < GRID_ROWS) {
                        tiles.push({ x: tx, y: ty });
                    }
                }
            }
        } else if (validDir === 'LEFT') {
            // Xa 2 ô theo trục X (-1, -2), Rộng 3 ô theo trục Y (-1, 0, +1)
            for (let dx = -1; dx >= -2; dx--) {
                for (let dy = -1; dy <= 1; dy++) {
                    const tx = fromX + dx;
                    const ty = fromY + dy;
                    if (tx >= 0 && tx < GRID_COLS && ty >= 0 && ty < GRID_ROWS) {
                        tiles.push({ x: tx, y: ty });
                    }
                }
            }
        } else if (validDir === 'UP') {
            // Xa 2 ô theo trục Y (-1, -2), Rộng 3 ô theo trục X (-1, 0, +1)
            for (let dy = -1; dy >= -2; dy--) {
                for (let dx = -1; dx <= 1; dx++) {
                    const tx = fromX + dx;
                    const ty = fromY + dy;
                    if (tx >= 0 && tx < GRID_COLS && ty >= 0 && ty < GRID_ROWS) {
                        tiles.push({ x: tx, y: ty });
                    }
                }
            }
        } else if (validDir === 'DOWN') {
            // Xa 2 ô theo trục Y (+1, +2), Rộng 3 ô theo trục X (-1, 0, +1)
            for (let dy = 1; dy <= 2; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    const tx = fromX + dx;
                    const ty = fromY + dy;
                    if (tx >= 0 && tx < GRID_COLS && ty >= 0 && ty < GRID_ROWS) {
                        tiles.push({ x: tx, y: ty });
                    }
                }
            }
        }
        return tiles;
    }

    createLeapArc(x1, y1, x2, y2, color = '#06b6d4') {
        const cx1 = x1 * CELL_SIZE + CELL_SIZE / 2;
        const cy1 = y1 * CELL_SIZE + CELL_SIZE / 2;
        const cx2 = x2 * CELL_SIZE + CELL_SIZE / 2;
        const cy2 = y2 * CELL_SIZE + CELL_SIZE / 2;
        const steps = 24;
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            const arcY = -Math.sin(t * Math.PI) * 45;
            this.particles.push({
                x: cx1 + (cx2 - cx1) * t + (Math.random() - 0.5) * 6,
                y: cy1 + (cy2 - cy1) * t + arcY + (Math.random() - 0.5) * 6,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                color: Math.random() > 0.4 ? color : '#ffffff',
                size: Math.random() * 4 + 2,
                life: 0.38,
                maxLife: 0.38
            });
        }
    }

    createRectSlashEffect(tiles, color = '#06b6d4') {
        for (const t of tiles) {
            const cx = t.x * CELL_SIZE + CELL_SIZE / 2;
            const cy = t.y * CELL_SIZE + CELL_SIZE / 2;
            for (let i = 0; i < 8; i++) {
                const angle = Math.random() * Math.PI * 2;
                const speed = Math.random() * 8 + 3;
                this.particles.push({
                    x: cx + (Math.random() - 0.5) * 28,
                    y: cy + (Math.random() - 0.5) * 28,
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    color: Math.random() > 0.3 ? color : '#e0f2fe',
                    size: Math.random() * 4 + 2,
                    life: 0.32,
                    maxLife: 0.32
                });
            }
        }
    }

    // --- Hiệu ứng đồ họa & hạt ---
    createSlashEffect(gridX, gridY, color) {
        for (let i = 0; i < 15; i++) {
            this.particles.push({
                x: gridX * CELL_SIZE + CELL_SIZE / 2 + (Math.random() - 0.5) * 40,
                y: gridY * CELL_SIZE + CELL_SIZE / 2 + (Math.random() - 0.5) * 40,
                vx: (Math.random() - 0.5) * 12,
                vy: (Math.random() - 0.5) * 12,
                color: color,
                size: Math.random() * 4 + 2,
                life: 0.28,
                maxLife: 0.28
            });
        }
    }

    createBulletTracer(x1, y1, x2, y2, color) {
        const cx1 = x1 * CELL_SIZE + CELL_SIZE / 2;
        const cy1 = y1 * CELL_SIZE + CELL_SIZE / 2;
        const cx2 = x2 * CELL_SIZE + CELL_SIZE / 2;
        const cy2 = y2 * CELL_SIZE + CELL_SIZE / 2;
        const dist = Math.hypot(cx2 - cx1, cy2 - cy1);
        const steps = Math.max(8, Math.floor(dist / 14));
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            this.particles.push({
                x: cx1 + (cx2 - cx1) * t + (Math.random() - 0.5) * 4,
                y: cy1 + (cy2 - cy1) * t + (Math.random() - 0.5) * 4,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                color: color,
                size: Math.random() * 3 + 2,
                life: 0.22,
                maxLife: 0.22
            });
        }
    }

    createRocketTrail(x1, y1, x2, y2, color) {
        const cx1 = x1 * CELL_SIZE + CELL_SIZE / 2;
        const cy1 = y1 * CELL_SIZE + CELL_SIZE / 2;
        const cx2 = x2 * CELL_SIZE + CELL_SIZE / 2;
        const cy2 = y2 * CELL_SIZE + CELL_SIZE / 2;
        const steps = 18;
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            this.particles.push({
                x: cx1 + (cx2 - cx1) * t + (Math.random() - 0.5) * 10,
                y: cy1 + (cy2 - cy1) * t + (Math.random() - 0.5) * 10,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                color: Math.random() > 0.5 ? '#f59e0b' : color,
                size: Math.random() * 5 + 3,
                life: 0.35,
                maxLife: 0.35
            });
        }
    }

    createExplosionBurst(gridX, gridY, count = 40) {
        const cx = gridX * CELL_SIZE + CELL_SIZE / 2;
        const cy = gridY * CELL_SIZE + CELL_SIZE / 2;
        const colors = ['#ef4444', '#f59e0b', '#fbbf24', '#ffffff'];
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 14 + 4;
            this.particles.push({
                x: cx + (Math.random() - 0.5) * 20,
                y: cy + (Math.random() - 0.5) * 20,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: colors[Math.floor(Math.random() * colors.length)],
                size: Math.random() * 7 + 3,
                life: 0.55,
                maxLife: 0.55
            });
        }
    }

    createGrenadeArc(x1, y1, x2, y2) {
        const cx1 = x1 * CELL_SIZE + CELL_SIZE / 2;
        const cy1 = y1 * CELL_SIZE + CELL_SIZE / 2;
        const cx2 = x2 * CELL_SIZE + CELL_SIZE / 2;
        const cy2 = y2 * CELL_SIZE + CELL_SIZE / 2;
        for (let i = 0; i <= 10; i++) {
            const t = i / 10;
            const arcY = -Math.sin(t * Math.PI) * 35;
            this.particles.push({
                x: cx1 + (cx2 - cx1) * t,
                y: cy1 + (cy2 - cy1) * t + arcY,
                vx: 0,
                vy: 0,
                color: '#f59e0b',
                size: 3.5,
                life: 0.4,
                maxLife: 0.4
            });
        }
    }

    createHookChainEffect(x1, y1, x2, y2) {
        const startX = x1 * CELL_SIZE + CELL_SIZE / 2;
        const startY = y1 * CELL_SIZE + CELL_SIZE / 2;
        const endX = x2 * CELL_SIZE + CELL_SIZE / 2;
        const endY = y2 * CELL_SIZE + CELL_SIZE / 2;
        const dist = Math.hypot(endX - startX, endY - startY);
        const steps = Math.max(6, Math.floor(dist / 14));

        for (let i = 0; i <= steps; i++) {
            const progress = i / steps;
            const px = startX + (endX - startX) * progress;
            const py = startY + (endY - startY) * progress;
            this.particles.push({
                x: px,
                y: py,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                color: '#ef4444',
                size: 3,
                life: 0.35,
                maxLife: 0.35
            });
        }
    }

    createBuffSparks(gridX, gridY, color = '#10b981') {
        for (let i = 0; i < 20; i++) {
            this.particles.push({
                x: gridX * CELL_SIZE + CELL_SIZE / 2 + (Math.random() - 0.5) * 36,
                y: gridY * CELL_SIZE + CELL_SIZE / 2 + (Math.random() - 0.5) * 36,
                vx: (Math.random() - 0.5) * 4,
                vy: -(Math.random() * 6 + 3), // Bay lên trên
                color: color,
                size: Math.random() * 4 + 2,
                life: 0.45,
                maxLife: 0.45
            });
        }
    }

    createHitSparks(gridX, gridY, color) {
        for (let i = 0; i < 25; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 8 + 3;
            this.particles.push({
                x: gridX * CELL_SIZE + CELL_SIZE / 2,
                y: gridY * CELL_SIZE + CELL_SIZE / 2,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: Math.random() > 0.4 ? color : '#ffffff',
                size: Math.random() * 5 + 2,
                life: 0.45,
                maxLife: 0.45
            });
        }
    }

    createShieldSpark(gridX, gridY, color) {
        for (let i = 0; i < 16; i++) {
            const angle = (i / 16) * Math.PI * 2;
            this.particles.push({
                x: gridX * CELL_SIZE + CELL_SIZE / 2 + Math.cos(angle) * 25,
                y: gridY * CELL_SIZE + CELL_SIZE / 2 + Math.sin(angle) * 25,
                vx: Math.cos(angle) * 3,
                vy: Math.sin(angle) * 3,
                color: color,
                size: 3,
                life: 0.35,
                maxLife: 0.35
            });
        }
    }

    createClashBurst(gridX, gridY) {
        for (let i = 0; i < 35; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 11 + 4;
            this.particles.push({
                x: gridX * CELL_SIZE + CELL_SIZE / 2,
                y: gridY * CELL_SIZE + CELL_SIZE / 2,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: '#fbbf24',
                size: Math.random() * 6 + 2,
                life: 0.5,
                maxLife: 0.5
            });
        }
    }

    createTeleportBurst(x1, y1, x2, y2) {
        for (let i = 0; i < 20; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 6 + 2;
            this.particles.push({
                x: x1 * CELL_SIZE + CELL_SIZE / 2,
                y: y1 * CELL_SIZE + CELL_SIZE / 2,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: '#06b6d4',
                size: Math.random() * 4 + 2,
                life: 0.45,
                maxLife: 0.45
            });
            this.particles.push({
                x: x2 * CELL_SIZE + CELL_SIZE / 2,
                y: y2 * CELL_SIZE + CELL_SIZE / 2,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: '#06b6d4',
                size: Math.random() * 4 + 2,
                life: 0.45,
                maxLife: 0.45
            });
        }
    }

    getEnemyDeployableAt(x, y, attackerTeam) {
        if (this.sentries) {
            const s = this.sentries.find(s => s.x === x && s.y === y && s.team !== attackerTeam && s.hp > 0);
            if (s) return { type: 'SENTRY', obj: s, team: s.team, x: s.x, y: s.y, hp: s.hp, maxHp: s.maxHp };
        }
        if (this.teleporters) {
            const tIn = this.teleporters.find(t => t.inX === x && t.inY === y && t.team !== attackerTeam && t.hp > 0);
            if (tIn) return { type: 'TELE_IN', obj: tIn, team: tIn.team, x: tIn.inX, y: tIn.inY, hp: tIn.hp, maxHp: tIn.maxHp };
            const tOut = this.teleporters.find(t => t.outX === x && t.outY === y && t.team !== attackerTeam && t.hp > 0);
            if (tOut) return { type: 'TELE_OUT', obj: tOut, team: tOut.team, x: tOut.outX, y: tOut.outY, hp: tOut.hp, maxHp: tOut.maxHp };
        }
        if (this.zombies) {
            const z = this.zombies.find(z => z.x === x && z.y === y && z.team !== attackerTeam && z.hp > 0);
            if (z) return { type: 'ZOMBIE', obj: z, team: z.team, x: z.x, y: z.y, hp: z.hp, maxHp: z.maxHp };
        }
        return null;
    }

    damageDeployable(dep, dmg, attacker) {
        if (!dep || !dep.obj || dep.obj.hp <= 0) return;
        dep.obj.hp -= dmg;
        const isZombie = (dep.type === 'ZOMBIE');
        const isSentry = (dep.type === 'SENTRY');
        const label = isZombie ? t('deployableZombie') : (isSentry ? t('deployableSentry') : t('deployableTeleporter'));
        const ownerName = dep.obj.ownerName || (isZombie ? (this.lang === 'en' ? 'False Prophet' : 'Fake Savior') : 'Engie');

        this.createHitSparks(dep.x, dep.y, '#f59e0b');
        this.addFloatingText(`-${dmg} HP (${label})`, dep.x, dep.y, '#f87171');
        this.addCombatLog(
            this.lang === 'en'
                ? `💥 ${attacker ? attacker.name : 'Attack'} deals ${dmg} damage to ${label} of ${ownerName}! (${Math.max(0, dep.obj.hp)}/${dep.obj.maxHp} HP)`
                : `💥 ${attacker ? attacker.name : 'Đòn đánh'} gây ${dmg} sát thương lên ${label} của ${ownerName}! (${Math.max(0, dep.obj.hp)}/${dep.obj.maxHp} HP)`,
            'hit'
        );

        if (dep.obj.hp <= 0) {
            dep.obj.hp = 0;
            this.createExplosionBurst(dep.x, dep.y, 30);
            if (window.soundCtrl) window.soundCtrl.playExplosion();
            this.addFloatingText(this.lang === 'en' ? `💥 DESTROYED!` : `💥 BỊ PHÁ HỦY!`, dep.x, dep.y, '#ef4444');
            this.addCombatLog(
                this.lang === 'en'
                    ? `💥 ${label} of ${ownerName} has been destroyed!`
                    : `💥 ${label} của ${ownerName} đã bị phá hủy tan tành!`,
                'clash'
            );

            if (isZombie) {
                this.zombies = this.zombies.filter(z => z.hp > 0);
            } else if (isSentry) {
                this.sentries = this.sentries.filter(s => s.hp > 0);
            } else {
                this.teleporters = this.teleporters.filter(t => t.hp > 0);
            }
        }
    }

    damageDeployablesInArea(centerX, centerY, radius, dmg, attackerTeam, attacker) {
        if (this.zombies) {
            const zombiesToDamage = this.zombies.filter(z =>
                z.hp > 0 &&
                (!attackerTeam || z.team !== attackerTeam) &&
                Math.abs(z.x - centerX) <= radius && Math.abs(z.y - centerY) <= radius
            );
            for (const z of zombiesToDamage) {
                this.damageDeployable({ type: 'ZOMBIE', obj: z, team: z.team, x: z.x, y: z.y, hp: z.hp, maxHp: z.maxHp }, dmg, attacker);
            }
        }
        if (this.sentries) {
            const sentriesToDamage = this.sentries.filter(s =>
                s.hp > 0 &&
                (!attackerTeam || s.team !== attackerTeam) &&
                Math.abs(s.x - centerX) <= radius && Math.abs(s.y - centerY) <= radius
            );
            for (const s of sentriesToDamage) {
                this.damageDeployable({ type: 'SENTRY', obj: s, team: s.team, x: s.x, y: s.y, hp: s.hp, maxHp: s.maxHp }, dmg, attacker);
            }
        }
        if (this.teleporters) {
            const telesToDamage = this.teleporters.filter(t =>
                t.hp > 0 &&
                (!attackerTeam || t.team !== attackerTeam) &&
                ((Math.abs(t.inX - centerX) <= radius && Math.abs(t.inY - centerY) <= radius) ||
                 (Math.abs(t.outX - centerX) <= radius && Math.abs(t.outY - centerY) <= radius))
            );
            for (const t of telesToDamage) {
                const hitIn = Math.abs(t.inX - centerX) <= radius && Math.abs(t.inY - centerY) <= radius;
                const depType = hitIn ? 'TELE_IN' : 'TELE_OUT';
                const depX = hitIn ? t.inX : t.outX;
                const depY = hitIn ? t.inY : t.outY;
                this.damageDeployable({ type: depType, obj: t, team: t.team, x: depX, y: depY, hp: t.hp, maxHp: t.maxHp }, dmg, attacker);
            }
        }
    }

    checkTeleporters(unit) {
        if (!this.teleporters || this.teleporters.length === 0 || unit.hp <= 0) return;
        for (const tele of this.teleporters) {
            if (tele.hp <= 0) continue;
            // Chỉ áp dụng cho thành viên cùng đội (Mọi thành viên thuộc đội)
            if (unit.team !== tele.team) continue;

            if (unit.x === tele.inX && unit.y === tele.inY) {
                let destX = tele.outX;
                let destY = tele.outY;

                const allAlive = [...this.blueTeam, ...this.redTeam].filter(u => u.hp > 0 && u !== unit);
                const isOccupied = allAlive.some(u => u.x === destX && u.y === destY);
                if (isOccupied) {
                    const offsets = [
                        { dx: 1, dy: 0 }, { dx: -1, dy: 0 }, { dx: 0, dy: 1 }, { dx: 0, dy: -1 },
                        { dx: 1, dy: 1 }, { dx: -1, dy: -1 }, { dx: 1, dy: -1 }, { dx: -1, dy: 1 }
                    ];
                    for (const off of offsets) {
                        const nx = destX + off.dx;
                        const ny = destY + off.dy;
                        if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
                            if (!allAlive.some(u => u.x === nx && u.y === ny)) {
                                destX = nx;
                                destY = ny;
                                break;
                            }
                        }
                    }
                }

                unit.x = destX;
                unit.y = destY;
                unit.renderX = destX;
                unit.renderY = destY;

                if (window.soundCtrl) window.soundCtrl.playTeleport();
                this.createBuffSparks(destX, destY, '#06b6d4');
                this.createTeleportBurst(tele.inX, tele.inY, destX, destY);
                this.addFloatingText(this.lang === 'en' ? '🌀 WARPED!' : '🌀 DỊCH CHUYỂN!', destX, destY, '#06b6d4');
                this.addCombatLog(
                    this.lang === 'en'
                        ? `🌀 ${unit.name} stepped into Teleporter and warped to (${destX}, ${destY})!`
                        : `🌀 ${unit.name} bước vào Cổng Dịch Chuyển và tức thì xuất hiện tại (${destX}, ${destY})!`,
                    'system'
                );
                this.checkFireZones(unit);
                break;
            }
        }
    }

    async resolveSentryAttacks(stepIndex) {
        if (!this.sentries || this.sentries.length === 0) return;
        const allLivingUnits = [...this.blueTeam, ...this.redTeam].filter(u => u.hp > 0);

        for (const sentry of this.sentries) {
            if (sentry.hp <= 0) continue;
            const opposingTeam = (sentry.team === 'BLUE') ? this.redTeam : this.blueTeam;
            const livingOpponents = opposingTeam.filter(u => u.hp > 0);
            if (livingOpponents.length === 0) continue;

            // Quét 11x11 quanh nó (bán kính Chebyshev <= 5)
            const sRange = sentry.range || 5;
            const enemiesInRange = livingOpponents.filter(e =>
                Math.abs(e.x - sentry.x) <= sRange &&
                Math.abs(e.y - sentry.y) <= sRange
            );
            if (enemiesInRange.length === 0) continue;

            // Bắn kẻ địch gần nhất
            enemiesInRange.sort((a, b) => {
                const distA = Math.abs(a.x - sentry.x) + Math.abs(a.y - sentry.y);
                const distB = Math.abs(b.x - sentry.x) + Math.abs(b.y - sentry.y);
                return distA - distB;
            });
            const target = enemiesInRange[0];

            if (window.soundCtrl) window.soundCtrl.playSentryShot();
            this.createBulletTracer(sentry.x, sentry.y, target.x, target.y, '#f59e0b');

            // Kiểm tra khiên
            let blocked = false;
            if (target.shieldDir) {
                const sD = DIRECTIONS[target.shieldDir];
                const dxToSentry = sentry.x - target.x;
                const dyToSentry = sentry.y - target.y;
                if ((sD.dx !== 0 && Math.sign(sD.dx) === Math.sign(dxToSentry)) ||
                    (sD.dy !== 0 && Math.sign(sD.dy) === Math.sign(dyToSentry))) {
                    blocked = true;
                }
            }

            if (blocked) {
                if (window.soundCtrl && (target.isPlayer || allLivingUnits.some(u => u.isPlayer))) window.soundCtrl.playShield();
                this.addFloatingText(this.lang === 'en' ? 'BLOCKED SENTRY!' : 'CHẶN ĐẠN SENTRY!', target.x, target.y, '#60a5fa');
                this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: ${target.name} raised Shield, blocking ${sentry.ownerName}'s Sentry burst!` : `Nhịp #${stepIndex + 1}: ${target.name} giương Khiên chặn loạt đạn Sentry của ${sentry.ownerName}!`, 'block');
            } else {
                if (window.soundCtrl && (target.isPlayer || allLivingUnits.some(u => u.isPlayer))) window.soundCtrl.playHit();
                const dmg = sentry.power || 10;
                this.applyDamage(target, dmg, sentry.owner || null);
                this.createHitSparks(target.x, target.y, target.color);
                this.addFloatingText(`-${dmg} HP (SENTRY 🤖)`, target.x, target.y, '#ea580c');
                this.addCombatLog(this.lang === 'en' ? `Beat #${stepIndex + 1}: 🤖 ${sentry.ownerName}'s Sentry automatically fired at ${target.name}! (-${dmg} HP)!` : `Nhịp #${stepIndex + 1}: 🤖 Sentry của ${sentry.ownerName} tự động nã đạn vào ${target.name}! (-${dmg} HP)!`, 'hit');

                if (target.charId === 'hookman') {
                    target.revealedTurns = 2;
                    if (target.isPlayer) this.playerRevealedTurns = 2;
                    this.addFloatingText(this.lang === 'en' ? 'REVEALED!' : 'HIỆN HÌNH!', target.x, target.y, '#f43f5e');
                }
            }
            await this.delay(100);
        }
    }

    async resolveZombieAttacks(stepIndex) {
        if (!this.zombies || this.zombies.length === 0) return;
        const allLivingUnits = [...this.blueTeam, ...this.redTeam].filter(u => u.hp > 0);

        for (const zombie of this.zombies) {
            if (zombie.hp <= 0) continue;
            // Mỗi thây ma chỉ có duy nhất 1 lệnh tấn công trong lượt:
            if (zombie.attackedThisTurn) continue;

            const opposingTeam = (zombie.team === 'BLUE') ? this.redTeam : this.blueTeam;
            const livingOpponents = opposingTeam.filter(u => u.hp > 0);
            if (livingOpponents.length === 0) continue;

            // Quét phạm vi 3x3 quanh thây ma (bán kính Chebyshev <= 1)
            const inRangeEnemies = livingOpponents.filter(e =>
                Math.abs(e.x - zombie.x) <= 1 &&
                Math.abs(e.y - zombie.y) <= 1
            );

            if (inRangeEnemies.length === 0) continue;

            // "và chỉ ở duy nhất 1 kẻ địch ngẫu nhiên nếu có nhiều kẻ địch trong phạm vi"
            const target = inRangeEnemies[Math.floor(Math.random() * inRangeEnemies.length)];

            // Thực thi lệnh tấn công duy nhất
            zombie.attackedThisTurn = true;

            if (window.soundCtrl && (target.isPlayer || allLivingUnits.some(u => u.isPlayer))) window.soundCtrl.playZombieAttack();

            const dmg = zombie.power || 35;
            this.applyDamage(target, dmg, zombie.owner || null);
            this.createHitSparks(target.x, target.y, '#10b981');
            this.addFloatingText(this.lang === 'en' ? `🧟 BITE -${dmg} HP!` : `🧟 CẮN -${dmg} HP!`, target.x, target.y, '#10b981');
            this.addCombatLog(
                this.lang === 'en'
                    ? `Beat #${stepIndex + 1}: ${zombie.name} bit ${target.name} for ${dmg} DMG in 3x3 zone!`
                    : `Nhịp #${stepIndex + 1}: ${zombie.name} tấn công cắn xé ${target.name} gây ${dmg} sát thương trong vùng 3x3!`,
                'hit'
            );
        }
    }

    addFloatingText(text, gridX, gridY, color = '#ffffff') {
        this.floatingTexts.push({
            text: text,
            x: gridX * CELL_SIZE + CELL_SIZE / 2,
            y: gridY * CELL_SIZE + 16,
            color: color,
            life: 0.8,
            maxLife: 0.8
        });
    }

    updateCamera(instant = false) {
        const playerScreenX = this.player.renderX * CELL_SIZE + CELL_SIZE / 2;
        const halfCanvasWidth = this.canvas.width / 2;
        const totalWorldWidth = GRID_COLS * CELL_SIZE;

        this.targetCameraX = Math.max(0, Math.min(totalWorldWidth - this.canvas.width, playerScreenX - halfCanvasWidth));

        if (instant) {
            this.cameraX = this.targetCameraX;
        } else {
            this.cameraX += (this.targetCameraX - this.cameraX) * 0.12;
        }
    }

    renderLoop(timestamp) {
        if (this.isAdShowing) {
            this.lastTime = timestamp;
            requestAnimationFrame((t) => this.renderLoop(t));
            return;
        }

        const dt = Math.min((timestamp - this.lastTime) / 1000, 0.1);
        this.lastTime = timestamp;

        if (this.blueTeam) {
            for (const u of this.blueTeam) {
                u.renderX += (u.x - u.renderX) * 0.2;
                u.renderY += (u.y - u.renderY) * 0.2;
            }
        }
        if (this.redTeam) {
            for (const u of this.redTeam) {
                u.renderX += (u.x - u.renderX) * 0.2;
                u.renderY += (u.y - u.renderY) * 0.2;
            }
        }

        this.updateCamera();

        this.renderWorld(dt);
        this.renderMinimap();

        requestAnimationFrame((t) => this.renderLoop(t));
    }

    renderWorld(dt) {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        ctx.save();
        ctx.translate(-this.cameraX, 0);

        // 1. Vẽ lưới ô cờ 20x7
        for (let r = 0; r < GRID_ROWS; r++) {
            for (let c = 0; c < GRID_COLS; c++) {
                const x = c * CELL_SIZE;
                const y = r * CELL_SIZE;

                ctx.fillStyle = (r + c) % 2 === 0 ? 'rgba(15, 23, 42, 0.7)' : 'rgba(11, 19, 36, 0.7)';
                ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);

                ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
                ctx.lineWidth = 1;
                ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);

                ctx.fillStyle = 'rgba(148, 163, 184, 0.15)';
                ctx.font = '10px monospace';
                ctx.fillText(`${c},${r}`, x + 4, y + 14);
            }
        }

        // 1.5 Vẽ Khu Vực Chiếm Cứ Điểm 5x5 (King of the Hill)
        if (this.gameMode === 'KOTH') {
            const kz = this.kothZone;
            const zX = kz.minX * CELL_SIZE;
            const zY = kz.minY * CELL_SIZE;
            const zW = (kz.maxX - kz.minX + 1) * CELL_SIZE;
            const zH = (kz.maxY - kz.minY + 1) * CELL_SIZE;

            ctx.save();
            let zoneBg = 'rgba(245, 158, 11, 0.08)';
            let borderColor = 'rgba(245, 158, 11, 0.8)';
            let statusText = this.lang === 'en' ? 'NEUTRAL (0/2)' : 'TRUNG LẬP (0/2)';

            const blueInZone = this.blueTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;
            const redInZone = this.redTeam.filter(u => u.hp > 0 && this.isInCaptureZone(u.x, u.y)).length;
            const isContested = blueInZone > 0 && redInZone > 0;

            if (isContested) {
                borderColor = 'rgba(245, 158, 11, 0.95)';
                zoneBg = 'rgba(245, 158, 11, 0.18)';
                if (this.hillOwner === 'BLUE') {
                    statusText = this.lang === 'en'
                        ? `⚔️ BLUE POINT [CONTESTED! ${blueInZone}v${redInZone}] [+1/T]`
                        : `⚔️ ĐỘI XANH [TRANH CHẤP! ${blueInZone}v${redInZone}] [+1/L]`;
                } else if (this.hillOwner === 'RED') {
                    statusText = this.lang === 'en'
                        ? `⚔️ RED POINT [CONTESTED! ${redInZone}v${blueInZone}] [+1/T]`
                        : `⚔️ ĐỘI ĐỎ [TRANH CHẤP! ${redInZone}v${blueInZone}] [+1/L]`;
                } else {
                    statusText = this.lang === 'en'
                        ? `⚔️ CONTESTED! (${blueInZone}v${redInZone})`
                        : `⚔️ TRANH CHẤP! (${blueInZone}v${redInZone})`;
                }
            } else if (this.hillOwner === 'BLUE') {
                zoneBg = 'rgba(56, 189, 248, 0.22)';
                borderColor = 'rgba(56, 189, 248, 0.95)';
                if (this.hillScale === 2) {
                    statusText = this.lang === 'en' ? 'BLUE ZONE (2/2) [+1/T]' : 'ĐỘI XANH KIỂM SOÁT (2/2) [+1/L]';
                } else {
                    statusText = this.lang === 'en'
                        ? `BLUE ZONE [RED CAPPING ${Math.abs(this.hillScale - 2)}/4] [+1/T]`
                        : `ĐỘI XANH [ĐỎ ĐANG CHIẾM ${Math.abs(this.hillScale - 2)}/4] [+1/L]`;
                }
            } else if (this.hillOwner === 'RED') {
                zoneBg = 'rgba(244, 63, 94, 0.22)';
                borderColor = 'rgba(244, 63, 94, 0.95)';
                if (this.hillScale === -2) {
                    statusText = this.lang === 'en' ? 'RED ZONE (2/2) [+1/T]' : 'ĐỘI ĐỎ KIỂM SOÁT (2/2) [+1/L]';
                } else {
                    statusText = this.lang === 'en'
                        ? `RED ZONE [BLUE CAPPING ${Math.abs(-2 - this.hillScale)}/4] [+1/T]`
                        : `ĐỘI ĐỎ [XANH ĐANG CHIẾM ${Math.abs(-2 - this.hillScale)}/4] [+1/L]`;
                }
            } else {
                if (this.hillScale === 1) {
                    zoneBg = 'rgba(56, 189, 248, 0.12)';
                    borderColor = 'rgba(56, 189, 248, 0.7)';
                    statusText = this.lang === 'en' ? 'BLUE CAPTURING (1/2)' : 'ĐỘI XANH ĐANG CHIẾM (1/2)';
                } else if (this.hillScale === -1) {
                    zoneBg = 'rgba(244, 63, 94, 0.12)';
                    borderColor = 'rgba(244, 63, 94, 0.7)';
                    statusText = this.lang === 'en' ? 'RED CAPTURING (1/2)' : 'ĐỘI ĐỎ ĐANG CHIẾM (1/2)';
                }
            }

            ctx.fillStyle = zoneBg;
            ctx.fillRect(zX, zY, zW, zH);

            ctx.strokeStyle = borderColor;
            ctx.lineWidth = 3;
            ctx.setLineDash([8, 6]);
            ctx.strokeRect(zX, zY, zW, zH);
            ctx.setLineDash([]);

            ctx.fillStyle = borderColor;
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(`🚩 ${statusText}`, zX + zW / 2, zY + 18);
            ctx.restore();
        }

        // 2. Vẽ các Quả Lựu đạn trên mặt đất (Ground Hazards & Vùng 3x3)
        this.groundHazards.forEach(h => {
            const hx = h.x * CELL_SIZE;
            const hy = h.y * CELL_SIZE;
            const aoeX = (h.x - 1) * CELL_SIZE;
            const aoeY = (h.y - 1) * CELL_SIZE;
            const aoeSize = 3 * CELL_SIZE;

            ctx.save();
            ctx.fillStyle = 'rgba(239, 68, 68, 0.12)';
            ctx.fillRect(aoeX, aoeY, aoeSize, aoeSize);
            ctx.strokeStyle = 'rgba(245, 158, 11, 0.8)';
            ctx.lineWidth = 1.5;
            ctx.setLineDash([6, 4]);
            ctx.strokeRect(aoeX, aoeY, aoeSize, aoeSize);

            ctx.setLineDash([]);
            ctx.font = '22px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('💣', hx + CELL_SIZE / 2, hy + CELL_SIZE / 2 - 4);

            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(hx + CELL_SIZE / 2 + 10, hy + CELL_SIZE / 2 + 10, 9, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText(`${h.turnsLeft}${this.lang === 'en' ? 'T' : 'L'}`, hx + CELL_SIZE / 2 + 10, hy + CELL_SIZE / 2 + 10);
            ctx.restore();
        });

        // 2b. Vẽ các Vùng Cháy 3x3 (Fire Zones)
        if (this.fireZones && this.fireZones.length > 0) {
            const time = performance.now() * 0.005;
            this.fireZones.forEach(fz => {
                const aoeX = (fz.x - 1) * CELL_SIZE;
                const aoeY = (fz.y - 1) * CELL_SIZE;
                const aoeSize = 3 * CELL_SIZE;

                ctx.save();
                const pulse = 0.22 + 0.08 * Math.sin(time + fz.x * 2 + fz.y * 3);
                ctx.fillStyle = `rgba(234, 88, 12, ${pulse})`;
                ctx.fillRect(aoeX, aoeY, aoeSize, aoeSize);

                ctx.strokeStyle = '#f97316';
                ctx.lineWidth = 2;
                ctx.setLineDash([8, 4]);
                ctx.strokeRect(aoeX, aoeY, aoeSize, aoeSize);
                ctx.setLineDash([]);

                ctx.font = '16px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                for (let dx = -1; dx <= 1; dx++) {
                    for (let dy = -1; dy <= 1; dy++) {
                        const fx = (fz.x + dx) * CELL_SIZE + CELL_SIZE / 2;
                        const fy = (fz.y + dy) * CELL_SIZE + CELL_SIZE / 2;
                        if ((dx + dy + Math.floor(time)) % 2 === 0) {
                            ctx.fillText('🔥', fx, fy);
                        }
                    }
                }

                const cx = fz.x * CELL_SIZE + CELL_SIZE / 2;
                const cy = fz.y * CELL_SIZE + CELL_SIZE / 2;
                ctx.fillStyle = '#ea580c';
                ctx.beginPath();
                ctx.arc(cx, cy, 13, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 1.5;
                ctx.stroke();

                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 11px sans-serif';
                ctx.fillText(`${fz.turnsLeft}${this.lang === 'en' ? 'T' : 'L'}`, cx, cy);
                ctx.restore();
            });
        }

        // 2c. Vẽ Cổng Dịch Chuyển (Teleporters)
        if (this.teleporters && this.teleporters.length > 0) {
            const time = performance.now() * 0.004;
            this.teleporters.forEach(tele => {
                if (tele.hp <= 0) return;
                const inPx = tele.inX * CELL_SIZE + CELL_SIZE / 2;
                const inPy = tele.inY * CELL_SIZE + CELL_SIZE / 2;
                const outPx = tele.outX * CELL_SIZE + CELL_SIZE / 2;
                const outPy = tele.outY * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                // Đường kết nối không gian giữa Cổng Vào và Cổng Ra
                ctx.strokeStyle = tele.team === 'BLUE' ? 'rgba(6, 182, 212, 0.4)' : 'rgba(244, 63, 94, 0.4)';
                ctx.lineWidth = 2;
                ctx.setLineDash([6, 4]);
                ctx.beginPath();
                ctx.moveTo(inPx, inPy);
                ctx.lineTo(outPx, outPy);
                ctx.stroke();
                ctx.setLineDash([]);

                // Vẽ Cổng Vào (IN)
                const pulseIn = 20 + 3 * Math.sin(time * 3);
                const gradIn = ctx.createRadialGradient(inPx, inPy, 5, inPx, inPy, pulseIn);
                gradIn.addColorStop(0, '#06b6d4');
                gradIn.addColorStop(0.7, 'rgba(6, 182, 212, 0.45)');
                gradIn.addColorStop(1, 'rgba(6, 182, 212, 0)');
                ctx.fillStyle = gradIn;
                ctx.beginPath();
                ctx.arc(inPx, inPy, pulseIn, 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = '#22d3ee';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(inPx, inPy, 16, 0, Math.PI * 2);
                ctx.stroke();

                ctx.font = '16px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('🌀', inPx, inPy - 2);

                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 9px monospace';
                ctx.fillText('IN', inPx, inPy + 12);

                // Thanh máu Cổng Vào
                const hpPct = Math.max(0, tele.hp / tele.maxHp);
                const barW = 32;
                ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
                ctx.fillRect(inPx - barW / 2, inPy - 26, barW, 4);
                ctx.fillStyle = hpPct > 0.4 ? '#06b6d4' : '#ef4444';
                ctx.fillRect(inPx - barW / 2, inPy - 26, barW * hpPct, 4);

                // Vẽ Cổng Ra (OUT)
                const pulseOut = 20 + 3 * Math.cos(time * 3);
                const gradOut = ctx.createRadialGradient(outPx, outPy, 5, outPx, outPy, pulseOut);
                gradOut.addColorStop(0, '#3b82f6');
                gradOut.addColorStop(0.7, 'rgba(59, 130, 246, 0.45)');
                gradOut.addColorStop(1, 'rgba(59, 130, 246, 0)');
                ctx.fillStyle = gradOut;
                ctx.beginPath();
                ctx.arc(outPx, outPy, pulseOut, 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = '#60a5fa';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(outPx, outPy, 16, 0, Math.PI * 2);
                ctx.stroke();

                ctx.font = '16px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('🌀', outPx, outPy - 2);

                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 9px monospace';
                ctx.fillText('OUT', outPx, outPy + 12);

                // Thanh máu Cổng Ra
                ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
                ctx.fillRect(outPx - barW / 2, outPy - 26, barW, 4);
                ctx.fillStyle = hpPct > 0.4 ? '#3b82f6' : '#ef4444';
                ctx.fillRect(outPx - barW / 2, outPy - 26, barW * hpPct, 4);

                ctx.restore();
            });
        }

        // 2d. Vẽ Sentry tự động (Auto-Sentries)
        if (this.sentries && this.sentries.length > 0) {
            this.sentries.forEach(sentry => {
                if (sentry.hp <= 0) return;
                const sx = sentry.x * CELL_SIZE + CELL_SIZE / 2;
                const sy = sentry.y * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                // Bệ ụ súng
                ctx.fillStyle = sentry.team === 'BLUE' ? 'rgba(56, 189, 248, 0.25)' : 'rgba(244, 63, 94, 0.25)';
                ctx.strokeStyle = sentry.team === 'BLUE' ? '#38bdf8' : '#f43f5e';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(sx, sy, 20, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                ctx.font = '20px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('🤖', sx, sy - 2);

                // Thanh máu Sentry
                const hpPct = Math.max(0, sentry.hp / sentry.maxHp);
                const barW = 34;
                ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
                ctx.fillRect(sx - barW / 2, sy - 28, barW, 5);
                ctx.fillStyle = hpPct > 0.5 ? '#10b981' : (hpPct > 0.25 ? '#f59e0b' : '#ef4444');
                ctx.fillRect(sx - barW / 2, sy - 28, barW * hpPct, 5);
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
                ctx.lineWidth = 1;
                ctx.strokeRect(sx - barW / 2, sy - 28, barW, 5);

                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 9px sans-serif';
                ctx.fillText(`${sentry.hp}/${sentry.maxHp}`, sx, sy - 34);

                ctx.restore();
            });
        }

        // 2e. Vẽ Thây Ma (Zombies)
        if (this.zombies && this.zombies.length > 0) {
            this.zombies.forEach(zombie => {
                if (zombie.hp <= 0) return;
                const zx = zombie.x * CELL_SIZE + CELL_SIZE / 2;
                const zy = zombie.y * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                ctx.fillStyle = zombie.team === 'BLUE' ? 'rgba(56, 189, 248, 0.2)' : 'rgba(244, 63, 94, 0.2)';
                ctx.strokeStyle = zombie.team === 'BLUE' ? '#38bdf8' : '#f43f5e';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(zx, zy, 20, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                ctx.font = '22px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('🧟', zx, zy - 2);

                const hpPct = Math.max(0, zombie.hp / zombie.maxHp);
                const barW = 32;
                ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
                ctx.fillRect(zx - barW / 2, zy - 28, barW, 5);
                ctx.fillStyle = hpPct > 0.5 ? '#10b981' : (hpPct > 0.25 ? '#f59e0b' : '#ef4444');
                ctx.fillRect(zx - barW / 2, zy - 28, barW * hpPct, 5);
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
                ctx.lineWidth = 1;
                ctx.strokeRect(zx - barW / 2, zy - 28, barW, 5);

                ctx.fillStyle = '#a78bfa';
                ctx.font = 'bold 9px sans-serif';
                ctx.fillText(`${zombie.hp}/${zombie.maxHp}`, zx, zy - 34);

                ctx.restore();
            });
        }

        // 3. Vẽ Lộ trình đã nạp trong hàng đợi
        this.renderQueuedPaths();

        // 4. Vẽ Lộ trình đang vẽ (Active Path)
        if (this.isBuildingPath) {
            this.renderActivePath();
        }

        // 5. Highlight ô mục tiêu
        if (this.phase === 'PLANNING' && !this.isBuildingPath) {
            const d = DIRECTIONS[this.currentSelectedDir];
            const targetX = this.player.x + d.dx;
            const targetY = this.player.y + d.dy;
            if (targetX >= 0 && targetX < GRID_COLS && targetY >= 0 && targetY < GRID_ROWS) {
                ctx.fillStyle = 'rgba(0, 242, 254, 0.15)';
                ctx.fillRect(targetX * CELL_SIZE, targetY * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                ctx.strokeStyle = this.player.color;
                ctx.lineWidth = 1.5;
                ctx.strokeRect(targetX * CELL_SIZE + 2, targetY * CELL_SIZE + 2, CELL_SIZE - 4, CELL_SIZE - 4);
            }
        }

        // 6. Vẽ toàn bộ Chiến binh (Hệ thống Tàng hình 7x7 của Hookman cho cả Đội Xanh & Đội Đỏ)
        const livingBlues = this.blueTeam ? this.blueTeam.filter(u => u.hp > 0) : [this.player];
        const livingReds = this.redTeam ? this.redTeam.filter(u => u.hp > 0) : [this.cpu];

        // Vẽ Đội Xanh
        for (const u of livingBlues) {
            const isHookman = u.charId === 'hookman';
            const isStealth = isHookman && u.revealedTurns <= 0 && livingReds.every(r => this.isOutside7x7(u, r));
            const isRevealed = isHookman && u.revealedTurns > 0;
            const tag = u.isPlayer ? `${u.name} [${this.lang === 'en' ? 'YOU' : 'BẠN'}]` : u.name;
            this.drawFighter(u, u.isPlayer ? u.color : '#38bdf8', tag, isStealth, isRevealed, u.revealedTurns);
        }

        // Vẽ Đội Đỏ
        for (const u of livingReds) {
            const isHookman = u.charId === 'hookman';
            const isStealth = isHookman && u.revealedTurns <= 0 && livingBlues.every(b => this.isOutside7x7(u, b));
            const isRevealed = isHookman && u.revealedTurns > 0;
            if (!isStealth) {
                this.drawFighter(u, '#f43f5e', u.name, false, isRevealed, u.revealedTurns);
            }
        }

        // Vẽ Dây Móc đang găm nối
        if (this.activeHookTethers && this.activeHookTethers.length > 0) {
            this.activeHookTethers.forEach(tether => {
                const hooker = tether.sourceUnit || (tether.source === 'PLAYER' ? this.player : this.cpu);
                const victim = tether.targetUnit || (tether.target === 'CPU' ? this.cpu : this.player);
                if (hooker && victim && hooker.hp > 0 && victim.hp > 0) {
                    ctx.save();
                    ctx.strokeStyle = '#ef4444';
                    ctx.lineWidth = 2.5;
                    ctx.setLineDash([8, 6]);
                    ctx.beginPath();
                    ctx.moveTo(hooker.renderX * CELL_SIZE + CELL_SIZE / 2, hooker.renderY * CELL_SIZE + CELL_SIZE / 2);
                    ctx.lineTo(victim.renderX * CELL_SIZE + CELL_SIZE / 2, victim.renderY * CELL_SIZE + CELL_SIZE / 2);
                    ctx.stroke();

                    const midX = ((hooker.renderX + victim.renderX) / 2) * CELL_SIZE + CELL_SIZE / 2;
                    const midY = ((hooker.renderY + victim.renderY) / 2) * CELL_SIZE + CELL_SIZE / 2;
                    ctx.setLineDash([]);
                    ctx.font = '16px sans-serif';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText('🪝', midX, midY);
                    ctx.restore();
                }
            });
        }

        // 7. Hạt hiệu ứng
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.life -= dt;
            if (p.life <= 0) {
                this.particles.splice(i, 1);
                continue;
            }
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.life / p.maxLife;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1.0;
        }

        // 8. Chữ bay
        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            const ft = this.floatingTexts[i];
            ft.y -= 38 * dt;
            ft.life -= dt;
            if (ft.life <= 0) {
                this.floatingTexts.splice(i, 1);
                continue;
            }
            ctx.save();
            ctx.font = 'bold 15px sans-serif';
            ctx.textAlign = 'center';
            ctx.globalAlpha = Math.min(1, ft.life / (ft.maxLife * 0.4));
            ctx.fillStyle = '#000000';
            ctx.fillText(ft.text, ft.x + 1, ft.y + 1);
            ctx.fillStyle = ft.color;
            ctx.fillText(ft.text, ft.x, ft.y);
            ctx.restore();
        }

        ctx.restore();
    }

    renderActivePath() {
        const ctx = this.ctx;
        const startPos = this.getPathStartPos();

        let prevX = startPos.x * CELL_SIZE + CELL_SIZE / 2;
        let prevY = startPos.y * CELL_SIZE + CELL_SIZE / 2;

        ctx.save();
        ctx.strokeStyle = this.player.color;
        ctx.lineWidth = 4;
        ctx.setLineDash([8, 6]);

        this.activePath.forEach((step, idx) => {
            const currX = step.x * CELL_SIZE + CELL_SIZE / 2;
            const currY = step.y * CELL_SIZE + CELL_SIZE / 2;

            ctx.beginPath();
            ctx.moveTo(prevX, prevY);
            ctx.lineTo(currX, currY);
            ctx.stroke();

            ctx.save();
            ctx.fillStyle = this.player.color;
            ctx.shadowColor = this.player.color;
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(currX, currY, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${idx + 1}`, currX, currY - 14);

            prevX = currX;
            prevY = currY;
        });

        ctx.restore();
    }

    renderQueuedPaths() {
        const ctx = this.ctx;
        let startX = this.player.x;
        let startY = this.player.y;

        ctx.save();
        for (const act of this.playerQueue) {
            if (act.type === 'PATH_MOVE' && act.path) {
                let px = startX * CELL_SIZE + CELL_SIZE / 2;
                let py = startY * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
                ctx.lineWidth = 3;
                ctx.setLineDash([4, 4]);

                for (const pNode of act.path) {
                    const nx = pNode.x * CELL_SIZE + CELL_SIZE / 2;
                    const ny = pNode.y * CELL_SIZE + CELL_SIZE / 2;

                    ctx.beginPath();
                    ctx.moveTo(px, py);
                    ctx.lineTo(nx, ny);
                    ctx.stroke();

                    ctx.fillStyle = '#38bdf8';
                    ctx.beginPath();
                    ctx.arc(nx, ny, 4, 0, Math.PI * 2);
                    ctx.fill();

                    px = nx;
                    py = ny;
                }
                ctx.restore();

                if (act.path.length > 0) {
                    const last = act.path[act.path.length - 1];
                    startX = last.x;
                    startY = last.y;
                }
            } else if (act.type === 'DASH') {
                const d = DIRECTIONS[act.dir];
                const destX = Math.max(0, Math.min(GRID_COLS - 1, startX + d.dx * (act.range || 2)));
                const destY = Math.max(0, Math.min(GRID_ROWS - 1, startY + d.dy * (act.range || 2)));

                const px = startX * CELL_SIZE + CELL_SIZE / 2;
                const py = startY * CELL_SIZE + CELL_SIZE / 2;
                const nx = destX * CELL_SIZE + CELL_SIZE / 2;
                const ny = destY * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                ctx.strokeStyle = 'rgba(251, 146, 60, 0.55)';
                ctx.lineWidth = 3;
                ctx.setLineDash([6, 3]);
                ctx.beginPath();
                ctx.moveTo(px, py);
                ctx.lineTo(nx, ny);
                ctx.stroke();

                ctx.fillStyle = '#fb923c';
                ctx.beginPath();
                ctx.arc(nx, ny, 5, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();

                startX = destX;
                startY = destY;
            } else if (act.type === 'LEAP') {
                const d = DIRECTIONS[act.dir];
                let destX = Math.max(0, Math.min(GRID_COLS - 1, startX + d.dx * (act.range || 3)));
                let destY = Math.max(0, Math.min(GRID_ROWS - 1, startY + d.dy * (act.range || 3)));

                const px = startX * CELL_SIZE + CELL_SIZE / 2;
                const py = startY * CELL_SIZE + CELL_SIZE / 2;
                const nx = destX * CELL_SIZE + CELL_SIZE / 2;
                const ny = destY * CELL_SIZE + CELL_SIZE / 2;

                ctx.save();
                ctx.strokeStyle = 'rgba(6, 182, 212, 0.55)';
                ctx.lineWidth = 3;
                ctx.setLineDash([6, 3]);
                ctx.beginPath();
                ctx.moveTo(px, py);
                ctx.quadraticCurveTo((px + nx) / 2, (py + ny) / 2 - 25, nx, ny);
                ctx.stroke();

                ctx.fillStyle = '#06b6d4';
                ctx.beginPath();
                ctx.arc(nx, ny, 6, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();

                startX = destX;
                startY = destY;
            }
        }
        ctx.restore();
    }

    drawFighter(fighter, color, tag, isStealth = false, isRevealed = false, revealedTurns = 0) {
        const ctx = this.ctx;
        const cx = fighter.renderX * CELL_SIZE + CELL_SIZE / 2;
        const cy = fighter.renderY * CELL_SIZE + CELL_SIZE / 2;

        ctx.save();
        ctx.translate(cx, cy);

        // Kiểm tra Buff Thuốc Lá (Smoke guy)
        const hasCigaretteBuff = (fighter.buffs && fighter.buffs.cigarette && fighter.buffs.cigarette.turnsLeft > 0);

        // Nếu ở trạng thái Tàng hình (Stealth)
        if (isStealth) {
            ctx.globalAlpha = 0.55;
            ctx.save();
            ctx.strokeStyle = '#a78bfa';
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 28, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} ${t('tagStealth')}`;
        } else if (isRevealed) {
            ctx.save();
            ctx.strokeStyle = '#f43f5e';
            ctx.setLineDash([3, 3]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 28, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} ${t('tagRevealed', { turns: revealedTurns })}`;
        }

        if (hasCigaretteBuff) {
            ctx.save();
            ctx.strokeStyle = 'rgba(251, 146, 60, 0.6)';
            ctx.setLineDash([3, 5]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 28, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🚬]`;
        }

        if (fighter.isOiled) {
            ctx.save();
            ctx.strokeStyle = '#d97706';
            ctx.setLineDash([3, 3]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 24, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🛢️]`;
        }

        if (fighter.burnTurns > 0) {
            ctx.save();
            ctx.strokeStyle = '#ea580c';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 22, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} ${t('tagBurn', { turns: fighter.burnTurns })}`;
        }

        // Kiểm tra Chế độ Ngắm Bắn (Snipeman)
        const isFighterScoped = fighter.isScoped || (this.phase === 'PLANNING' && this.isUnitScoped(fighter));
        if (isFighterScoped) {
            ctx.save();
            ctx.strokeStyle = '#818cf8';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(0, 0, 25, 0, Math.PI * 2);
            ctx.moveTo(-29, 0); ctx.lineTo(-19, 0);
            ctx.moveTo(19, 0); ctx.lineTo(29, 0);
            ctx.moveTo(0, -29); ctx.lineTo(0, -19);
            ctx.moveTo(0, 19); ctx.lineTo(0, 29);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🎯]`;
        }

        // Kiểm tra Buff Phát Bắn Hủy Diệt (Snipeman: +30% DMG & Xuyên Thấu)
        if (fighter.buffs && fighter.buffs.destructiveShot) {
            ctx.save();
            ctx.strokeStyle = '#ec4899';
            ctx.setLineDash([2, 3]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 27, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [⚡]`;
        }

        // Kiểm tra Buff Tầm Nhìn Dò Nhiệt (Snipeman: +1 Tầm)
        if (fighter.buffs && fighter.buffs.thermalVision && fighter.buffs.thermalVision.active) {
            ctx.save();
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(0, 0, 30, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🔭]`;
        }

        // Kiểm tra Buff Phát Bắn Rối Loạn (Hat Boom Man: +30% & Nổ 5x5)
        if (fighter.buffs && fighter.buffs.chaosShot) {
            ctx.save();
            ctx.strokeStyle = '#a855f7';
            ctx.setLineDash([3, 2]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 27, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🌀]`;
        }

        // Hiệu ứng Hộ Thuẫn Bất Tử (Medic: Kháng mọi sát thương)
        if (fighter.buffs && fighter.buffs.invulnerability && fighter.buffs.invulnerability.active) {
            ctx.save();
            ctx.strokeStyle = '#38bdf8';
            ctx.shadowColor = '#38bdf8';
            ctx.shadowBlur = 10;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(0, 0, 26, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} ${t('tagImmune')}`;
        } else if (fighter.buffs && fighter.buffs.invulnerability && fighter.buffs.invulnerability.primedForNextTurn) {
            ctx.save();
            ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 25, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} ${t('tagShield')}`;
        }

        // Hiệu ứng Miễn Nhiễm Sát Thương (Hat Boom Man Bật Nhảy)
        if (fighter.isImmune) {
            ctx.save();
            ctx.strokeStyle = '#eab308';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(0, 0, 24, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
            tag = `${tag} [🛡️]`;
        }

        // Hiệu ứng phát sáng
        const grad = ctx.createRadialGradient(0, 0, 8, 0, 0, 26);
        grad.addColorStop(0, color);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.globalAlpha = isStealth ? 0.3 : 0.5;
        ctx.beginPath();
        ctx.arc(0, 0, 26, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = isStealth ? 0.6 : 1.0;

        // Thân nhân vật
        ctx.fillStyle = '#0f172a';
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Biểu tượng Avatar ở giữa
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(fighter.avatar || '⚔️', 0, 1);

        // Hướng nhìn (8 hướng)
        const d = DIRECTIONS[fighter.dir];
        const angle = Math.atan2(d.dy, d.dx);
        const arrowDist = 24;
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(Math.cos(angle) * 11, Math.sin(angle) * 11);
        ctx.lineTo(Math.cos(angle) * arrowDist, Math.sin(angle) * arrowDist);
        ctx.stroke();

        // Khiên chắn
        if (fighter.shieldDir) {
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(0, 0, 24, angle - Math.PI / 3, angle + Math.PI / 3);
            ctx.stroke();
        }

        // Thanh máu Mini trên đầu nhân vật
        const barW = 32;
        const barH = 4;
        const hpRatio = Math.max(0, Math.min(1, fighter.hp / fighter.maxHp));
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(-barW / 2, -32, barW, barH);
        ctx.fillStyle = hpRatio > 0.5 ? '#10b981' : (hpRatio > 0.25 ? '#f59e0b' : '#ef4444');
        ctx.fillRect(-barW / 2, -32, barW * hpRatio, barH);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(-barW / 2, -32, barW, barH);

        // Tên tag
        ctx.font = 'bold 8.5px sans-serif';
        ctx.fillStyle = isStealth ? '#c084fc' : (isRevealed ? '#f43f5e' : (hasCigaretteBuff ? '#fb923c' : '#f8fafc'));
        ctx.textAlign = 'center';
        ctx.fillText(tag, 0, -23);

        ctx.restore();
    }

    renderMinimap() {
        const mCtx = this.minimapCtx;
        const w = this.minimapCanvas.width;
        const h = this.minimapCanvas.height;
        const cellW = w / GRID_COLS;
        const cellH = h / GRID_ROWS;

        mCtx.clearRect(0, 0, w, h);

        mCtx.fillStyle = '#030712';
        mCtx.fillRect(0, 0, w, h);

        const vpX = (this.cameraX / (GRID_COLS * CELL_SIZE)) * w;
        const vpW = (this.canvas.width / (GRID_COLS * CELL_SIZE)) * w;
        mCtx.fillStyle = 'rgba(56, 189, 248, 0.12)';
        mCtx.fillRect(vpX, 0, vpW, h);
        mCtx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        mCtx.lineWidth = 1;
        mCtx.strokeRect(vpX, 0, vpW, h);

        // Vẽ Cứ Điểm 5x5 trên Minimap nếu ở chế độ KOTH
        if (this.gameMode === 'KOTH') {
            const kz = this.kothZone;
            const mzX = kz.minX * cellW;
            const mzY = kz.minY * cellH;
            const mzW = (kz.maxX - kz.minX + 1) * cellW;
            const mzH = (kz.maxY - kz.minY + 1) * cellH;

            let mColor = 'rgba(245, 158, 11, 0.25)';
            let mBorder = '#f59e0b';
            if (this.hillOwner === 'BLUE') {
                mColor = 'rgba(56, 189, 248, 0.35)';
                mBorder = '#38bdf8';
            } else if (this.hillOwner === 'RED') {
                mColor = 'rgba(244, 63, 94, 0.35)';
                mBorder = '#f43f5e';
            }

            mCtx.fillStyle = mColor;
            mCtx.fillRect(mzX, mzY, mzW, mzH);
            mCtx.strokeStyle = mBorder;
            mCtx.lineWidth = 1;
            mCtx.strokeRect(mzX, mzY, mzW, mzH);
        }

        // Vẽ bom trên minimap
        mCtx.fillStyle = '#ef4444';
        this.groundHazards.forEach(hz => {
            mCtx.fillRect(hz.x * cellW - 1, hz.y * cellH - 1, 3, 3);
        });

        // Vẽ Vùng Cháy trên minimap
        if (this.fireZones && this.fireZones.length > 0) {
            mCtx.fillStyle = 'rgba(234, 88, 12, 0.55)';
            this.fireZones.forEach(fz => {
                mCtx.fillRect((fz.x - 1) * cellW, (fz.y - 1) * cellH, 3 * cellW, 3 * cellH);
            });
        }

        // Vẽ Cổng Dịch Chuyển trên minimap
        if (this.teleporters && this.teleporters.length > 0) {
            mCtx.fillStyle = '#06b6d4';
            this.teleporters.forEach(t => {
                if (t.hp > 0) {
                    mCtx.fillRect(t.inX * cellW - 1, t.inY * cellH - 1, 3, 3);
                    mCtx.fillRect(t.outX * cellW - 1, t.outY * cellH - 1, 3, 3);
                }
            });
        }

        // Vẽ Sentry trên minimap
        if (this.sentries && this.sentries.length > 0) {
            mCtx.fillStyle = '#f59e0b';
            this.sentries.forEach(s => {
                if (s.hp > 0) {
                    mCtx.fillRect(s.x * cellW - 1, s.y * cellH - 1, 3, 3);
                }
            });
        }

        // Vẽ Thây Ma trên minimap
        if (this.zombies && this.zombies.length > 0) {
            this.zombies.forEach(z => {
                if (z.hp > 0) {
                    mCtx.fillStyle = z.team === 'BLUE' ? '#38bdf8' : '#f43f5e';
                    mCtx.fillRect(z.x * cellW - 1, z.y * cellH - 1, 3, 3);
                }
            });
        }

        // Vẽ toàn bộ chiến binh Đội Xanh
        if (this.blueTeam) {
            this.blueTeam.filter(u => u.hp > 0).forEach(u => {
                mCtx.fillStyle = u.isPlayer ? u.color : '#38bdf8';
                mCtx.beginPath();
                mCtx.arc((u.x + 0.5) * cellW, (u.y + 0.5) * cellH, 3.5, 0, Math.PI * 2);
                mCtx.fill();
            });
        }

        // Vẽ toàn bộ chiến binh Đội Đỏ (trừ tàng hình)
        if (this.redTeam) {
            const livingBlues = this.blueTeam ? this.blueTeam.filter(u => u.hp > 0) : [this.player];
            this.redTeam.filter(u => u.hp > 0).forEach(u => {
                const isHookman = u.charId === 'hookman';
                const isStealth = isHookman && u.revealedTurns <= 0 && livingBlues.every(b => this.isOutside7x7(u, b));
                if (!isStealth) {
                    mCtx.fillStyle = '#f43f5e';
                    mCtx.beginPath();
                    mCtx.arc((u.x + 0.5) * cellW, (u.y + 0.5) * cellH, 3.5, 0, Math.PI * 2);
                    mCtx.fill();
                }
            });
        }
    }
}

// Khởi tạo Game
window.addEventListener('DOMContentLoaded', () => {
    window.gameEngine = new GameEngine();
});
